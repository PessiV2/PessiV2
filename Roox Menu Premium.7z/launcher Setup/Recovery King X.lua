
------------------------------------------------------------------------------------------------------------------------------------------------------------
------------------------------------------" [ Recovery King X Script - By Offline Mods - Relayzr ] " -----------------------------------------------------
-------------------------------------------------" [ Script To -- Roox -- Yim Mod Menu ] " ------------------------------------------------------
-------------------------------------------------------" [  GTAO v1.69 - v3274 ] " ------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------------------------------------
RKing = gui.get_tab("Recovery X v1.69")
-----------------------------------------------------------------------------------------------------------------------------
gui.show_message("Recovery King X", " By Offline Mods ")   
RKing:add_text("        Recovery King X Script ")
RKing:add_text("                Version 4.2 ")

function Teleport(Text, x, y, z)
  if ImGui.Button(Text) then
     script.run_in_fiber(function(script)
                PED.SET_PED_COORDS_KEEP_VEHICLE(PLAYER.PLAYER_PED_ID(), x, y, z)
     end)
  end
end
function spawn_car(Hash)
  script.run_in_fiber(function (rr)
    if not STREAMING.IS_MODEL_IN_CDIMAGE(Hash) then return end
    STREAMING.REQUEST_MODEL(Hash)
   while not STREAMING.HAS_MODEL_LOADED(Hash) do
     rr:yield()
    end
    local Ped = PLAYER.PLAYER_PED_ID()
    local coords = ENTITY.GET_ENTITY_COORDS(Ped, true)
    local spcar = VEHICLE.CREATE_VEHICLE(Hash, coords.x, coords.y-3, coords.z, ENTITY.GET_ENTITY_HEADING(Ped+1), true, false, false)
    VEHICLE.SET_VEHICLE_IS_STOLEN(spcar, false)
    PED.SET_PED_INTO_VEHICLE(Ped, spcar, -1)
    DECORATOR.DECOR_SET_INT(spcar, "MPBitset", 0)
 
    local network = NETWORK.VEH_TO_NET(spcar)
    if NETWORK.NETWORK_GET_ENTITY_IS_NETWORKED(spcar) then
      NETWORK.SET_NETWORK_ID_EXISTS_ON_ALL_MACHINES(network, true)
    end
    spcar = PLAYER.GET_PLAYERS_LAST_VEHICLE()
    VEHICLE.DELETE_VEHICLE(spcar);
    rr:sleep(3000)
 
    STREAMING.SET_MODEL_AS_NO_LONGER_NEEDED(Hash)
    ENTITY.SET_ENTITY_AS_NO_LONGER_NEEDED(spcar)
 end)
end

 function spawn(Text, Hash)
  if ImGui.Button(Text) then
    script.run_in_fiber(function(script)
      spawn_car(Hash)
    end)
  end
end

function reg_mod(hash)
  script.run_in_fiber(function (rr)
    STREAMING.REQUEST_MODEL(hash)
    if STREAMING.HAS_MODEL_LOADED(hash) == false then  
      rr:yield() STREAMING.REQUEST_MODEL(hash)
    end
  end)
 end


MPX = King King = stats.get_int("MPPLY_LAST_MP_CHAR")
if King == 0 then
   MPX = "MP0_" else MPX = "MP1_"
end

checkbox = false
King_2 = MPX .. "CLUB_PAY_TIME_LEFT"
King_1 = MPX .. "CLUB_POPULARITY"
   

RKing:add_imgui(function()

----------------------------------------------------------------------------------------------------------------------------

if ImGui.BeginMenu("Self") then 
if ImGui.BeginMenu("Fast Run") then 
ImGui.BulletText("          How to use !!")
ImGui.BulletText("( 1 ) Click on ( Fast Run on )")
ImGui.BulletText("( 2 ) Change the server ")
ImGui.BulletText(" To return to normal mode, click on")
ImGui.BulletText("       ( Fast Run Off )")
ImGui.BulletText("    ** Use at your own risk **")

if ImGui.Button("Fast Run (On / OFF )") then script.run_in_fiber(function(script)
stats.set_int(MPX .. "CHAR_ABILITY_1_UNLCK", -1)
stats.set_int(MPX .. "CHAR_ABILITY_2_UNLCK", -1)
stats.set_int(MPX .. "CHAR_ABILITY_3_UNLCK", -1)
stats.set_int(MPX .. "CHAR_FM_ABILITY_1_UNLCK", -1)
stats.set_int(MPX .. "CHAR_FM_ABILITY_2_UNLCK", -1)
stats.set_int(MPX .. "CHAR_FM_ABILITY_3_UNLCK", -1)
end)end

ImGui.EndMenu()end

if ImGui.Button("Full Inventory + Armour") then script.run_in_fiber(function(script)
stats.set_int(MPX .. "NO_BOUGHT_YUM_SNACKS", 30)
stats.set_int(MPX .. "NO_BOUGHT_HEALTH_SNACKS", 15)
stats.set_int(MPX .. "NO_BOUGHT_EPIC_SNACKS", 5)
stats.set_int(MPX .. "NUMBER_OF_CHAMP_BOUGHT", 5)
stats.set_int(MPX .. "NUMBER_OF_ORANGE_BOUGHT", 11)
stats.set_int(MPX .. "NUMBER_OF_BOURGE_BOUGHT", 10)
stats.set_int(MPX .. "CIGARETTES_BOUGHT", 20)
stats.set_int(MPX .. "MP_CHAR_ARMOUR_1_COUNT", 10)
stats.set_int(MPX .. "MP_CHAR_ARMOUR_2_COUNT", 10)
stats.set_int(MPX .. "MP_CHAR_ARMOUR_3_COUNT", 10)
stats.set_int(MPX .. "MP_CHAR_ARMOUR_4_COUNT", 10)
stats.set_int(MPX .. "MP_CHAR_ARMOUR_5_COUNT", 10)
stats.set_int(MPX .. "BREATHING_APPAR_BOUGHT", 20)    
end)end
if ImGui.Button("Fullx1000 Inventory + Armour") then script.run_in_fiber(function(script)
stats.set_int(MPX .. "NO_BOUGHT_YUM_SNACKS", 1000)
stats.set_int(MPX .. "NO_BOUGHT_HEALTH_SNACKS", 1000)
stats.set_int(MPX .. "NO_BOUGHT_EPIC_SNACKS", 1000)
stats.set_int(MPX .. "NUMBER_OF_CHAMP_BOUGHT", 1000)
stats.set_int(MPX .. "NUMBER_OF_ORANGE_BOUGHT", 1000)
stats.set_int(MPX .. "NUMBER_OF_BOURGE_BOUGHT", 1000)
stats.set_int(MPX .. "CIGARETTES_BOUGHT", 1000)
stats.set_int(MPX .. "MP_CHAR_ARMOUR_1_COUNT", 1000)
stats.set_int(MPX .. "MP_CHAR_ARMOUR_2_COUNT", 1000)
stats.set_int(MPX .. "MP_CHAR_ARMOUR_3_COUNT", 1000)
stats.set_int(MPX .. "MP_CHAR_ARMOUR_4_COUNT", 1000)
stats.set_int(MPX .. "MP_CHAR_ARMOUR_5_COUNT", 1000)
stats.set_int(MPX .. "BREATHING_APPAR_BOUGHT", 1000)
end)end

ImGui.EndMenu()end

if ImGui.BeginMenu("Player Online ( Risk! )") then

  ImGui.BulletText("                                    How to use !!")
  ImGui.BulletText("       In order to be able to drop players in the server, ")
  ImGui.BulletText("          you must first click on the player's name,")
  ImGui.BulletText("then from the Recovery script choose what you want to drop.")
  ImGui.BulletText("                            Used at your own risk!!")

  drmoney, Toggled1 = ImGui.Checkbox("Drop Money", drmoney)
  drcard, Toggled2 = ImGui.Checkbox("Drop Card", drcard)
  drpogofig, Toggled3 = ImGui.Checkbox("Drop Pogo Figures", drpogofig)
  drhealth, Toggled4 = ImGui.Checkbox("Drop Health", drhealth)
  drarmor, Toggled5 = ImGui.Checkbox("Drop Armor", drarmor)  


  script.register_looped("dropoption", function(rr)
    if drmoney then
        local plr = PLAYER.GET_PLAYER_PED(network.get_selected_player())
        local coords = ENTITY.GET_ENTITY_COORDS(plr, false)
        reg_mod(2628187989)
        OBJECT.CREATE_AMBIENT_PICKUP(1704231442, coords.x, coords.y, coords.z + 3, 0, 2000, 2628187989, false, true)
        rr:sleep(1 * 500)
    end
    if drcard then
        local plr = PLAYER.GET_PLAYER_PED(network.get_selected_player())
        local coords = ENTITY.GET_ENTITY_COORDS(plr, false)
        reg_mod(3030532197)
        OBJECT.CREATE_AMBIENT_PICKUP(0x2C014CA6, coords.x, coords.y, coords.z + 3, 0, 1000, 3030532197, false, true)
        rr:sleep(1 * 500)
    end
    if drpogofig then
        local plr = PLAYER.GET_PLAYER_PED(network.get_selected_player())
        local coords = ENTITY.GET_ENTITY_COORDS(plr, false)
        reg_mod(1025210927)
        OBJECT.CREATE_AMBIENT_PICKUP(0x2C014CA6, coords.x, coords.y, coords.z + 3, 0, 1000, 1025210927, false, true)
        rr:sleep(1 * 500)
    end
    if drhealth then
        local plr = PLAYER.GET_PLAYER_PED(network.get_selected_player())
        local coords = ENTITY.GET_ENTITY_COORDS(plr, false)
        reg_mod(678958360)
        OBJECT.CREATE_AMBIENT_PICKUP(2406513688, coords.x, coords.y, coords.z + 3, 0, 1000, 678958360, false, true)
        rr:sleep(1 * 500)
    end
    if drarmor then
        local plr = PLAYER.GET_PLAYER_PED(network.get_selected_player())
        local coords = ENTITY.GET_ENTITY_COORDS(plr, false)
        reg_mod(701173564)
        OBJECT.CREATE_AMBIENT_PICKUP(1274757841, coords.x, coords.y, coords.z + 3, 0, 1000, 701173564, false, true)
        rr:sleep(1 * 500)
    end
end)

ImGui.BulletText("      The condition is serious and not recommended!.")


ImGui.EndMenu()end

  

-----------------------------------------------------------------------------------------------------------------------------
if ImGui.BeginMenu("Vehicle Spawner") then  

if ImGui.BeginMenu("All DLC Vehicles") then
  if ImGui.BeginMenu("Bottom Dollar Bounties") then 
    spawn("Burrito (Bail Enforcement) ", -1444856003)
    spawn("Castigator", 1307736079)
    spawn("Coquette D1", -1958428933)
    spawn("Cypher ", 258105345)
    spawn("Dominator FX ", 1579902654)
    spawn("Dominator FX Interceptor ", -773802025)
    spawn("Dorado Cruiser", -1628000569)
    spawn("Envisage", 1121330119)
    spawn("Euros X32 HSW ", -999594302)
    spawn("Euros X32 ", -999594302)
    spawn("Greenwood Cruiser", 1737348074)
    spawn("Impaler LX Cruiser", 1452003510)
    spawn("Impaler SZ Cruiser ", 1249425552)
    spawn("Nebula Turbo Drift ", 1690421418)
    spawn("Niobe HSW", 1881415402)
    spawn("Niobe", 1881415402)
    spawn("Paragon S", -946047670)
    spawn("Pipistrello", -223461503)
    spawn("Pizza Boy", 1968807591)
    spawn("Sentinel Classic Widebody Drift", -986656474)
    spawn("PVorschlaghammer Drift", -143587026)
    spawn("Vorschlaghammer", -1240172147)
    spawn("Yosemite 1500", -1896488056)

ImGui.EndMenu() end

if ImGui.BeginMenu("Chop Shop") then 
      spawn("Aleutian ", -38879449)
      spawn("Asterope GZ", -741120335)
      spawn("Baller ST-D", -863358884)
      spawn("Benson (Cluckin' Bell)", -728350375)
      spawn("Boat Trailer", -1835260592)
      spawn("Boat Trailer 2", 1539159908)
      spawn("Boxville (LSDS) ", -842765535)
      spawn("BCavalcade XL ", -1029730482)
      spawn("Dominator GT", -441209695)
      spawn("Dorado", -768044142)
      spawn("Drift Tampa (Drift)", -1696319096)
      spawn("Drift Yosemite (Drift)", -1681653521)
      spawn("Euros (Drift) ", 821121576)
      spawn("FR36 (Drift) ", -1479935577)
      spawn("FR36 ", -465825307)
      spawn("Freight Train  ", -442229240)
      spawn("Futo GTX (Drift) ", -181562642)
      spawn("Gauntlet Interceptor ", -1233767450)
      spawn("Impaler LX", -178442374)
      spawn("Impaler SZ", -478639183)
      spawn("Jester RR (Drift)", -1763273939)
      spawn("Phantom (Christmas)", -129283887)
      spawn("Trailer (Christmas) ", -1334453816)
      spawn("Remus (Drift)", -1624083468)
      spawn("Stanier LE Cruiser", -1674384553)
      spawn("Terminus", 167522317)
      spawn("Towtruck", -902029319)
      spawn("Towtruck (Beater) ", -671564942)
      spawn("Trailer ", 471034616)
      spawn("Turismo Omaggio", -122993285)
      spawn("Vigero ZX Convertible ", 372621319)
      spawn("Vivanite ", -1372798934)
      spawn("ZR350 ", 1923534526)
ImGui.EndMenu() end
if ImGui.BeginMenu ("San Andreas Mercenaries ") then
        spawn("Aenger ",-426933872)
        spawn("Brigham",-654498607)
        spawn("Buffalo EX ",165968051)
        spawn("Clique Wagon ",-979292575)
        spawn("Weaponized Conada ",-1659004814)
        spawn("La Coureuse ",610429990)
        spawn("Hotring Hellfire ",1336514315)
        spawn("Inductor ",-897824023)
        spawn("Junk Energy Inductor ",-1983622024)
        spawn("Walton L35 ",-1763675285)
        spawn("MonstroCiti ",802856453)
        spawn("F-160 Raiju ",239897677)
        spawn("Ratel ",-536105557)
        spawn("Speedo Custom  ",-44799464)
        spawn("Itali GTO Stinger TT ",1447690049)
        spawn("Streamer216 ",191916658)
 ImGui.EndMenu() end
 if ImGui.BeginMenu ("Los Santos Drug Wars") then
        spawn("igero2",996383885)
        spawn("Drickade 6x6",-1576586413)
        spawn("Eudora",-1933242328)
        spawn("Hotring Eeron",-1958189855)
        spawn("lssi Rally",1748565021)
        spawn("Journey ll",-1249788006)
        spawn("Manchez ScoutC",-131348178)
        spawn("Panthere",1550581940)
        spawn("Powersurge",-1627077503)
        spawn("300R",1384502824)
        spawn("Surfer Custom",-1035489563)
        spawn("Tahoma Coupe",-461850249)
        spawn("Tulip M-100",268758436)
        spawn("irtue",669204833)
ImGui.EndMenu() end
if ImGui.BeginMenu ("Criminal Enterprises") then  
        spawn("igero2",-1758379524)
        spawn("Sm722",775514032)
        spawn("Omnisegt",-505223465)
        spawn("Conada",-477831899)
        spawn("Ruiner4",1706945532)
        spawn("Brioso3",15214558)
        spawn("Corsita",-754687673)
        spawn("Draugur",-768236378)
        spawn("Kanjosj",-64075878)
        spawn("Postlude",-294678663)
        spawn("Torero2",-165394758)
        spawn("Lm87",-10917683)
        spawn("Tenf",-893984159)
        spawn("Rhinehart",-1855505138)
        spawn("Weeil2",-994371320)
        spawn("Greenwood",40817712)
ImGui.EndMenu() end
if ImGui.BeginMenu ("The Contrect") then
        spawn("igero2",629969764)
        spawn("Baller ST ",359875117)
        spawn("Buffalo STX ",-619930876)
        spawn("Champion ",-915234475)
        spawn("Cinquemila ",-1527436269)
        spawn("ComeT S2 Cabrio ",1141395928)
        spawn("Deity ",1532171089)
        spawn("Granger 3600LX ",-261346873)
        spawn("lgnus ",-1444114309)
        spawn("l-Wagen ",662793086)
        spawn("Jubilee ",461465043)
        spawn("Mule ",1343932732)
        spawn("Patriot ",-670086588)
        spawn("Reeet ",1993851908)
        spawn("Shinobi ",1353120668)
        spawn("Youga ",1486521356)
        spawn("Zeno ",655665811)
ImGui.EndMenu() end
if ImGui.BeginMenu ("Los Santos Tuners ") then
        spawn("Cailco GTF ",-1193912403)
        spawn("Comet S2 ",-1726022652)
        spawn("Cypher ",1755697647)
        spawn("Dominator ASP ",426742808)
        spawn("Dominator GTT ",736672010)
        spawn("Euros ",203848341)
        spawn("Futo GTX ",-1507230520)
        spawn("Growler ",1304459735)
        spawn("Jester RR ",-1582061455)
        spawn("Preion ",1416471345)
        spawn("Remus ",1377217886)
        spawn("RT3000 ",-452604007)
        spawn("Sultan RS Classic ",-291021213)
        spawn("Tailgater S ",-1244461404)
        spawn("ectre ",-1540373595)
        spawn("Warrener HKR ",579912970)
        spawn("ZR350 ",-1858654120)
ImGui.EndMenu() end
if ImGui.BeginMenu ("Cayo Perico Heist ") then
        spawn("Itali RSX ",-1149725334)
        spawn("Brioso 300 ",1429622905)
        spawn("Aisa ",-1706603682)
        spawn("Annihilator Stealth ",295054921)
        spawn("Manchez Scout ",1086534307)
        spawn("Longfin ",1861786828)
        spawn("Kurtz 31 Patrol Boat ",-276744698)
        spawn("Kosatka ",1336872304)
        spawn("Sparrow",1229411063)
        spawn("Sparrow  ",1593933419)
        spawn("Slamtruck ",-1045911276)
        spawn("RO-86 Alkonost ",-365873403)
        spawn("etir ",2014313426)
        spawn("Toreador ",1455990255)
        spawn("Squaddie ",-102335483)
        spawn("Weeil ",1644055914)
        spawn("Weaponized Dinghy",-980573366)
        spawn("eto Modern ",-1492917079)
        spawn("eto Classic",-857356038)
        spawn("Winky",-210308634)
ImGui.EndMenu() end
if ImGui.BeginMenu ("Los Santos Summer Special ") then
        spawn("Coquette D10 ",-1728685474)
        spawn("Club ",-2098954619)
        spawn("BR8 ",1492612435)
        spawn("Beater Dukes ",2134119907)
        spawn("Landstalker XL ",-838099166)
        spawn("Glendale Custom ",-913589546)
        spawn("Gauntlet Classic Custom ",-2122646867)
        spawn("DR1 ",1181339704)
        spawn("Seminole Frontier ",-1810806490)
        spawn("Peyote Custom ",1107404867)
        spawn("Penumbra FF  ",-631322662)
        spawn("Manana Custom ",1717532765)
        spawn("Tigon ",-1358197432)
        spawn("Yosemite Rancher ",67753863)
        spawn("Youga Classic 4x4 ",1802742206)
ImGui.EndMenu() end
if ImGui.BeginMenu ("Diamond Casino - Heist ") then
        spawn("Eeron ",-1756021720)
        spawn("Drift Yosemite ",1693751655)
        spawn("Blista Kanjo ",409049982)
        spawn("Asbo ",1118611807)
        spawn("JB 700W ",394110044)
        spawn("Inade and Persuade Tank ",-1254331310)
        spawn("Imorgon",-1132721664)
        spawn("Furia ",960812448)
        spawn("R88",-1960756985)
        spawn("PR4  ",340154634)
        spawn("Outlaw ",408825843)
        spawn("Komoda ",-834353991)
        spawn("Sugoi ",987469656)
        spawn("Stryder ",301304410)
        spawn("Retinue Mk II ",2031587082)
        spawn("Rebla GTS ",83136452)
        spawn("Zhaba",1284356689)
        spawn("agrant ",740289177)
        spawn("-STR ",1456336509)
        spawn("Sultan Classic",872704284)
ImGui.EndMenu() end
if ImGui.BeginMenu ("Diamond Casino - Resort ") then
        spawn("Emerus ",1323778901)
        spawn("Dynasty ",310284501)
        spawn("Caracara 4x4 ",-1349095620)
        spawn("8F Drafter ",686471183)
        spawn("Issi Sport ",1854776567)
        spawn("Hellion",-362150785)
        spawn("Gauntlet Hellfire",1934384720)
        spawn("Gauntlet Classic ",722226637)
        spawn("Nebula Turbo",-882629065)
        spawn("Locust  ",-941272559)
        spawn("Krieger ",-664141241)
        spawn("Jugular ",-208911803)
        spawn("Paragon R (Armored) ",1416466158)
        spawn("Paragon R ",-447711397)
        spawn("Noak ",-1829436850)
        spawn("Neo ",-1620126302)
        spawn("Thrax",1044193113)
        spawn("S80RR ",-324618589)
        spawn("Rampant Rocket ",916547552)
        spawn("Peyote Gasser",-1804415708)
        spawn("Zorrusso",-682108547)
        spawn("Zion Classic",1862507111)
ImGui.EndMenu() end
if ImGui.BeginMenu ("Arena War")  then
        spawn("Apocalypse Bruiser ",668439077)
        spawn("Apocalypse Brutus ",2139203625)
        spawn("Apocalypse Cerberus ",-801550069)
        spawn("Apocalypse Deathbike",-27326686)
        spawn("Apocalypse Dominator ",-688189648)
        spawn("Apocalypse Impaler",1009171724)
        spawn("Apocalypse Imperator",444994115)
        spawn("Apocalypse Issi",628003514)
        spawn("Apocalypse Sasquatch",1721676810)
        spawn("Apocalypse Scarab  ",-1146969353)
        spawn("Apocalypse Slaman",-2061049099)
        spawn("Apocalypse ZR380 ",540101442)
        spawn("Clique ",-1566607184)
        spawn("Deeste Eight ",1591739866)
        spawn("Deiant ",1279262537)
        spawn("Future Shock Bruiser ",-1694081890)
        spawn("Future Shock Brutus",-1890996696)
        spawn("Future Shock Cerberus ",679453769)
        spawn("Future Shock Deathbike ",-1812949672)
        spawn("Future Shock Dominator",-1375060657)
        spawn("Future Shock Impaler",-1924800695)
        spawn("Future Shock Imperator",1637620610)
        spawn("Future Shock Issi",1537277726)
        spawn("Future Shock Sasquatch",840387324)
        spawn("Future Shock Scarab",1542143200)
        spawn("Future Shock Slaman",373261600)
        spawn("Future Shock ZR380",-1106120762)
        spawn("Impaler",-2096690334)
        spawn("Itali GTO",-331467772)
        spawn("Nightmare Bruiser",-2042350822)
        spawn("Nightmare Brutus",2038858402)
        spawn("Nightmare Cerberus",1909700336)
        spawn("Nightmare Deathbike",-1374500452)
        spawn("Nightmare Dominator",-1293924613)
        spawn("Nightmare Impaler",-1744505657)
        spawn("Nightmare Imperator",-755532233)
        spawn("Nightmare Issi",1239571361)
        spawn("Nightmare Sasquatch",-715746948)
        spawn("Nightmare Scarab",-579747861)
        spawn("Nightmare Slaman",1742022738)
        spawn("Nightmare ZR380",-1478704292)
        spawn("RC Bandito",-286046740)
        spawn("Schlagen GT",-507495760)
        spawn("Taxi Custom",-956048545)
        spawn("Toros",-1168952148)
        spawn("Tulip",1456744817)
        spawn("amos",-49115651)
ImGui.EndMenu() end
if ImGui.BeginMenu ("After Hours")  then
        spawn("B-11 Strikeforce ",1692272545)
        spawn("Blimp ",-307958377)
        spawn("Festial Bus ",345756458)
        spawn("Freecrawler ",-54332285)
        spawn("Jester Classic ",-214906006)
        spawn("Menacer",2044532910)
        spawn("Mule Custom",1945374990)
        spawn("Oppressor Mk II ",2069146067)
        spawn("Patriot Stretch",-420911112)
        spawn("Pounder Custom  ",1653666139)
        spawn("Scramjet ",-638562243)
        spawn("Speedo Custom  ",219613597)
        spawn("Stafford ",321186144)
        spawn("Swinger ",500482303)
        spawn("Terrorbyte ",-1988428699)
ImGui.EndMenu() end
if ImGui.BeginMenu ("Southern SA Super Sport Series ") then
        spawn("Caracara ",1254014755)
        spawn("Cheburek ",-988501280)
        spawn("Dominator GTX ",-986944621)
        spawn("Ellie ",-1267543371)
        spawn("Entity XXR ",-2120700196)
        spawn("Fagaloa",1617472902)
        spawn("Flash GT",-1259134696)
        spawn("GB200 ",1909189272)
        spawn("Hotring Sabre",1115909093)
        spawn("Issi Classic ",931280609)
        spawn("Michelli GT ",1046206681)
        spawn("Sea Sparrow  ",-726768679)
        spawn("Taipan ",-1134706562)
        spawn("Tezeract ",1031562256)
        spawn("Tyrant ",-376434238)
ImGui.EndMenu() end
if ImGui.BeginMenu ("The Doomsday Heist ") then
        spawn("190z ",838982985)
        spawn("Akula ",1181327175)
        spawn("Autarch ",-313185164)
        spawn("Aenger  ",408970549)
        spawn("Aenger2 ",-2118308144)
        spawn("Barrage",-212993243)
        spawn("Chernobog",-692292317)
        spawn("Comet Safari ",1561920505)
        spawn("Comet SR",661493923)
        spawn("Deluxo ",1483171323)
        spawn("GT500 ",-2079788230)
        spawn("Hermes  ",15219735)
        spawn("Hustler ",600450546)
        spawn("Neon ",-1848994066)
        spawn("Pariah ",867799010)
        spawn("Raiden  ",-1529242755)
        spawn("RC ",-1693015116)
        spawn("Reolter ",-410205223)
        spawn("Riata ",-1532697517)
        spawn("Saestra  ",903794909)
        spawn("SC1 ",1352136073)
        spawn("Sentinel Classic ",1104234922)
        spawn("Streiter ",1741861769)
        spawn("Stromberg ",886810209)
        spawn("Thruster ",1489874736)
        spawn("TM-02 Khanjali",-1435527158)
        spawn("iseris ",-391595372)
        spawn("olatol",447548909)
        spawn("Yosemite ",1871995513)
ImGui.EndMenu() end
if ImGui.BeginMenu ("Smuggler's Run ") then
        spawn("Alpha-Z1 ",-1523619738)
        spawn("Cyclone ",1392481335)
        spawn("FH-1 Hunter ",-42959138)
        spawn("Haok  ",-1984275979)
        spawn("Howard NX-25 ",-1007528109)
        spawn("LF-22 Starling",-1700874274)
        spawn("Mogul",-749299473)
        spawn("P-45 Nokota",1036591958)
        spawn("Pyro",-1386191424)
        spawn("Rapid GT Classic ",2049897956)
        spawn("Retinue ",1841130506)
        spawn("RM-10 Bombushka  ",-32878452)
        spawn("Rogue ",-975345305)
        spawn("Seabreeze ",-392675425)
        spawn("Tula ",1043222410)
        spawn("Ultralight  ",-1763555241)
        spawn("-65 Molotok ",1565978651)
        spawn("igilante ",-1242608589)
        spawn("isione ",-998177792)
 ImGui.EndMenu() end
 if ImGui.BeginMenu ("Gunrunning") then
        spawn("Anti-Aircraft Trailer ",-1881846085)
        spawn("APC ",562680400)
        spawn("Ardent",159274291)
        spawn("Caddy ",-769147461)
        spawn("Cheetah Classic",223240013)
        spawn("Dune FA",1897744184)
        spawn("Half-track",-32236122)
        spawn("Hauler Custom",387748548)
        spawn("Insurgent Pick-Up Custom",-1924433270)
        spawn("Mobile Operations Center",1502869817)
        spawn("Nightshark ",433954513)
        spawn("Oppressor ",884483972)
        spawn("Phantom Custom ",177270108)
        spawn("Technical Custom ",1356124575)
        spawn("Torero ",1504306544)
        spawn("Ultralight  ",-1763555241)
        spawn("Trailer  ",-1100548694)
        spawn("agner ",1939284556)
        spawn("Weaponized Tampa",-1210451983)
        spawn("XA-21",917809321)
ImGui.EndMenu() end
 if ImGui.BeginMenu ("Cunning Stunts: S Circuit") then
        spawn("GP1 ",1234311532)
        spawn("Infernus Classic",-1405937764)
        spawn("Ruston",719660200)
        spawn("Turismo Classic ",-982130927)
ImGui.EndMenu()end
 if ImGui.BeginMenu ("Import/Export ") then
        spawn("Armored Boxille ",682434785)
        spawn("Blazer Aqua",-1590337689)
        spawn("Comet Retro Custom",-2022483795)
        spawn("Diabolus ",-239841468)
        spawn("Diabolus Custom ",1790834270)
        spawn("Elegy Retro Custom",196747873)
        spawn("FCR 1000 ",627535535)
        spawn("FCR 1000 Custom",-757735410)
        spawn("Itali GTB ",-2048333973)
        spawn("Itali GTB Custom",-482719877)
        spawn("Nero ",1034187331)
        spawn("Nero Custom",1093792632)
        spawn("Penetrator ",-1758137366)
        spawn("Phantom Wedge",-1649536104)
        spawn("Ramp Buggy ",-827162039)
        spawn("Ramp Buggy 2",-312295511)
        spawn("Rocket oltic ",989294410)
        spawn("Ruiner ",777714999)
        spawn("Ruiner 2000 ",941494461)
        spawn("Specter",1886268224)
        spawn("Specter Custom ",1074745671)
        spawn("Technical Aqua ",1180875963)
        spawn("Tempesta ",272929391)
        spawn("Wastelander",-1912017790)
ImGui.EndMenu() end
 if ImGui.BeginMenu ("Bikers") then
        spawn("Aarus",-2115793025)
        spawn("Chimera",6774487)
        spawn("Daemon ",-1404136503)
        spawn("Defiler ",822018448)
        spawn("Esskey ",2035069708)
        spawn("Faggio Mod",-1289178744)
        spawn("Faggio Sport ",-1842748181)
        spawn("Hakuchou Drag",-255678177)
        spawn("Manchez ",-1523428744)
        spawn("Nightblade",-1606187161)
        spawn("Raptor ",-674927303)
        spawn("Rat Bike",1873600305)
        spawn("Sanctus ",1491277511)
        spawn("Shotaro",-405626514)
        spawn("Street Blazer ",-440768424)
        spawn("Tornado Rat Rod",-1558399629)
        spawn("ortex",-609625092)
        spawn("Wolfsbane ",-618617997)
        spawn("Youga Classic ",1026149675)
        spawn("Zombie Bobber",-1009268949)
        spawn("Zombie Chopper ",-570033273)
ImGui.EndMenu() end
if ImGui.BeginMenu ("Cunning Stunts ") then
        spawn("BF400 ",86520421)
        spawn("Brioso R/A",1549126457)
        spawn("Cliffhanger ",390201602)
        spawn("Contender ",683047626)
        spawn("Desert Raid",-663299102)
        spawn("Drift Tampa",-1071380347)
        spawn("Dune ",-2103821244)
        spawn("ETR1 ",819197656)
        spawn("Gargoyle ",741090084)
        spawn("Lynx ",482197771)
        spawn("Omnis ",-777172681)
        spawn("RE-7B",-1232836011)
        spawn("Trophy Truck",101905590)
        spawn("Tropos Rallye",1887331236)
        spawn("Tyrus",2067820283)
ImGui.EndMenu() end
if ImGui.BeginMenu ("Finance and Felony ") then
        spawn("811 ",-1829802492)
        spawn("Bestia GTS",1274868363)
        spawn("Brickade ",-305727417)
        spawn("FMJ ",1426219628)
        spawn("Nimbus",-1295027632)
        spawn("Reaper",234062309)
        spawn("Rumpo Custom",1475773103)
        spawn("Seen-70",-1757836725)
        spawn("Tug ",-1845487887)
        spawn("olatus ",482197771)
        spawn("Windsor Drop",-1930048799)
        spawn("X80 Proto",2123327359)
        spawn("XLS",1203490606)
        spawn("XLS (Armored)",-432008408)
ImGui.EndMenu() end
if ImGui.BeginMenu ("Custom Classics ") then
        spawn("Faction Custom Donk",-2039755226)
        spawn("Minian Custom",-1126264336)
        spawn("Sabre Turbo Custom",223258115)
        spawn("Slaman Custom",1119641113)
        spawn("Tornado Custom",-1797613329)
        spawn("irgo Classic",16646064)
        spawn("irgo Classic Custom",-899509638)
ImGui.EndMenu() end
if ImGui.BeginMenu ("Be My alentine ") then
        spawn("Rooseelt alor",-602287871)
 ImGui.EndMenu() end
if ImGui.BeginMenu ("January 2016") then
        spawn("Banshee 900R",633712403)
        spawn("Sultan RS",-295689028)
ImGui.EndMenu() end
if ImGui.BeginMenu ("Festie Surprise 2015 ") then
        spawn("Tampa",972671128 )
ImGui.EndMenu() end
if ImGui.BeginMenu ("Executies and Criminals ") then
        spawn("Baller LE",1878062887)
        spawn("Baller LE (Armored)",470404958)
        spawn("Baller LE LWB",634118882)
        spawn("Baller LE LWB (Armored)",666166960)
        spawn("Cargobob ",2025593404)
        spawn("Cognoscenti ",-2030171296)
        spawn("Cognoscenti 55",906642318)
        spawn("Cognoscenti 55 (Armored)",704435172)
        spawn("Cognoscenti (Armored)",-604842630)
        spawn("Dinghy ",867467158)
        spawn("Mamba ",-1660945322)
        spawn("Nightshade ",-1943285540)
        spawn("Schafter LWB",1489967196)
        spawn("Schafter LWB (Armored)",1922255844)
        spawn("Schafter 12",-1485523546)
        spawn("Schafter 12 (Armored)",-888242983)
        spawn("Seashark ",-311022263)
        spawn("Speeder ",437538602)
        spawn("Superolito ",710198397)
        spawn("Superolito Carbon",-1671539132)
        spawn("Toro ",908897389)
        spawn("Tropic  ",1448677353)
        spawn("Turreted Limo",-114627507)
        spawn("alkyrie MOD.0",1543134283)
        spawn("erlierer",1102544804)
ImGui.EndMenu() end
if ImGui.BeginMenu ("Halloween Surprise ") then
        spawn("Fränken Stange ",-831834716)
        spawn("Lurcher ",2068293287)
ImGui.EndMenu()end
if ImGui.BeginMenu ("Lowriders ") then
        spawn("Fränken Stange ",-831834716)
        spawn("Lurcher ",2068293287)
ImGui.EndMenu() end
if ImGui.BeginMenu ("III Gotten Gains 2 ") then
        spawn("Brawler ",-1479664699)
        spawn("Chino ",349605904)
        spawn("Coquette BlackFin",784565758)
        spawn("T20 ",1663218586)
        spawn("Toro ",1070967343)
        spawn("indicator ",-1353081087)
ImGui.EndMenu() end
if ImGui.BeginMenu ("III Gotten Gains 1 ") then
        spawn("Luxor Deluxe",-1214293858)
        spawn("Osiris ",1987142870)
        spawn("Stirling GT",-1566741232)
        spawn("irgo ",-498054846)
        spawn("Windsor ",1581459400)
        spawn("Swift Deluxe",1075432268)
ImGui.EndMenu() end
if ImGui.BeginMenu ("Heists ") then
        spawn("Barracks ",630371791)
        spawn("Boxille  ",444171386)
        spawn("Casco",941800958)
        spawn("Dinghy  ",509498602)
        spawn("Enduro ",1753414259)
        spawn("Gang Burrito",296357396)
        spawn("Guardian",-2107990196)
        spawn("Hydra",970385471)
        spawn("Insurgent",2071877360)
        spawn("Insurgent Pick-Up",-1860900134)
        spawn("Kuruma",-1372848492)
        spawn("Kuruma (Armored)",410882957)
        spawn("Lectro",640818791)
        spawn("Lost Slaman",833469436)
        spawn("Mule ",-2052737935)
        spawn("Saage ",-82626025)
        spawn("fuel tank ",1956216962)
        spawn("Technical",-2096818938)
        spawn("Trashmaster ",-1255698084)
        spawn("alkyrie ",-1600252419)
        spawn("elum 5-Seater ",1077420264)
 ImGui.EndMenu() end
if ImGui.BeginMenu ("Festie Surprise 2014 ") then
        spawn("Jester (Racecar) ",-1106353882)
        spawn("Massacro (Racecar)",-631760477)
        spawn("Rat-Truck",-589178377)
        spawn("Slaman  ",729783779)
ImGui.EndMenu() end
        
        if ImGui.BeginMenu ("Enhanced Edition ") then
        spawn("Blista Compact",1039032026)
        spawn("Burger Shot Stallion)",-401643538)
        spawn("Dodo",-901163259)
        spawn("Duke O'Death  ",-326143852)
        spawn("Dukes ",723973206)
        spawn("Go Go Monkey Blista ",-591651781)
        spawn("Kraken",-1066334226)
        spawn("Marshall",1233534620)
        spawn("Pisswasser Dominator",-915704871)
        spawn("Redwood Gauntlet",349315417)
        spawn("Sprunk Buffalo",237764926)
        spawn("Stallion",1923400478)
        spawn("Xero Blimp",-613725916)
        ImGui.EndMenu()
        end
        
        if ImGui.BeginMenu ("Last Team Standing") then
        spawn("Furore GT",-1089039904)
        spawn("Hakuchou",1265391242)
        spawn("Innoation",-159126838)
        ImGui.EndMenu()
        end
        
        if ImGui.BeginMenu ("SA Flight School") then
        spawn("Besra",1824333165)
        spawn("Coquette Classic",1011753235)
        spawn("Miljet",165154707)
        spawn("Swift",-339587598)
        ImGui.EndMenu()
        end
        
        if ImGui.BeginMenu ("lndependence Day") then
        spawn("Liberator",-845961253)
        spawn("Soereign",743478836)
        ImGui.EndMenu()
        end
        
        if ImGui.BeginMenu ("l'm Not A Hipster") then
        spawn("Blade",-1205801634)
        spawn("Dubsta 6x6",-1237253773)
        spawn("Glendale",75131841)
        spawn("Panto",-431692672)
        spawn("Pigalle",1078682497)
        spawn("Rhapsody",841808271)
        spawn("Warrener",1373123368)
        ImGui.EndMenu()
        end
        
        if ImGui.BeginMenu ("High Life") then
        spawn("Huntley S ",486987393)
        spawn("Massacro ",-142942670)
        spawn("Thrust",1836027715)
        spawn("Zentorno",-1403128555)
        ImGui.EndMenu()
        end
        
        if ImGui.BeginMenu ("Business ") then
        spawn("Alpha ",767087018)
        spawn("Jester ",-1297672541)
        spawn("Turismo R",408192225)
        spawn("estra",1341619767)
        ImGui.EndMenu()
        end
        
        if ImGui.BeginMenu ("alentine's Day Massacre ") then
        spawn("Rooseelt",117401876)
        ImGui.EndMenu()
        end
        
        if ImGui.BeginMenu ("Beach Bum Update")  then
        spawn("Bifta",-349601129)
        spawn("Kalahari",92612664)
        spawn("Paradise",1488164764)
        spawn("Speeder",231083307)
        ImGui.EndMenu()
        end
            ImGui.EndMenu()
 end 
 if ImGui.BeginMenu("Vehicles Removed") then

    spawn("1 Peyote Gasser" ,-1804415708) 
    spawn("2 Zion Classic" ,1862507111) 
    spawn("3 Nebula Turbo" ,-882629065) 
    spawn("4 Vamos",-49115651)
    spawn("5 Futo ",-1507230520)
    spawn("6 Ruiner ",1706945532)
    spawn("7 Romero ",627094268)
    spawn("8 Prairie ",-1450650718)
    spawn("9 Michelli GT ",1046206681)
    spawn("10 Fagaloa ",1617472902)
    spawn("11 Hermes ",15219735)
    spawn("12 Retinue ",2031587082)
    spawn("13 Tornado Rat-Rod ",-1558399629)
    spawn("14 Massacro Racecar ",-631760477)
    spawn("15 Jester Racecar ",-1106353882)
    spawn("16 Pigalle ",1078682497)
    spawn("17 Blade ",-1606187161)
    spawn("18 Picador ",1507916787)
    spawn("19 F620 ",-591610296)
    spawn("20 Fusilade ",499169875)
    spawn("21 Penumbra ",-631322662)
    spawn("22 Sentinel ",873639469)
    spawn("23 Rat-Loader ",-667151410)
    spawn("24 Schwartzer ",-746882698)
    spawn("25 Zion Cabrio ",-1193103848)
    spawn("26 Zion ",-1122289213)
    spawn("27 Gauntlet ",-1800170043)
    spawn("28 Vigero ",-825837129)
    spawn("29 Issi ",-1177863319)
    spawn("30 Seminole Frontier ",-1810806490)
    spawn("31 Dynasty ",310284501)
    spawn("32 Tulip ",1456744817)
    spawn("33 BeeJay XL ",850565707)
    spawn("34 FQ2 ",-1137532101)
    spawn("35 SeRemovedano ",1337041428)
    spawn("36 Habanero ",884422927)
    spawn("37 Cheburek ",-988501280)
    spawn("38 Streiter ",1741861769)
    spawn("39 Franken Stange ",-831834716)
    spawn("40 Jackal ",-624529134)
    spawn("41 Oracle Xs ",1348744438)
    spawn("42 Schafter ",-1255452397)
    spawn("43 Surge ",-1894894188)
    spawn("44 WaRemovedener ",1373123368)
    spawn("45 Regina ",-14495224)
    spawn("46 Buffalo ",-304802106)
    spawn("47 Buffalo S ",736902334)
    spawn("48 Tailgater ",-1008861746)
    spawn("49 Asea ",-1809822327)
    spawn("50 Granger ",-1775728740)
    spawn("51 Rancher XL ",1645267888)
    spawn("52 Ingot ",-1289722222)
    spawn("53 Intruder ",886934177)
    spawn("54 Minivan ",-310465116)
    spawn("55 Premier ",-1883869285)
    spawn("56 Radius ",-1651067813)
    spawn("57 Stanier ",-1477580979)
    spawn("58 Stratum ",1723137093)
    spawn("59 Washington ",1777363799)
    spawn("60 Asterope ",-1903012613)
    spawn("61 Fugitive ",1909141499)
    spawn("62 Dilettante ",-1130810103)
    spawn("63 Hellion ",-362150785)
    spawn("64 Riata ",-1532697517 )
    spawn("65 Seminole ",1221512915 )
    spawn("66 Kalahari ",92612664 )
    spawn("67 Rebel (Clean) ",-1207771834 )
    spawn("68 Sanking SWB ",989381445 )
    spawn("69 Bodhi ",-1435919434 )
    spawn("70 Dune Buggy ",-1661854193 )
    spawn("71 Rebel ",-2045594037 )
    spawn("72 Injection ",1126868326 )
    spawn("73 Bison ",-16948145)
    spawn("74 Landstalker XL ",-838099166)
    spawn("75 Patriot ",-808457413)
    spawn("76 Contender ",683407626)
    spawn("77 Landstalker ",1269098716)
    spawn("78 Gresley ",-1543762099)
    spawn("79 Baller ",-808831384)
    spawn("80 Cavalcade 1 ",2006918058)
    spawn("81 Cavalcade 2 ",-789894171)
    spawn("82 Rocoto ",2136773105)
    spawn("83 Felon GT ",-89291282)
    spawn("84 Felon ",-39154584)
    spawn("85 Oracle ",-511601230)
    spawn("86 Tigon ",-1358197432)
    spawn("87 Imorgon ",-1132721664)
    spawn("88 ZoRemoveduso ",-682108547)
    spawn("89 Locust ",-941272559)
    spawn("90 Neo ",-1620126302)
    spawn("91 Paragon R ",-447711397)
    spawn("92 S80Removed ",-324618589)
    spawn("93 Deviant ",1279262537)
    spawn("94 Swinger ",500482303)
    spawn("95 Comet SR ",661493923)
    spawn("96 Hustler ",600450546)
    spawn("97 190Z ",838982985)
    spawn("98 GT500 ",-2079788230)
    spawn("99 Viseris ",-391595372)
    spawn("100 Savestra ",903794909)
    spawn("101 SC1 ",1352136073)
    spawn("102 Cyclone ",1392481335)
    spawn("103 Rapid GT Classic ",2049897956)
    spawn("104 XA-21 ",917809321)
    spawn("105 Torero ",1504306544)
    spawn("106 Ruston ",719660200)
    spawn("107 GP1 ",1234311532)
    spawn("108 Raptor ",-674927303)
    spawn("109 Lynx ",482197771)
    spawn("110 ETR1 ",819197656)
    spawn("111 Tyrus ",2067820283)
    spawn("112 RE-7B ",-1232836011)
    spawn("113 Seven-70 ",-1757836725)
    spawn("114 811 ",-1829802492)
    spawn("115 Verlierer ",1102544804)
    spawn("116 Brawler ",-1479664699)
    spawn("117 Coquette Black Fin ",784565758)
    spawn("118 Stirling GT ",-1566741232)
    spawn("119 Furore GT ",-1089039904)
    spawn("120 Jester ",-1297672541)
    spawn("121 Alpha ",767087010)
    spawn("122 Z-Type ",758895617)
    spawn("123 Stinger GT ",-2098947590)
    spawn("124 Stinger ",1545842587)
    spawn("125 JB700 ",1051415893)
    spawn("126 Cheetah ",-1311154784)
    spawn("127 Entity XF ",-1291952903)
    spawn("128 Cognoscenti Cabrio ",330661258)
    spawn("129 Coquette ",108773431)
    spawn("130 Feltzer ",-1995326987)
    spawn("131 Infernus ",418536135)
    spawn("132 9F Cabri ",-1461482751)
    spawn("133 9F ",1032823388)
    spawn("134 Comet ",-1045541610)
    spawn("135 Vacca ",338562499)
    spawn("136 Bullet ",-1696146015)
    spawn("137 Carbonizzare ",2072687711)
    spawn("138 Voltic ",-1622444098)
    spawn("139 Rapid GT Cabrio ",2049897956)
    spawn("140 Rapid GT ",1737773231)
    spawn("141 Stafford ",321186144)
    spawn("142 Revolter ",-410205223)
    spawn("143 Raiden ",-1529242755)
    spawn("144 XLS ",1203490606)
    spawn("145 XLS Armored ",-432008408)
    spawn("146 Roosevelt ",-602287871)
    spawn("147 Cognoscenti 55 ",906642318)
    spawn("148 Cognoscenti ",-2023171296)
    spawn("149 Baller LE ",634118882)
    spawn("150 Schafter LWB ",1489967196)
    spawn("151 Exemplar ",-5153954)
    spawn("152 Super Diamond ",1123216662)
    spawn("153 Squaddie ",-102335483)
    spawn("154 Mesa ",914654722)
    spawn("155 Liberator ",-845961253)
    spawn("156 Comet ",-1045541610)
    spawn("157 Thrust ",1836027715)
    spawn("158 Esskey ",-618617997)
    spawn("159 Avarus ",-2115793025)
    spawn("160 Zombie Bobber ",-1009268949)
    spawn("161 Daemon 1 ",-1404136503)
    spawn("162 Daemon 2 ",2006142190)
    spawn("163 Rat-Bike ",1873600305)
    spawn("164 Bagger ",-2140431165)
    spawn("165 Faggio Mod ",-1289178744)
    spawn("166 Cliffhanger ",390201602)
    spawn("167 Enduro ",1753414259)
    spawn("168 Nemesis ",-634879114)
    spawn("169 Hakuchou ",1265391242)
    spawn("170 Innovation ",-159126838)
    spawn("171 Sovereign ",743478836)
    spawn("172 Hot Rod Blazer ",-1269889662)
    spawn("173 Bati 801Removed  ",-891462355)
    spawn("174 Ruffian  ",-893578776)
    spawn("175 Vader  ",-140902153)
    spawn("176 Blazer  ",-2128233223)
    spawn("177 PCJ 600  ",-909201658)
    spawn("178 Sanchez 1  ",788045382)
    spawn("179 Sanchez 2  ",-1453280962)
    spawn("180 Faggio  ",-1842748181)
    spawn("181 Akuma  ",1672195559)
    spawn("182 Double-T   ",-1670998136)
    spawn("183 Hexer   ",301427732)
    spawn("184 Lifeguard   ",-48031959)
    spawn("185 Verus   ",298565713)

    ImGui.EndMenu() end
    ImGui.EndMenu() end
-----------------------------------------------------------------------------------------------------------------------------

if ImGui.BeginMenu("Teleport") then 
 
if ImGui.BeginMenu("Casino Heist") then 
Teleport("Hack Vault 1",2510.261475, -224.366699, -72.037163) 
Teleport("Hack Vault 2",2533.521729, -225.209366, -72.037163) 
Teleport("Hack Vault 3",2537.823486, -237.452118, -72.037163) 
Teleport("Hack Vault 4",2534.049561, -248.194931, -72.037163) 
Teleport("Hack Vault 5",2520.342773, -255.425705, -72.037178)
Teleport("Cash Vault Enter",2521.761719, -287.359192, -60.022976)
Teleport("Cash Vault Exit",2521.876709, -284.334869, -60.022999)
ImGui.EndMenu() end
            
if ImGui.BeginMenu("Cayo Perlco Heist") then 
  Teleport("# Main Dock",4947.496094, -5168.458008, 1.234270) 
  Teleport("# Main Loot",5010.065430, -5751.291504, 14.184451) 
  Teleport("# Office",5010.203613, -5753.518555, 27.545284)
  Teleport("# Vault Loot",4999.764160, -5747.863770, 14.840000)
  Teleport("# Main Loot Gate",5009.156738, -5753.715820, 14.173852)
  Teleport("# North Safe Point",4961.050781, -5791.280762, 24.966309)
  Teleport("# StorageRoom1",5080.922852, -5756.109375, 14.529646)
  Teleport("# StorageRoom2",5028.794922, -5735.571777, 16.565603)
  Teleport("# StorageRoom3",5008.020020, -5787.345215, 16.531713)
  Teleport("# StorageRoom4",5000.289062, -5749.532715, 13.540483)
  Teleport("# PowerStation",4477.102539, -4597.295898, 4.283014)
  Teleport("# CommTower",5266.018555, -5427.736328, 64.297134)
  Teleport("# Main Dock Loot #01",4924.384766, -5243.334473, 1.223530)
  Teleport("# Main Dock Loot #02",4999.082520, -5165.239746, 1.464267)
  Teleport("# Main Dock Loot #03",4504.116211, -4555.046387, 2.871900)
  Teleport("# Main Dock Loot #04",4437.779785, -4447.757812, 3.028435)
  Teleport("# Main Dock Loot #05",5136.357910, -4607.321289, 1.332651)
  Teleport("# Main Dock Loot #06",5064.508789, -4596.458008, 1.552215)
  Teleport("# Main Dock Loot #07",5090.897949, -4682.269043, 1.107239)
  Teleport("# Main Dock Loot #08",5194.034668, -5135.017090, 2.046481)
  Teleport("# Main Dock Loot #09",5330.440918, -5270.056641, 31.886101)
  Teleport("# Main Dock Loot #10",4999.170898, -5165.166504, 1.464278)
  Teleport("# Main Dock Loot #11",4961.721680, -5108.724609, 1.681915)
  Teleport("# Hack Tower #01",5265.228516, -5429.266113, 107.849457)
  Teleport("# Hack Tower #02",5266.385742, -5431.791992, 89.423813)
  Teleport("# Hack Tower #03",5265.713867, -5427.803711, 139.747101)
  Teleport("# Exit",4990.778809, -5716.004395, 18.580210)
  ImGui.EndMenu() end

  if ImGui.BeginMenu("Gun Van ") then 
  Teleport("#1 Paleto Bay ",-29.532, 6435.136, 31.162) 
  Teleport("#2 Grapeseed Discount Store ",1705.214, 4819.167, 41.75)
  Teleport("#3 Sandy Shores ",1795.522, 3899.753, 33.869) 
  Teleport("#4 Grand Senora Desert by the airstrip ",1335.536, 2758.746, 51.099) 
  Teleport("#5 Vinewood Sign ",795.583, 1210.78, 338.962) 
  Teleport("#6 Chumash Plaza ",-3192.67, 1077.205, 20.594) 
  Teleport("#7 Paleto Forest near the sawmill ",-789.719, 5400.921, 33.915)
  Teleport("#8 Ortega's trailer ",-24.384, 3048.167, 40.703) 
  Teleport("#9 Powerplant ",2666.786, 1469.324, 24.237) 
  Teleport("#10 Powerplant ",-1454.966, 2667.503, 3.2)
  Teleport("#11 Grand Senora Desert Scrapyard ",2340.418, 3054.188, 47.888)
  Teleport("#12 El Burro Heights scrapyard ",1509.183, 2146.795, 76.853)
  Teleport("#13 Murrieta Heights ",1137.404, 1358.654, 34.322)
  Teleport("#14 Elysian Island ",-57.208, 2658.793, 5.737)
  Teleport("#15 Reservwar ",1905.017, 565.222, 185.558)
  Teleport("#16 La Mesa ",974.484, 1718.798, 35.296)
  Teleport("#17 Dock Terminal ",779.077, 3266.297, 6.719)
  Teleport("#18 la Puerta junkyard ",-587.728, 1637.208, 22.611)
  Teleport("#19 La Mesa ",733.99, 736.803, 29.165)
  Teleport("#20 La Mesa ",-1694.632, 454.082, 45.712)
  Teleport("#21 Vespucci Beach ",-1330.726, 1163.948, 4.313)
  Teleport("#22 West Vinewood ",-496.618, 40.231, 52.316)
  Teleport("#23 Downtown Vinewood ",275.527, 66.509, 94.108)
  Teleport("#24 Pillbox Hill ",260.928, 763.35, 40.559)
  Teleport("#25 Little Seoul ",-478.025, 741.45, 40.299)
  Teleport("#26 Alamo Sea ", 894.94, 3603.911, 40.56)
  Teleport("#27 Hookies ",2166.511, 4289.503, 55.733)
  Teleport("#28 Mt. Chilliad Truck terminal ", 1465.633, 6553.67, 25.771) 
  Teleport("#29 Mirror Park ", 1101.032, 335.172, 70.944)
  Teleport("#30 Davis ",149.683, 1655.674, 80.028)
  ImGui.EndMenu() end
  
  if ImGui.BeginMenu("Collectible Daily ") then 
  if ImGui.BeginMenu("G's Cache Location ") then 
  if ImGui.BeginMenu(" Part ( 1 ) G's Cache ") then 
  
  Teleport("# 1 /1 Location",1113.557, -645.957, 56.091) 
  Teleport("# 1 /2 Location",1142.874, -662.951, 57.135)
  Teleport("# 1 /3 Location",1146.691, -703.717, 56.167)
  Teleport("# 1 /4 Location",1073.542, -678.236, 56.583)
  Teleport("# 1 /5 Location",1046.454, -722.915, 56.419) 
  
  ImGui.EndMenu() end
  if ImGui.BeginMenu(" Part ( 2 ) G's Cache ") then 
  
  Teleport("# 2/1 Location",2064.713, 3489.88, 44.223) 
  Teleport("# 2/2 Location",2081.859, 3553.254, 42.157)
  Teleport("# 2/3 Location",2014.72, 3551.499, 42.726)
  Teleport("# 2/4 Location",1997.019, 3507.838, 39.666)
  Teleport("# 2/5 Location",2045.597, 3564.346, 39.343)
  
  ImGui.EndMenu() end
  if ImGui.BeginMenu(" Part ( 3 ) G's Cache") then 
  
  Teleport("# 3/1 Location ",-1317.344, -1481.97, 3.923) 
  Teleport("# 3/2 Location ",-1350.041, -1478.273, 4.567) 
  Teleport("# 3/3 Location ",-1393.87, -1445.139, 3.437) 
  Teleport("# 3/4 Location ",-1367.034, -1413.992, 2.611) 
  Teleport("# 3/5 Location ",-1269.861, -1426.272, 3.556) 
  Teleport("# 3/6 Location ",-1269.861, -1426.272, 3.556) 
  
  ImGui.EndMenu() end
  if ImGui.BeginMenu(" Part ( 4 ) G's Cache") then 
  
  Teleport("# 4/1 Location ",-295.468, 2787.385, 59.864) 
  Teleport("# 4/2 Location ",-284.69, 2848.234, 53.266) 
  Teleport("# 4/3 Location ",-329.193, 2803.404, 57.787) 
  Teleport("# 4/4 Location ",-306.847, 2825.6, 58.219) 
  Teleport("# 4/5 Location ",-336.046, 2829.988, 55.448) 
  
   ImGui.EndMenu() end
  if ImGui.BeginMenu(" Part ( 5 ) G's Cache ") then 
  
  Teleport("# 5/1 Location ",-1725.245, 233.946, 57.685)
  Teleport("# 5/2 Location ",-1639.892, 225.521, 60.336)
  Teleport("# 5/3 Location ",-1648.48, 212.049, 59.777)
  Teleport("# 5/4 Location ",-1693.318, 156.665, 63.855)
  Teleport("# 5/5 Location ",-1699.193, 179.574, 63.185)
  
  ImGui.EndMenu() end
  if ImGui.BeginMenu(" Part ( 6 ) G's Cache ") then 
  
  Teleport("# 6/1 Location ",-949.714, -710.658, 19.604)
  Teleport("# 6/2 Location ",-938.774, -781.817, 19.657)
  Teleport("# 6/3 Location ",-884.91, -786.863, 15.043)
  Teleport("# 6/4 Location ",-895.257, -729.943, 19.143)
  Teleport("# 6/5 Location ",-932.986, -746.452, 19.008)
  
  ImGui.EndMenu() end
  if ImGui.BeginMenu(" Part ( 7 ) G's Cache ") then 
  
  Teleport("# 7/1 Location ",-425.948, 1213.342, 324.936)
  Teleport("# 7/2 Location ",-387.267, 1137.65, 321.704)
  Teleport("# 7/3 Location ",-477.999, 1135.36, 320.123)
  Teleport("# 7/4 Location ",-431.822, 1119.449, 325.964)
  Teleport("# 7/5 Location ",-387.902, 1161.655, 324.529)
  
  ImGui.EndMenu() end
  if ImGui.BeginMenu(" Part ( 8 ) G's Cache ") then 
  
  
  Teleport("# 8/1 Location ",-3381.278, 965.534, 7.426)
  Teleport("# 8/2 Location ",-3427.724, 979.944, 7.526)
  Teleport("# 8/3 Location ",-3413.606, 961.845, 11.038)
  Teleport("# 8/4 Location ",-3419.585, 977.595, 11.167)
  Teleport("# 8/5 Location ",-3425.687, 961.215, 7.536)
  
  ImGui.EndMenu() end
  if ImGui.BeginMenu(" Part ( 9 ) G's Cache ") then 
  
  Teleport("# 9/1 Location",-688.732, 5828.4, 16.696)
  Teleport("# 9/2 Location",-673.425, 5799.744, 16.467)
  Teleport("# 9/3 Location",-710.348, 5769.631, 16.75)
  Teleport("# 9/4 Location",-699.926, 5801.619, 16.504)
  Teleport("# 9/5 Location",-660.359, 5781.733, 18.774)
  
  ImGui.EndMenu()end
  if ImGui.BeginMenu(" Part ( 10 ) G's Cache ") then 
  
  Teleport("# 10/1 Location",38.717, 6264.173, 32.88)
  Teleport("# 10/2 Location",84.67, 6292.286, 30.731)
  Teleport("# 10/3 Location",97.17, 6288.558, 38.447)
  Teleport("# 10/4 Location",14.453, 6243.932, 35.445)
  Teleport("# 10/5 Location",67.52, 6261.744, 32.029)
  
  ImGui.EndMenu()end
  if ImGui.BeginMenu(" Part ( 11 ) G's Cache ") then 
  
  Teleport("# 11/1 Location",2954.598, 4671.458, 50.106)
  Teleport("# 11/2 Location",2911.146, 4637.608, 49.3)
  Teleport("# 11/3 Location",2945.212, 4624.044, 49.078)
  Teleport("# 11/4 Location",2941.139, 4617.117, 52.114)
  Teleport("# 11/5 Location",2895.884, 4686.396, 48.094)
  
  ImGui.EndMenu() end
  if ImGui.BeginMenu(" Part ( 12 ) G's Cache") then 
  
  Teleport("# 12/1 Location",1332.319, 4271.446, 30.646)
  Teleport("# 12/2 Location",1353.332, 4387.911, 43.541)
  Teleport("# 12/3 Location",1337.892, 4321.563, 38.093)
  Teleport("# 12/4 Location",1386.603, 4366.511, 42.236)
  Teleport("# 12/5 Location",1303.193, 4313.509, 36.939)
  
  ImGui.EndMenu() end
  if ImGui.BeginMenu(" Part ( 13 ) G's Cache ") then 
  
  Teleport("# 13/1 Location",2720.03, 1572.762, 20.204)
  Teleport("# 13/2 Location",2663.161, 1581.395, 24.418)
  Teleport("# 13/3 Location",2661.482, 1641.057, 24.001)
  Teleport("# 14/4 Location",2671.003, 1561.394, 23.882)
  Teleport("# 15/5 Location",2660.104, 1606.54, 28.61)
  
  ImGui.EndMenu() end
  if ImGui.BeginMenu(" Part ( 14 ) G's Cache") then 
  
  Teleport("# 14/1 Location",211.775, -934.269, 23.466)
  Teleport("# 14/2 Location",198.265, -884.039, 30.696)
  Teleport("# 14/3 Location",189.542, -919.726, 29.96)
  Teleport("# 14/4 Location",169.504, -934.841, 29.228)
  Teleport("# 14/5 Location",212.376, -934.807, 29.007)
  
  ImGui.EndMenu() end
  if ImGui.BeginMenu(" Part ( 15 ) G's Cache ") then 
  
  Teleport("# 15/1 Location",1330.113, -2520.754, 46.365)
  Teleport("# 15/2 Location",1328.954, -2538.302, 46.976)
  Teleport("# 15/3 Location",1244.602, -2563.721, 42.646)
  Teleport("# 15/4 Location",1278.421, -2565.117, 43.544)
  
  ImGui.EndMenu() end
  ImGui.EndMenu() end
  if ImGui.BeginMenu("Stash House ") then 
  
  Teleport("# 1/2 Location",-156.345, 6292.5244, 30.6833)
  Teleport("# 1/3 Location",-1101.3784, 4940.878, 217.3541)
  Teleport("# 1/4 Location",2258.4717, 5165.8105, 58.1167)
  Teleport("# 1/5 Location",2881.7866, 4511.734, 46.9993)
  Teleport("# 1/6 Location",1335.4141, 4306.677, 37.0984)
  Teleport("# 1/7 Location",1857.9542, 3854.2195, 32.0891)
  Teleport("# 1/8 Location",905.7146, 3586.9836, 32.3914)
  Teleport("# 1/9 Location",2404.0786, 3127.706, 47.1533)
  Teleport("# 1/10 Location",550.6724, 2655.782, 41.223)
  Teleport("# 1/11 Location",-1100.8274, 2722.5867, 17.8004)
  Teleport("# 1/12 Location",-125.9821, 1896.2302, 196.3329)
  Teleport("# 1/13 Location",1546.2168, 2166.431, 77.7258)
  Teleport("# 1/14 Location",-3169.8516, 1034.2666, 19.8417)
  Teleport("# 1/15 Location",121.2199, 318.9121, 111.1516)
  Teleport("# 1/16 Location",-583.559, 195.3448, 70.4433)
  Teleport("# 1/17 Location",-1308.2467, -168.6344, 43.132)
  Teleport("# 1/18 Location",99.3476, -240.9664, 50.3995)
  Teleport("# 1/19 Location",1152.2288, -431.8629, 66.0115)
  Teleport("# 1/20 Location",-546.0123, -873.7389, 26.1988)
  Teleport("# 1/21 Location",-1293.3013, -1259.5853, 3.2025)
  Teleport("# 1/22 Location",161.7004, -1306.8784, 28.3547)
  Teleport("# 1/23 Location",979.653, -1981.9202, 29.6675)
  Teleport("# 1/24 Location",1124.7676, -1010.5512, 43.6728)
  Teleport("# 1/25 Location",167.95, -2222.4854, 6.2361)
  Teleport("# 1/26 Location",-559.2866, -1803.9038, 21.6104)
  
  ImGui.EndMenu() end
  
  if ImGui.BeginMenu("Stash Street Dealers ") then 
  Teleport("# 1/1 Location",550.8953, -1774.5175, 28.3121) 
  Teleport("# 1/2 Location",-154.924, 6434.428, 30.916)
  Teleport("# 1/2 Location",400.9768, 2635.3691, 43.5045)
  Teleport("# 1/3 Location",1533.846, 3796.837, 33.456)
  Teleport("# 1/4 Location",-1666.642, -1080.0201, 12.1537)
  Teleport("# 1/5 Location",-1560.6105, -413.3221, 37.1001)
  Teleport("# 1/6 Location",819.2939, -2988.8562, 5.0209)
  Teleport("# 1/7 Location",1001.701, -2162.448, 29.567)
  Teleport("# 1/8 Location",1388.9678, -1506.0815, 57.0407)
  Teleport("# 1/9 Location",-3054.574, 556.711, 0.661)
  Teleport("# 1/10 Location",-72.8903, 80.717, 70.6161)
  Teleport("# 1/11 Location",198.6676, -167.0663, 55.3187)
  Teleport("# 1/12 Location",814.636, -280.109, 65.463)
  Teleport("# 1/13 Location",-237.004, -256.513, 38.122)
  Teleport("# 1/14 Location",-493.654, -720.734, 22.921)
  Teleport("# 1/15 Location",156.1586, 6656.525, 30.5882)
  Teleport("# 1/16 Location",1986.3129, 3786.75, 31.2791)
  Teleport("# 1/17 Location",-685.5629, 5762.8706, 16.511)
  Teleport("# 1/18 Location",1707.703, 4924.311, 41.078)
  Teleport("# 1/19 Location",1195.3047, 2630.4685, 36.81)
  Teleport("# 1/20 Location",167.0163, 2228.922, 89.7867)
  Teleport("# 1/21 Location",2724.0076, 1483.066, 23.5007)
  Teleport("# 1/22 Location",1594.9329, 6452.817, 24.3172)
  Teleport("# 1/23 Location",-2177.397, 4275.945, 48.12)
  Teleport("# 1/24 Location",-2521.249, 2311.794, 32.216)
  Teleport("# 1/25 Location",-3162.873, 1115.6418, 19.8526)
  Teleport("# 1/26 Location",-1145.026, -2048.466, 12.218)
  Teleport("# 1/27 Location",-1304.321, -1318.848, 3.88)
  Teleport("# 1/28 Location",-946.727, 322.081, 70.357)
  Teleport("# 1/29 Location",-895.112, -776.624, 14.91)
  Teleport("# 1/30 Location",-250.614, -1527.617, 30.561)
  Teleport("# 1/31 Location",-601.639, -1026.49, 21.55)
  Teleport("# 1/32 Location",2712.9868, 4324.1157, 44.8521)
  Teleport("# 1/33 Location",726.772, 4169.101, 39.709)
  Teleport("# 1/34 Location",178.3272, 3086.2603, 42.0742)
  Teleport("# 1/35 Location",2351.592, 2524.249, 46.694)
  Teleport("# 1/36 Location",388.9941, 799.6882, 186.6764)
  Teleport("# 1/37 Location",2587.9822, 433.6803, 107.6139)
  Teleport("# 1/38 Location",830.2875, -1052.7747, 27.6666)
  Teleport("# 1/39 Location",-759.662, -208.396, 36.271)
  Teleport("# 1/40 Location",-43.7171, -2015.22, 17.017)
  Teleport("# 1/41 Location",124.02, -1039.884, 28.213)
  Teleport("# 1/42 Location",479.0473, -597.5507, 27.4996)
  Teleport("# 1/43 Location",959.67, 3619.036, 31.668)
  Teleport("# 1/44 Location",2375.8994, 3162.9954, 47.2087)
  Teleport("# 1/45 Location",-1505.687, 1526.558, 114.257)
  Teleport("# 1/46 Location",645.737, 242.173, 101.153)
  Teleport("# 1/47 Location",1173.1378, -388.2896, 70.5896)
  Teleport("# 1/48 Location",-1801.85, 172.49, 67.771)
  Teleport("# 1/49 Location",3729.2568, 4524.872, 21.4755)
  
  ImGui.EndMenu() end
  
  if ImGui.BeginMenu("Shipwreck ") then 
  Teleport("# 1/1 Location ",-389.978, -2215.861, 0.565) 
  Teleport("# 1/2 Location ",-872.646, -3121.243, 2.533) 
  Teleport("# 1/3 Location ",-1969.555, -3073.933, 1.899)
  Teleport("# 1/4 Location ",-1227.362, -1862.997, 1.071)
  Teleport("# 1/5 Location ",-1684.489, -1077.488, 0.464)
  Teleport("# 1/6 Location ",-2219.716, -438.266, 0.828)
  Teleport("# 1/7 Location ",-3099.804, 494.968, 0.134)
  Teleport("# 1/8 Location ",-3226.636, 1337.312, 0.634)
  Teleport("# 1/9 Location ",-2879.233, 2247.547, 0.878)
  Teleport("# 1/10 Location ",-1767.392, 2642.144, 0.089)
  Teleport("# 1/11 Location ",-180.913, 3081.589, 19.814)
  Teleport("# 1/12 Location ",-2198.02, 4606.557, 1.402)
  Teleport("# 1/13 Location ",-1356.295, 5379.136, 0.351)
  Teleport("# 1/14 Location ",-844.701, 6045.489, 1.201)
  Teleport("# 1/15 Location ",126.747, 7095.39, 0.484)
  Teleport("# 1/16 Location ",473.135, 6741.893, -0.009)
  Teleport("# 1/17 Location ",1469.845, 6629.33, -0.152)
  Teleport("# 1/18 Location ",2356.588, 6663.491, -0.172)
  Teleport("# 1/19 Location ",3380.806, 5670.246, 0.898)
  Teleport("# 1/20 Location ",3198.166, 5091.909, 0.464)
  Teleport("# 1/21 Location ",3947.421, 4403.337, 0.275)
  Teleport("# 1/22 Location ",3901.5327, 3323.1387, 0.5902)
  Teleport("# 1/23 Location ",3646.8667, 3120.687, 0.4864)
  Teleport("# 1/24 Location ",2891.847, 1790.7085, 1.4015)
  Teleport("# 1/25 Location ",2779.8674, 1106.5143, -0.0319)
  Teleport("# 1/26 Location ",2783.5151, 82.6473, -0.0161)
  Teleport("# 1/27 Location ",2820.225, -759.2029, 1.4572)
  Teleport("# 1/28 Location ",2772.996, -1606.0311, -0.1129)
  Teleport("# 1/29 Location ",1818.4303, -2718.4414, 0.1797)
  Teleport("# 1/30 Location ",987.383, -2681.047, -0.1296)
  
  ImGui.EndMenu() end
  
  if ImGui.BeginMenu("Hidden Caches Location ") then 
  if ImGui.BeginMenu("Part ( 1 ) Hidden Caches ") then 
  Teleport("# 1/1 Location",-540.975, -2465.579, -18.201)
  Teleport("# 1/2 Location",15.332, -2323.989, -14.224)
  Teleport("# 1/3 Location",461.483, -2386.212, -10.055)
  Teleport("# 1/4 Location",839.554, -2782.746, -20.516)
  Teleport("# 1/5 Location",1309.934, -2985.761, -21.344)
  Teleport("# 1/6 Location",1394.588, -3371.972, -17.855)
  Teleport("# 1/7 Location",1067.032, -3610.489, -52.777)
  Teleport("# 1/8 Location",371.111, -3226.341, -19.88)
  Teleport("# 1/9 Location",-1365.19, -3701.575, -32.056)
  Teleport("# 1/10 Location",-1983.722, -2769.391, -22.868)
  
  ImGui.EndMenu() end
  if ImGui.BeginMenu("Part ( 2 ) Hidden Caches ") then
  Teleport("# 2/1 Location",-1295.859, -1948.583, -7.47)
  Teleport("# 2/2 Location",-1791.493, -1284.341, -16.36)
  Teleport("# 2/3 Location",-1879.817, -1111.846, -19.249)
  Teleport("# 2/4 Location",-2086.537, -862.681, -37.465)
  Teleport("# 2/5 Location",-2614.496, -636.549, -35.296)
  Teleport("# 2/6 Location",-2815.156, -585.703, -59.753)
  Teleport("# 2/7 Location",-3412.1304, 165.8565, -32.6174)
  Teleport("# 2/8 Location",-3554.145, 817.679, -28.592)
  Teleport("# 2/9 Location",-3440.336, 1416.229, -33.629)
  Teleport("# 2/10 Location",-3295.557, 2020.828, -20.276)
  
  ImGui.EndMenu() end
  
  if ImGui.BeginMenu("Part ( 3 ) Hidden Caches ") then 
  Teleport("# 3/1 Location",-3020.068, 2527.044, -22.628)
  Teleport("# 3/2 Location",-3183.344, 3051.828, -39.251)
  Teleport("# 3/3 Location",-3270.3245, 3670.6917, -26.5299)
  Teleport("# 3/4 Location",-2860.754, 3912.275, -33.684)
  Teleport("# 3/5 Location",-2752.189, 4572.626, -21.415)
  Teleport("# 3/6 Location",-2407.659, 4898.846, -45.411)
  Teleport("# 3/7 Location",-1408.649, 5734.096, -36.339)
  Teleport("# 3/8 Location",-1008.661, 6531.678, -22.122)
  Teleport("# 3/9 Location",-811.495, 6667.619, -14.098)
  Teleport("# 3/10 Location",-420.119, 7224.093, -44.899)
  
  ImGui.EndMenu() end
  
  if ImGui.BeginMenu("Part ( 4 ) Hidden Caches ") then 
  Teleport("# 4/1 Location",425.78, 7385.154, -44.087)
  Teleport("# 4/2 Location",556.131, 7158.932, -38.031)
  Teleport("# 4/3 Location",1441.456, 6828.521, -44.977)
  Teleport("# 4/4 Location",1820.262, 7017.078, -78.959)
  Teleport("# 4/5 Location",2396.039, 6939.861, -104.858)
  Teleport("# 4/6 Location",2475.159, 6704.704, -9.333)
  Teleport("# 4/7 Location",2696.607, 6655.181, -21.513)
  Teleport("# 4/8 Location",3049.285, 6549.182, -36.306)
  Teleport("# 4/9 Location",3411.339, 6308.514, -52.545)
  Teleport("# 4/10 Location",3770.457, 5838.503, -27.88)
  
  ImGui.EndMenu() end
  if ImGui.BeginMenu("Part ( 5 ) Hidden Caches ") then
  Teleport("# 5/1 Location",3625.00, 5543.203, -26.645)
  Teleport("# 5/2 Location",3986.087, 3867.625, -31.705)
  Teleport("# 5/3 Location",3846.006, 3683.454, -17.227)
  Teleport("# 5/4 Location",4130.328, 3530.792, -27.516)
  Teleport("# 5/5 Location",3897.776, 3050.804, -19.277)
  Teleport("# 5/6 Location",3751.005, 2672.416, -48.526)
  Teleport("# 5/7 Location",3559.241, 2070.137, -38.01)
  Teleport("# 5/8 Location",3410.804, 1225.255, -55.684)
  Teleport("# 5/9 Location",3373.351, 323.788, -20.246)
  Teleport("# 5/10 Location",3152.983, -261.257, -8.355)
  
  ImGui.EndMenu() end
  if ImGui.BeginMenu("Part ( 6 ) Hidden Caches ") then 
  Teleport("# 6/1 Location",3192.368, -367.909, -30.311)
  Teleport("# 6/2 Location",3178.722, -988.684, -25.133)
  Teleport("# 6/3 Location",2701.915, -1365.816, -13.163)
  Teleport("# 6/4 Location",3045.378, -1682.987, -31.797)
  Teleport("# 6/5 Location",2952.829, -2313.142, -94.421)
  Teleport("# 6/6 Location",2361.167, -2728.077, -67.131)
  Teleport("# 6/7 Location",1824.039, -2973.19, -41.865)
  Teleport("# 6/8 Location",-575.734, -3132.886, -21.879)
  Teleport("# 6/9 Location",-1872.968, -2087.878, -61.897)
  Teleport("# 6/10 Location",-3205.486, -144.9, -31.784)
  
  ImGui.EndMenu() end
  if ImGui.BeginMenu("Part ( 7 ) Hidden Caches ") then 
  Teleport("# 7/1 Location",-1760.539, 5721.301, -74.808)
  Teleport("# 7/2 Location",-1293.948, 5886.757, -27.186)
  Teleport("# 7/3 Location",-6.032, 7464.313, -12.313)
  Teleport("# 7/4 Location",3627.174, 5286.089, -35.437)
  Teleport("# 7/5 Location",3978.554, 4987.259, -69.702)
  Teleport("# 7/6 Location",3995.491, 4858.986, -37.555)
  Teleport("# 7/7 Location",4218.075, 4116.594, -29.013)
  Teleport("# 7/8 Location",3795.855, 2327.765, -37.352)
  Teleport("# 7/9 Location",3247.753, 1395.029, -50.268)
  Teleport("# 7/10 Location",3451.907, 278.014, -99.633)
  
  ImGui.EndMenu() end
  if ImGui.BeginMenu("Part ( 8 ) Hidden Caches") then 
  Teleport("# 8/1 Location",1061.475, 7157.525, -28.239)
  Teleport("# 8/2 Location",-1551.109, 5558.511, -22.472)
  Teleport("# 8/3 Location",-29.194, -3484.225, -34.377)
  Teleport("# 8/4 Location",2981.125, 843.773, -4.586)
  Teleport("# 8/5 Location",2446.59, -2413.441, -35.135)
  Teleport("# 8/6 Location",423.342, -2864.345, -16.944)
  Teleport("# 8/7 Location",668.404, -3173.142, -6.337)
  Teleport("# 8/8 Location",-2318.251, 4976.115, -101.11)
  Teleport("# 8/9 Location",806.924, 6846.94, -3.666)
  Teleport("# 8/10 Location",4404.907, 4617.076, -20.163)
  
  ImGui.EndMenu() end
  
  if ImGui.BeginMenu("Part ( 9 ) Hidden Caches ") then
  Teleport("# 9/1 Location",3276.699, 1648.139, -44.099)
  Teleport("# 9/2 Location",2979.325, 1.033, -16.746)
  Teleport("# 9/3 Location",-838.069, -1436.609, -10.248)
  Teleport("# 9/4 Location",-3334.358, 3276.015, -27.291)
  Teleport("# 9/5 Location",-808.456, 6165.307, -3.398)
  Teleport("# 9/6 Location",-397.854, 6783.974, -19.076)
  Teleport("# 9/7 Location",95.133, 3898.854, 24.086)
  Teleport("# 9/8 Location",660.099, 3760.461, 19.43)
  Teleport("# 9/9 Location",2241.487, 4022.88, 25.675)
  Teleport("# 9/10 Location",1553.867, 4321.805, 19.761)
  
  ImGui.EndMenu() end
  
  if ImGui.BeginMenu("Part ( 10 ) Hidden Caches") then 
  Teleport("# 10/1 Location",857.875, 3958.953, 6.001)
  Teleport("# 10/2 Location",3431.468, 717.226, -93.674)
  Teleport("# 10/3 Location",-1634.57, -1741.677, -34.462)
  Teleport("# 10/4 Location",-3378.466, 503.853, -27.274)
  Teleport("# 10/5 Location",-1732.212, 5336.15, -7.72)
  Teleport("# 10/6 Location",-2612.415, 4266.765, -30.535)
  Teleport("# 10/7 Location",3406.32, -584.198, -18.545)
  Teleport("# 10/8 Location",-3106.876, 2432.615, -23.172)
  Teleport("# 10/9 Location",-2172.952, -3199.194, -33.315)
   
  ImGui.EndMenu() end
  ImGui.EndMenu() end
  
  if ImGui.BeginMenu("Junk Energy Skydives ") then
  Teleport("# 1/1 Location",-121.199, -962.557, 26.524)
  Teleport("# 1/2 Location",153.572, -721.103, 46.328)
  Teleport("# 1/3 Location",-812.47, 299.77, 85.407)
  Teleport("# 1/4 Location",-1223.345, 3856.44, 488.126)
  Teleport("# 1/5 Location",426.341, 5612.683, 765.588)
  Teleport("# 1/6 Location",503.8174, 5506.424, 773.6786)
  Teleport("# 1/7 Location",813.5065, 5720.6187, 693.7969)
  Teleport("# 1/8 Location",-860.4413, 4729.499, 275.6516)
  Teleport("# 1/9 Location",1717.6476, 3295.5166, 40.4591)
  Teleport("# 1/10 Location",2033.4845, 4733.43, 40.8773)
  Teleport("# 1/11 Location",-1167.212, -2494.621, 12.956)
  Teleport("# 1/12 Location",2790.4, 1465.635, 23.518)
  Teleport("# 1/13 Location",-782.166, -1452.285, 4.013)
  Teleport("# 1/14 Location",-559.43, -909.031, 22.863)
  Teleport("# 1/15 Location",-136.551, 6356.967, 30.492)
  Teleport("# 1/16 Location",742.95, 2535.935, 72.156)
  Teleport("# 1/17 Location",-2952.79, 441.363, 14.251)
  Teleport("# 1/18 Location",-1522.113, 1491.642, 110.595)
  Teleport("# 1/19 Location",261.555, -209.291, 60.566)
  Teleport("# 1/20 Location",739.4191, -1223.1754, 23.7705)
  Teleport("# 1/21 Location",-1724.4279, -1129.78, 12.0438)
  Teleport("# 1/22 Location",735.9623, 1303.1774, 359.293)
  Teleport("# 1/23 Location",2555.3403, 301.0995, 107.4623)
  Teleport("# 1/24 Location",-1143.5713, 2683.302, 17.0937)
  Teleport("# 1/25 Location",-917.5775, -1155.1293, 3.7723)
  
  ImGui.EndMenu() end
  
  if ImGui.BeginMenu("Treasure Chests To Cayo ") then
  Teleport("# 1/1 Location",4877.7646, -4781.151, 1.1379)
  Teleport("# 1/2 Location",4535.187, -4703.817, 1.1286)
  Teleport("# 1/3 Location",3900.6318, -4704.9194, 3.4813)
  Teleport("# 1/4 Location",4823.4844, -4323.176, 4.6816)
  Teleport("# 1/5 Location",5175.097, -4678.9375, 1.4205)
  Teleport("# 1/6 Location",5590.9507, -5216.8467, 13.351)
  Teleport("# 1/7 Location",5457.7954, -5860.7734, 19.0936)
  Teleport("# 1/8 Location",4855.598, -5561.794, 26.5093)
  Teleport("# 1/9 Location",4854.77, -5162.7295, 1.4387)
  Teleport("# 1/10 Location",4178.2944, -4357.763, 1.5826)
  Teleport("# 1/11 Location",4942.0825, -5168.135, -3.575)
  Teleport("# 1/12 Location",4560.804, -4356.775, -7.888)
  Teleport("# 1/13 Location",5598.9644, -5604.2393, -6.0489)
  Teleport("# 1/14 Location",5264.7236, -4920.671, -2.8715)
  Teleport("# 1/15 Location",4944.2183, -4293.736, -6.6942)
  Teleport("# 1/16 Location",4560.804, -4356.775, -7.888)
  Teleport("# 1/17 Location",3983.0261, -4540.1865, -6.1264)
  Teleport("# 1/18 Location",4414.676, -4651.4575, -5.083)
  Teleport("# 1/19 Location",4540.07, -4774.899, -3.9321)
  Teleport("# 1/20 Location",4777.6006, -5394.6265, -5.0127)
  
  ImGui.EndMenu() end
  if ImGui.BeginMenu("Buried Stashes To Cayo ") then
  Teleport("# 1/1 Location",5579.7026, -5231.42, 14.2512)
  Teleport("# 1/2 Location",5481.595, -5855.187, 19.128)
  Teleport("# 1/3 Location",5549.2407, -5747.577, 10.427)
  Teleport("# 1/4 Location",5295.542, -5587.4307, 61.3964)
  Teleport("# 1/5 Location",5136.9844, -5524.6675, 52.7719)
  Teleport("# 1/6 Location",4794.91, -5546.516, 21.4945)
  Teleport("# 1/7 Location",4895.3125, -5335.3433, 9.0204)
  Teleport("# 1/8 Location",4994.968, -5136.416, 1.476)
  Teleport("# 1/9 Location",5323.654, -5276.0596, 33.0353)
  Teleport("# 1/10 Location",5362.1177, -5170.0854, 28.035)
  Teleport("# 1/11 Location",5164.5522, -4706.8384, 1.1632)
  Teleport("# 1/12 Location",4888.6104, -4789.4756, 1.4911)
  Teleport("# 1/13 Location",4735.3096, -4687.2236, 1.2879)
  Teleport("# 1/14 Location",4887.2036, -4630.111, 13.149)
  Teleport("# 1/15 Location",4796.803, -4317.4175, 4.3515)
  Teleport("# 1/16 Location",4522.936, -4649.638, 10.037)
  Teleport("# 1/17 Location",4408.228, -4470.875, 3.3683)
  Teleport("# 1/18 Location",4348.7827, -4311.3193, 1.3335)
  Teleport("# 1/19 Location",4235.67, -4552.0557, 4.0738)
  Teleport("# 1/20 Location",3901.899, -4720.187, 3.4537)
  
  ImGui.EndMenu() end
  if ImGui.BeginMenu("Exotic Exports ") then
  if ImGui.BeginMenu("Part ( 1 ) Exotic Exports ") then
  Teleport("# 1/1 Location",-1297.199, 252.495, 61.813)
  Teleport("# 1/2 Location",-1114.101, 479.205, 81.161)
  Teleport("# 1/3 Location",-345.267, 662.299, 168.587)
  Teleport("# 1/4 Location",-72.605, 902.579, 234.631)
  Teleport("# 1/5 Location",-161.232, 274.911, 92.534)
  Teleport("# 1/6 Location",-504.323, 424.21, 96.287)
  Teleport("# 1/7 Location",-1451.916, 533.495, 118.177)
  Teleport("# 1/8 Location",-1979.252, 586.078, 116.479)
  Teleport("# 1/9 Location",-1405.117, 81.983, 52.099)
  Teleport("# 1/10 Location",-1299.92, -228.464, 59.654)
  
  ImGui.EndMenu() end
  if ImGui.BeginMenu("Part ( 2 ) Exotic Exports ") then 
  Teleport("# 2/1 Location",-1409.08, -590.823, 29.317)
  Teleport("# 2/2 Location",-1085.162, -476.529, 35.636)
  Teleport("# 2/3 Location",-817.325, -1201.59, 5.935)
  Teleport("# 2/4 Location",-1873.598, -343.933, 48.26)
  Teleport("# 2/5 Location",-1334.625, -1008.972, 6.867)
  Teleport("# 2/6 Location",-1043.008, -1010.464, 1.15)
  Teleport("# 2/7 Location",-489.189, -596.899, 30.174)
  Teleport("# 2/8 Location",-187.144, -175.854, 42.624)
  Teleport("# 2/9 Location",871.548, -75.386, 77.764)
  Teleport("# 2/10 Location",443.542, 253.197, 102.21)
  
  ImGui.EndMenu() end
  
  if ImGui.BeginMenu("Part ( 3 ) Exotic Exports ") then
  Teleport("# 3/1 Location",185.595, -1016.005, 28.3)
  Teleport("# 3/2 Location",110.261, -714.605, 32.133)
  Teleport("# 3/3 Location",-74.575, -619.874, 35.173)
  Teleport("# 3/4 Location",283.769, -342.644, 43.92)
  Teleport("# 3/5 Location",-237.521, -2059.951, 26.62)
  Teleport("# 3/6 Location",-1044.016, -2608.022, 19.775)
  Teleport("# 3/7 Location",-801.566, -1313.922, 4.0)
  Teleport("# 3/8 Location",-972.578, -1464.273, 4.013)
  Teleport("# 3/9 Location",1309.942, -530.154, 70.312)
  Teleport("# 3/10 Location",1566.097, -1683.172, 87.205)
  
  ImGui.EndMenu() end
  
  if ImGui.BeginMenu("Part ( 4 ) Exotic Exports ") then
  Teleport("# 4/1 Location",339.481, 159.143, 102.146)
  Teleport("# 4/2 Location",-2316.493, 280.86, 168.467)
  Teleport("# 4/3 Location",-3036.574, 105.31, 10.593)
  Teleport("# 4/4 Location",-3071.87, 658.171, 9.918)
  Teleport("# 4/5 Location",-1534.826, 889.731, 180.803)
  Teleport("# 4/6 Location",140.945, 6606.513, 30.845)
  Teleport("# 4/7 Location",1362.672, 1178.352, 111.609)
  Teleport("# 4/8 Location",1869.749, 2622.154, 44.672)
  Teleport("# 4/9 Location",2673.478, 1678.569, 23.488)
  Teleport("# 4/10 Location",2593.022, 364.349, 107.457)
  
  ImGui.EndMenu() end
  if ImGui.BeginMenu("Part ( 5 ) Exotic Exports ") then
  
  Teleport("# 5/1 Location",-1886.248, 2016.572, 139.951)
  Teleport("# 5/2 Location",2537.084, -390.048, 91.993)
  Teleport("# 5/3 Location",3511.653, 3783.877, 28.925)
  Teleport("# 5/4 Location",2002.724, 3769.429, 31.181)
  Teleport("# 5/5 Location",-771.927, 5566.46, 32.486)
  Teleport("# 5/6 Location",1697.817, 6414.365, 31.73)
  Teleport("# 5/4 Location",386.663, 2640.138, 43.493)
  Teleport("# 5/8 Location",231.935, 1162.313, 224.464)
  Teleport("# 5/9 Location",1700.445, 4937.267, 41.078)
  Teleport("# 5/10 Location",-582.454, -859.433, 25.034)
  
  ImGui.EndMenu() end
  if ImGui.BeginMenu("Part ( 6 ) Exotic Exports ") then
  Teleport("# 6/1 Location",-604.458, -1218.292, 13.507)
  Teleport("# 6/2 Location",-229.587, -1483.435, 30.352)
  Teleport("# 6/3 Location",28.385, -1707.341, 28.298)
  Teleport("# 6/4 Location",-22.296, -1851.577, 24.108)
  Teleport("# 6/5 Location",321.798, -1948.141, 23.627)
  Teleport("# 6/6 Location",455.602, -1695.263, 28.289)
  Teleport("# 6/7 Location",934.148, -1812.944, 29.812)
  Teleport("# 6/8 Location",1228.548, -1605.649, 50.736)
  Teleport("# 6/9 Location",-329.7, -700.958, 31.912)
  Teleport("# 6/10 Location",238.339, -35.01, 68.728)
  
  ImGui.EndMenu() end
  if ImGui.BeginMenu("Part ( 7 ) Exotic Exports ") then
  Teleport("# 7/1 Location",393.61, -649.557, 27.5)
  Teleport("# 7/2 Location",246.847, -1162.082, 28.16)
  Teleport("# 7/3 Location",124.231, -1472.496, 28.142)
  Teleport("# 7/4 Location",1136.156, -773.997, 56.632)
  Teleport("# 7/5 Location",1156.682, -1474.145, 33.693)
  Teleport("# 7/6 Location",1028.898, -2405.952, 28.494)
  Teleport("# 7/7 Location",-936.334, -2692.07, 15.611)
  Teleport("# 7/7 Location",-532.351, -2134.219, 4.992)
  Teleport("# 7/9 Location",-1530.625, -993.47, 12.017)
  Teleport("# 7/10 Location",-1528.444, -427.05, 34.447)
  
  
  ImGui.EndMenu() end
  
  if ImGui.BeginMenu("Part ( 8 ) Exotic Exports ") then 
  Teleport("# 8/1 Location",-1640.424, -202.879, 54.146)
  Teleport("# 8/1 Location",-552.673, 309.154, 82.191)
  Teleport("# 8/3 Location",642.042, 587.747, 127.911)
  Teleport("# 8/4 Location",-1804.769, 804.137, 137.514)
  Teleport("# 8/5 Location",839.097, 2202.196, 50.46)
  Teleport("# 8/6 Location",756.539, 2525.957, 72.161)
  Teleport("# 8/7 Location",1205.454, 2658.357, 36.824)
  Teleport("# 8/8 Location",1991.707, 3078.063, 46.016)
  Teleport("# 8/9 Location",1977.207, 3837.1, 30.997)
  Teleport("# 8/10 Location",1350.173, 3601.249, 33.899)
  
  ImGui.EndMenu() end
  
  if ImGui.BeginMenu("Part ( 9 ) Exotic Exports ") then 
  Teleport("# 9/1 Location",1819.042, 4592.234, 35.316)
  Teleport("# 9/2 Location",2905.354, 4419.682, 47.541)
  Teleport("# 9/3 Location",-472.038, 6034.981, 30.341)
  Teleport("# 9/4 Location",-165.839, 6454.25, 30.495)
  Teleport("# 9/5 Location",-2221.144, 4232.757, 46.132)
  Teleport("# 9/6 Location",-3138.864, 1086.83, 19.669)
  Teleport("# 9/7 Location",1546.591, 3781.791, 33.06)
  Teleport("# 9/8 Location",2717.772, 1391.725, 23.535)
  Teleport("# 9/9 Location",-1144.001, 2666.28, 17.094)
  Teleport("# 9/10 Location",-2555.512, 2322.827, 32.06)
  
  ImGui.EndMenu() end
  if ImGui.BeginMenu("Part ( 10 ) Exotic Exports ") then
  Teleport("# 10/1 Location",-2340.763, 296.197, 168.467)
  Teleport("# 10/2 Location",1122.086, 267.125, 79.856)
  Teleport("# 10/3 Location",629.014, 196.173, 96.128)
  Teleport("# 10/4 Location",1150.161, -991.569, 44.528)
  Teleport("# 10/5 Location",244.916, -860.606, 28.5)
  Teleport("# 10/6 Location",-340.099, -876.452, 30.071)
  Teleport("# 10/7 Location",387.275, -215.651, 55.835)
  Teleport("# 10/8 Location",-1234.105, -1646.832, 3.129)
  Teleport("# 10/9 Location",-1062.018, -226.736, 37.155) 
  
  ImGui.EndMenu() end
  ImGui.EndMenu() end
  ImGui.EndMenu() end
  if ImGui.BeginMenu("Time Trials ") then
  Teleport("# 1/1 Location",-1811.675, -1199.5421, 12.0174)
  Teleport("# 1/2 Location",-377.166, 1250.8182, 326.4899)
  Teleport("# 1/3 Location",-1253.2399, -380.457, 58.2873)
  Teleport("# 1/4 Location",2702.0369, 5145.717, 42.8568)
  Teleport("# 1/5 Location",1261.3533, -3278.38, 4.8335)
  Teleport("# 1/6 Location",-1554.3121, 2755.0088, 16.8004)
  Teleport("# 1/7 Location",637.1439, -1845.8552, 8.2676)
  Teleport("# 1/8 Location",-552.626, 5042.7026, 127.9448)
  Teleport("# 1/9 Location",-579.1157, 5324.664, 69.2662)
  Teleport("# 1/10 Location",1067.343, -2448.2366, 28.0683)
  Teleport("# 1/11 Location",1577.189, 6439.966, 23.6996)
  Teleport("# 1/12 Location",-199.7486, -1973.3108, 26.6204)
  Teleport("# 1/13 Location",-1504.541, 1482.4895, 116.053)
  Teleport("# 1/14 Location",-1502.0471, 4940.611, 63.8034)
  Teleport("# 1/15 Location",947.562, 142.6773, 79.8307)
  Teleport("# 1/16 Location",1246.2249, 2685.1099, 36.5944)
  Teleport("# 1/17 Location",-1021.1459, -2580.291, 33.6353)
  Teleport("# 1/18 Location",231.9767, 3301.4888, 39.5627)
  Teleport("# 1/19 Location",860.353, 536.8055, 124.7803)
  Teleport("# 1/20 Location",2820.6514, 1642.2759, 23.668)
  Teleport("# 1/21 Location",-2257.7986, 4315.927, 44.5551)
  Teleport("# 1/22 Location",526.397, 5624.461, 779.3564)
  Teleport("# 1/23 Location",175.2847, -3042.0754, 4.7734)
  Teleport("# 1/24 Location",813.3556, 1274.9536, 359.511)
  Teleport("# 1/25 Location",77.5248, 3629.9146, 38.6907)
  Teleport("# 1/26 Location",1004.6567, 898.837, 209.0257)
  Teleport("# 1/27 Location",104.8058, -1938.9818, 19.8037)
  Teleport("# 1/28 Location",-985.2776, -2698.696, 12.8307)
  Teleport("# 1/29 Location",230.6618, -1399.0258, 29.4856)
  Teleport("# 1/30 Location",-546.6672, -2857.9282, 5.0004)
  Teleport("# 1/31 Location",-172.8944, 1034.8262, 231.2332)
  Teleport("# 1/32 Location",1691.4703, -1458.6351, 111.7033)
  
  ImGui.EndMenu() end
  if ImGui.BeginMenu("Rc Trial ") then
  Teleport("# 1/1 Location",-486.1165, -916.59, 22.964) 
  Teleport("# 1/2 Location",854.8221, -2189.789, 29.679604)
  Teleport("# 1/3 Location",-1730.7411, -188.57533, 57.337273)
  Teleport("# 1/4 Location",1409.3899, 1084.5609, 113.33391)
  Teleport("# 1/5 Location",-901.63, -779.377, 14.859)
  Teleport("# 1/6 Location",2562.03, 2707.7473, 41.071)
  Teleport("# 1/7 Location",-1194.2417, -1456.5526, 3.379667)
  Teleport("# 1/8 Location",-216.2158, -1109.7155, 21.9008)
  Teleport("# 1/9 Location",-889.356, -1071.848, 1.163)
  Teleport("# 1/10 Location",885.3417, -255.1916, 68.4006)
  Teleport("# 1/11 Location",-948.3436, -491.1428, 35.8333)
  Teleport("# 1/12 Location",750.3155, 597.0025, 124.9241)
  Teleport("# 1/13 Location",-402.4602, -1701.4429, 17.8213)
  Teleport("# 1/14 Location",-601.3092, 5295.396, 69.2145)
  
  ImGui.EndMenu() end
  if ImGui.BeginMenu("Bike Trial ") then
  Teleport("# 1/1 Location",501.6576, 5598.3604, 795.1221) 
  Teleport("# 1/2 Location",493.7987, 5528.249, 777.3241) 
  Teleport("# 1/3 Location",2820.5623, 5972.031, 349.5339)
  Teleport("# 1/4 Location",-1031.3934, 4721.9556, 235.3456)
  Teleport("# 1/5 Location",-1932.808, 1782.2681, 172.2726)
  Teleport("# 1/6 Location",-182.0154, 319.3242, 96.7999)
  Teleport("# 1/7 Location",1100.4553, -264.2758, 68.268)
  Teleport("# 1/8 Location",736.0028, 2574.1477, 74.2793)
  Teleport("# 1/9 Location",1746.0431, -1474.762, 111.8385)
  Teleport("# 1/10 Location",30.5142, 197.473, 104.6073)
  Teleport("# 1/11 Location",145.0902, -605.9424, 46.0762)
  Teleport("# 1/12 Location",-447.3499, 1600.9911, 357.3483)
  Teleport("# 1/13 Location",-2205.15, 199.7418, 173.6018)
  Teleport("# 1/14 Location",1321.0515, -505.2507, 70.4208)
ImGui.EndMenu() end
ImGui.EndMenu() end

-----------------------------------------------------------------------------------------------------------------------------
if ImGui.BeginMenu("Online") then

    if ImGui.BeginMenu("Instant Finish Heists / Mission") then
    ImGui.BulletText("--------------------------------------------------------------")
    ImGui.BulletText("                     How to use !")
    ImGui.BulletText("--------------------------------------------------------------")
    ImGui.BulletText("   It is preferable to wait 5 to 10 seconds ")
    ImGui.BulletText("             Ibefore pressing “Instant”")
    ImGui.BulletText("--------------------------------------------------------------")
    ImGui.BulletText("- Agency / Recird A Stuios  ")
    ImGui.BulletText("- U.L.Paper / Dax Part 1,2  ")
    ImGui.BulletText("- Auto Shop / Heist Cayo Perlco  ")
    if ImGui.Button("Instant Passed (1)") then
      script.run_in_fiber(function(script)
          if SCRIPT.GET_NUMBER_OF_THREADS_RUNNING_THE_SCRIPT_WITH_THIS_HASH(joaat("fm_mission_controller_2020")) ~= 0 then
              locals.set_int("fm_mission_controller_2020",50150 + 1, 51338752)
              locals.set_int("fm_mission_controller_2020",50150 + 1770 + 1 ,50)
          end
      end)
    end
    
    ImGui.BulletText("--------------------------------------------------------------")
    ImGui.BulletText("- Gerald / Simeon / Lamar  ")
    ImGui.BulletText("- Martin Madrazo / Ms Baker  ")
    ImGui.BulletText("- Heist Apartmen  ")
    
    if ImGui.Button("Instant Passed (2)") then
      script.run_in_fiber(function(script)
          if SCRIPT.GET_NUMBER_OF_THREADS_RUNNING_THE_SCRIPT_WITH_THIS_HASH(joaat("fm_mission_controller")) ~= 0 then
              locals.set_int("fm_mission_controller",19746 + 1741 ,80)
              locals.set_int("fm_mission_controller",19746 + 2686 ,10000000)
              locals.set_int("fm_mission_controller",27489 + 859 ,99999)
              locals.set_int("fm_mission_controller",31621 + 69 ,99999)
          end
      end)
    end
    
    ImGui.BulletText("--------------------------------------------------------------")
    ImGui.BulletText("- Heist Doomsday")
    if ImGui.Button("Instant Passed (3)") then
      script.run_in_fiber(function(script)
          if SCRIPT.GET_NUMBER_OF_THREADS_RUNNING_THE_SCRIPT_WITH_THIS_HASH(joaat("fm_mission_controller")) ~= 0 then
              locals.set_int("fm_mission_controller",19746,12)
              locals.set_int("fm_mission_controller",19746 + 1741, 150)
              locals.set_int("fm_mission_controller",27489+ 859, 99999)
              locals.set_int("fm_mission_controller",31621 + 69, 99999)
              locals.set_int("fm_mission_controller",31621 + 97, 80)
          end
      end)
    end
    
    ImGui.BulletText("--------------------------------------------------------------")
    ImGui.BulletText("- Sightseer ( CEO VIP ) Mission")
    if ImGui.Button("Instant Passed (4)") then
      script.run_in_fiber(function(script)
          if SCRIPT.GET_NUMBER_OF_THREADS_RUNNING_THE_SCRIPT_WITH_THIS_HASH(joaat("gb_sightseer")) ~= 0 then
              locals.set_int("gb_sightseer",194 + 1 , 6)
              locals.set_int("gb_sightseer",194 + 1 , 5)
              locals.set_int("gb_sightseer",194 + 1 , 3)
          end
      end)
    end
    
    ImGui.EndMenu() end
    
if ImGui.BeginMenu("Heists") then
if ImGui.BeginMenu("Cayo Perico Heist") then

if ImGui.BeginMenu("How to use Skip Heist !!") then

ImGui.BulletText("--------------------------------------------------------------")
ImGui.BulletText("              Read carefully please ")
ImGui.BulletText("--------------------------------------------------------------")
ImGui.BulletText("            SetThe first thing to do  ")
ImGui.BulletText("                 is pay for the 100k ")
ImGui.BulletText("           Then step away from the screen  ")
ImGui.BulletText("                 and start selecting ")
ImGui.BulletText("--------------------------------------------------------------")
ImGui.BulletText("If you are playing alone or with  ")
ImGui.BulletText("other players ")
ImGui.BulletText("the minimum must be no more ")
ImGui.BulletText("than 2.6 million  ")
ImGui.BulletText("before completing the mission. ")
ImGui.BulletText("If everyone gets 100% ")
ImGui.BulletText("If you steal more than that ")
ImGui.BulletText("the money will not be counted  ")
ImGui.BulletText("--------------------------------------------------------------")
ImGui.BulletText("To be safe? Do not repeat the theft more  ")
ImGui.BulletText("than two or three times every 24 hours! ")
ImGui.BulletText("--------------------------------------------------------------")
ImGui.EndMenu() end

if ImGui.BeginMenu("Skip Heist Cayo Perlco") then
ImGui.BulletText("          How to use !!")

ImGui.BulletText("--------------------------------------------------------------")
ImGui.BulletText("Choose The Target By Number")
ImGui.BulletText("--------------------------------------------------------------")
if ImGui.Button("1 - Sinsimito Tequila") then script.run_in_fiber(function(script) stats.set_int(MPX .. "H4CNF_TARGET",0 ) end)end
if ImGui.Button("2 -Ruby Necklace") then script.run_in_fiber(function(script) stats.set_int(MPX .. "H4CNF_TARGET",1 )end)end
if ImGui.Button("3 -Bearer Bonds") then script.run_in_fiber(function(script) stats.set_int(MPX .. "H4CNF_TARGET",2 )end)end
if ImGui.Button("4 -Pink Diamonde") then script.run_in_fiber(function(script) stats.set_int(MPX .. "H4CNF_TARGET",3 )end)end
if ImGui.Button("5 -Madrazo Files") then script.run_in_fiber(function(script) stats.set_int(MPX .. "H4CNF_TARGET",4 )end)end
if ImGui.Button("6 -Panther Statue") then script.run_in_fiber(function(script) stats.set_int(MPX .. "H4CNF_TARGET",5 )end)end

 ImGui.BulletText("--------------------------------------------------------------")
 ImGui.BulletText("Secondary Target By Number")
 ImGui.BulletText("--------------------------------------------------------------")
 if ImGui.Button("1 - Gold") then script.run_in_fiber(function(script)
 stats.set_int(MPX .. "H4LOOT_GOLD_C", 255)
 stats.set_int(MPX .. "H4LOOT_GOLD_C_SCOPED", 255)
 stats.set_int(MPX .. "H4LOOT_GOLD_V", 1251817)
 stats.set_int(MPX .. "H4LOOT_WEED_V", 0)
 stats.set_int(MPX .. "H4LOOT_COKE_V", 0)
 stats.set_int(MPX .. "H4LOOT_CASH_V", 0)
 stats.set_int(MPX .. "H4LOOT_COKE_I", 0)
 stats.set_int(MPX .. "H4LOOT_COKE_I_SCOPED", 0)
 stats.set_int(MPX .. "H4LOOT_COKE_C", 0)
 stats.set_int(MPX .. "H4LOOT_COKE_C_SCOPED", 0)
 stats.set_int(MPX .. "H4LOOT_WEED_I", 0)
 stats.set_int(MPX .. "H4LOOT_WEED_I_SCOPED", 0)
 stats.set_int(MPX .. "H4LOOT_WEED_C", 0)
 stats.set_int(MPX .. "H4LOOT_WEED_C_SCOPED", 0)
 stats.set_int(MPX .. "H4LOOT_CASH_I", 0)
 stats.set_int(MPX .. "H4LOOT_CASH_I_SCOPED", 0)
 stats.set_int(MPX .. "H4LOOT_CASH_C", 0)
 stats.set_int(MPX .. "H4LOOT_CASH_C_SCOPED", 0)
 stats.set_int(MPX .. "H4LOOT_CASH_V", 0)
end)end

if ImGui.Button("2 - Coke") then script.run_in_fiber(function(script)
  stats.set_int(MPX .. "H4LOOT_COKE_I", 167772)
  stats.set_int(MPX .. "H4LOOT_COKE_I_SCOPED", 167772)
  stats.set_int(MPX .. "H4LOOT_COKE_C", 255)
  stats.set_int(MPX .. "H4LOOT_COKE_C_SCOPED", 255)
  stats.set_int(MPX .. "H4LOOT_COKE_V", 938863)
  stats.set_int(MPX .. "H4LOOT_GOLD_I", 0)
  stats.set_int(MPX .. "H4LOOT_GOLD_I_SCOPED", 0)
  stats.set_int(MPX .. "H4LOOT_GOLD_V", 0)
  stats.set_int(MPX .. "H4LOOT_WEED_V", 0)
  stats.set_int(MPX .. "H4LOOT_CASH_V", 0)
  stats.set_int(MPX .. "H4LOOT_GOLD_C", 0)
  stats.set_int(MPX .. "H4LOOT_GOLD_C_SCOPED", 0)
  stats.set_int(MPX .. "H4LOOT_GOLD_V", 0)
  stats.set_int(MPX .. "H4LOOT_WEED_I", 0)
  stats.set_int(MPX .. "H4LOOT_WEED_I_SCOPED", 0)
  stats.set_int(MPX .. "H4LOOT_WEED_C", 0)
  stats.set_int(MPX .. "H4LOOT_WEED_C_SCOPED", 0)
  stats.set_int(MPX .. "H4LOOT_WEED_V", 0)
  stats.set_int(MPX .. "H4LOOT_CASH_I", 0)
  stats.set_int(MPX .. "H4LOOT_CASH_I_SCOPED", 0)
  stats.set_int(MPX .. "H4LOOT_CASH_C", 0)
  stats.set_int(MPX .. "H4LOOT_CASH_C_SCOPED", 0)
  stats.set_int(MPX .. "H4LOOT_CASH_V", 0)
 end)end
 
 if ImGui.Button("3 - Coke") then script.run_in_fiber(function(script)
  stats.set_int(MPX .. "H4LOOT_WEED_I", 17215)
  stats.set_int(MPX .. "H4LOOT_WEED_I_SCOPED", 17215)
  stats.set_int(MPX .. "H4LOOT_WEED_C", 255)
  stats.set_int(MPX .. "H4LOOT_WEED_C_SCOPED", 255)
  stats.set_int(MPX .. "H4LOOT_WEED_V", 625908)
  stats.set_int(MPX .. "H4LOOT_COKE_I", 0)
  stats.set_int(MPX .. "H4LOOT_COKE_I_SCOPED", 0)
  stats.set_int(MPX .. "H4LOOT_COKE_C", 0)
  stats.set_int(MPX .. "H4LOOT_COKE_C_SCOPED", 0)
  stats.set_int(MPX .. "H4LOOT_COKE_V", 0)
  stats.set_int(MPX .. "H4LOOT_GOLD_V", 0)
  stats.set_int(MPX .. "H4LOOT_CASH_V", 0)
  stats.set_int(MPX .. "H4LOOT_GOLD_C", 0)
  stats.set_int(MPX .. "H4LOOT_GOLD_C_SCOPED", 0)
  stats.set_int(MPX .. "H4LOOT_GOLD_V", 0)
  stats.set_int(MPX .. "H4LOOT_CASH_I", 0)
  stats.set_int(MPX .. "H4LOOT_CASH_I_SCOPED", 0)
  stats.set_int(MPX .. "H4LOOT_CASH_C", 0)
  stats.set_int(MPX .. "H4LOOT_CASH_C_SCOPED", 0)
  stats.set_int(MPX .. "H4LOOT_CASH_V", 0)
 end)end
 
 if ImGui.Button("4 - Weed") then script.run_in_fiber(function(script)
 stats.set_int(MPX .. "H4LOOT_CASH_I", 215)
 stats.set_int(MPX .. "H4LOOT_CASH_I_SCOPED", 215)
 stats.set_int(MPX .. "H4LOOT_CASH_C", 255)
 stats.set_int(MPX .. "H4LOOT_CASH_C_SCOPED", 255)
 stats.set_int(MPX .. "H4LOOT_CASH_V", 469431)
 stats.set_int(MPX .. "H4LOOT_GOLD_I", 0)
 stats.set_int(MPX .. "H4LOOT_GOLD_I_SCOPED", 0)
 stats.set_int(MPX .. "H4LOOT_GOLD_V", 0)
 stats.set_int(MPX .. "H4LOOT_COKE_I", 0)
 stats.set_int(MPX .. "H4LOOT_COKE_I_SCOPED", 0)
 stats.set_int(MPX .. "H4LOOT_COKE_C", 0)
 stats.set_int(MPX .. "H4LOOT_COKE_C_SCOPED", 0)
 stats.set_int(MPX .. "H4LOOT_COKE_V", 0)
 stats.set_int(MPX .. "H4LOOT_WEED_I", 0)
 stats.set_int(MPX .. "H4LOOT_WEED_I_SCOPED", 0)
 stats.set_int(MPX .. "H4LOOT_WEED_C", 0)
 stats.set_int(MPX .. "H4LOOT_WEED_C_SCOPED", 0)
 stats.set_int(MPX .. "H4LOOT_WEED_V", 0)
 stats.set_int(MPX .. "H4LOOT_GOLD_V", 0)
 stats.set_int(MPX .. "H4LOOT_WEED_V", 0)
 stats.set_int(MPX .. "H4LOOT_COKE_V", 0)
 stats.set_int(MPX .. "H4LOOT_GOLD_C", 0)
 stats.set_int(MPX .. "H4LOOT_GOLD_C_SCOPED", 0)
 stats.set_int(MPX .. "H4LOOT_GOLD_V", 0)
 stats.set_int(MPX .. "H4LOOT_WEED_I", 0)
 stats.set_int(MPX .. "H4LOOT_WEED_I_SCOPED", 0)
 stats.set_int(MPX .. "H4LOOT_WEED_C", 0)
 stats.set_int(MPX .. "H4LOOT_WEED_C_SCOPED", 0)
 stats.set_int(MPX .. "H4LOOT_WEED_V", 0)
 stats.set_int(MPX .. "H4LOOT_COKE_I", 0)
 stats.set_int(MPX .. "H4LOOT_COKE_I_SCOPED", 0)
 stats.set_int(MPX .. "H4LOOT_COKE_C", 0)
 stats.set_int(MPX .. "H4LOOT_COKE_C_SCOPED", 0)
 stats.set_int(MPX .. "H4LOOT_COKE_V", 0)
end)end

if ImGui.Button("5 - Cash") then script.run_in_fiber(function(script)
  stats.set_int(MPX .. "H4LOOT_CASH_I", 215)
  stats.set_int(MPX .. "H4LOOT_CASH_I_SCOPED", 215)
  stats.set_int(MPX .. "H4LOOT_CASH_C", 255)
  stats.set_int(MPX .. "H4LOOT_CASH_C_SCOPED", 255)
  stats.set_int(MPX .. "H4LOOT_CASH_V", 469431)
  stats.set_int(MPX .. "H4LOOT_GOLD_I", 215)
  stats.set_int(MPX .. "H4LOOT_GOLD_I_SCOPED", 215)
  stats.set_int(MPX .. "H4LOOT_GOLD_V", 469431)
  stats.set_int(MPX .. "H4LOOT_COKE_I", 215)
  stats.set_int(MPX .. "H4LOOT_COKE_I_SCOPED", 215)
  stats.set_int(MPX .. "H4LOOT_COKE_C", 255)
  stats.set_int(MPX .. "H4LOOT_COKE_C_SCOPED", 255)
  stats.set_int(MPX .. "H4LOOT_COKE_V", 469431)
  stats.set_int(MPX .. "H4LOOT_WEED_I", 215)
  stats.set_int(MPX .. "H4LOOT_WEED_I_SCOPED", 215)
  stats.set_int(MPX .. "H4LOOT_WEED_C", 255)
  stats.set_int(MPX .. "H4LOOT_WEED_C_SCOPED", 255)
  stats.set_int(MPX .. "H4LOOT_WEED_V", 469431)
  stats.set_int(MPX .. "H4LOOT_GOLD_V", 469431)
  stats.set_int(MPX .. "H4LOOT_WEED_V", 469431)
  stats.set_int(MPX .. "H4LOOT_COKE_V", 469431)
  stats.set_int(MPX .. "H4LOOT_GOLD_C", 255)
  stats.set_int(MPX .. "H4LOOT_GOLD_C_SCOPED", 255)
  stats.set_int(MPX .. "H4LOOT_GOLD_V", 469431)
  stats.set_int(MPX .. "H4LOOT_WEED_I", 215)
  stats.set_int(MPX .. "H4LOOT_WEED_I_SCOPED", 215)
  stats.set_int(MPX .. "H4LOOT_WEED_C", 255)
  stats.set_int(MPX .. "H4LOOT_WEED_C_SCOPED", 255)
  stats.set_int(MPX .. "H4LOOT_WEED_V", 469431)
  stats.set_int(MPX .. "H4LOOT_COKE_I", 215)
  stats.set_int(MPX .. "H4LOOT_COKE_I_SCOPED", 215)
  stats.set_int(MPX .. "H4LOOT_COKE_C", 255)
  stats.set_int(MPX .. "H4LOOT_COKE_C_SCOPED", 255)
  stats.set_int(MPX .. "H4LOOT_COKE_V", 469431)
 end)end
 ImGui.BulletText("--------------------------------------------------------------")

 if ImGui.Button("completed Heist! ") then script.run_in_fiber(function(script)
 stats.set_int(MPX .. "H4_PROGRESS", 124271)
 stats.set_int(MPX .. "H4CNF_BS_GEN", 131071)
 stats.set_int(MPX .. "H4CNF_WEAPONS", 5) 
 stats.set_int(MPX .. "H4_MISSIONS", -1)	
 stats.set_int(MPX .. "H4LOOT_PAINT", 0)
 stats.set_int(MPX .. "H4LOOT_PAINT_SCOPED", 0)
end)end

ImGui.EndMenu() end 

if ImGui.BeginMenu("Cuts $ Heist Cayo Perlco") then
Obj_Heist_Cayo_Cut1, HC = ImGui.DragInt("Player 1", Obj_Heist_Cayo_Cut1, 1, 5, 125) if HC then globals.set_int(Money_Heist_Cayo_Cut1, Obj_Heist_Cayo_Cut1) end 
Obj_Heist_Cayo_Cut2, HC = ImGui.DragInt("Player 2", Obj_Heist_Cayo_Cut2, 1, 5, 125) if HC then globals.set_int(Money_Heist_Cayo_Cut2, Obj_Heist_Cayo_Cut2) end 
Obj_Heist_Cayo_Cut3, HC = ImGui.DragInt("Player 3", Obj_Heist_Cayo_Cut3, 1, 5, 125) if HC then globals.set_int(Money_Heist_Cayo_Cut3, Obj_Heist_Cayo_Cut3) end 
Obj_Heist_Cayo_Cut4, HC = ImGui.DragInt("Player 4", Obj_Heist_Cayo_Cut4, 1, 5, 125) if HC then globals.set_int(Money_Heist_Cayo_Cut4, Obj_Heist_Cayo_Cut4) end 
ImGui.EndMenu() end 


if ImGui.BeginMenu("Tools for Heist") then

if ImGui.Button("Kill Cayo Cooldown Friends Mode") then script.run_in_fiber(function(script)
stats.set_int(MPX .. "H4_TARGET_POSIX", 1659429119)  
stats.set_int(MPX .. "H4_COOLDOWN", 0)
stats.set_int(MPX .. "H4_COOLDOWN_HARD", 0)
stats.set_int(MPX .. "H4_COOLDOWN", 0)
stats.set_int(MPX .. "H4_TARGET_POSIX", 1659429119)
stats.set_int(MPX .. "H4_COOLDOWN_HARD", 0)
end)end

if ImGui.Button("Kill Cayo Cooldown Solo Mode") then script.run_in_fiber(function(script)
stats.set_int(MPX .. "H4_TARGET_POSIX", 1659643454)  
stats.set_int(MPX .. "H4_COOLDOWN", 0)
stats.set_int(MPX .. "H4_COOLDOWN_HARD", 0)
stats.set_int(MPX .. "H4_COOLDOWN", 0)
stats.set_int(MPX .. "H4_TARGET_POSIX", 1659643454)
stats.set_int(MPX .. "H4_COOLDOWN_HARD", 0)
end)end

if ImGui.Button("Setup Cayo Now") then script.run_in_fiber(function(script)
  stats.set_int(MPX .. "H4CNF_BS_GEN", 131071)
  stats.set_int(MPX .. "H4CNF_BS_ENTR", 63)
  stats.set_int(MPX .. "H4CNF_BS_ABIL", 63)
  stats.set_int(MPX .. "H4CNF_WEAPONS", 5)
  stats.set_int(MPX .. "H4CNF_WEP_DISRP", 3)
  stats.set_int(MPX .. "H4CNF_ARM_DISRP", 3)
  stats.set_int(MPX .. "H4CNF_HEL_DISRP", 3)
  stats.set_int(MPX .. "H4CNF_TARGET", 5)
  stats.set_int(MPX .. "H4CNF_TROJAN", 2)
  stats.set_int(MPX .. "H4CNF_APPROACH", -1)
  stats.set_int(MPX .. "H4LOOT_CASH_I", 0)
  stats.set_int(MPX .. "H4LOOT_CASH_C", 0)
  stats.set_int(MPX .. "H4LOOT_WEED_I", 0)
  stats.set_int(MPX .. "H4LOOT_WEED_C", 0)
  stats.set_int(MPX .. "H4LOOT_COKE_I", 0)
  stats.set_int(MPX .. "H4LOOT_COKE_C", 0)
  stats.set_int(MPX .. "H4LOOT_CASH_I", 0)
  stats.set_int(MPX .. "H4LOOT_GOLD_I", 0)
  stats.set_int(MPX .. "H4LOOT_GOLD_C", 0)
  stats.set_int(MPX .. "H4LOOT_PAINT", -1)
  stats.set_int(MPX .. "H4_PROGRESS", 126823)
  stats.set_int(MPX .. "H4LOOT_CASH_I_SCOPED", 0)
  stats.set_int(MPX .. "H4LOOT_CASH_C_SCOPED", 0)
  stats.set_int(MPX .. "H4LOOT_WEED_I_SCOPED", 0)
  stats.set_int(MPX .. "H4LOOT_WEED_C_SCOPED", 0)
  stats.set_int(MPX .. "H4LOOT_COKE_I_SCOPED", 0)
  stats.set_int(MPX .. "H4LOOT_COKE_C_SCOPED", 0)
  stats.set_int(MPX .. "H4LOOT_GOLD_I_SCOPED", 0)
  stats.set_int(MPX .. "H4LOOT_GOLD_C_SCOPED", 0)
  stats.set_int(MPX .. "H4LOOT_PAINT_SCOPED", -1)
  stats.set_int(MPX .. "H4_MISSIONS", 65535)
  stats.set_int(MPX .. "H4_PLAYTHROUGH_STATUS", 32)
end)end

ImGui.EndMenu() end --- Tools for Heist
ImGui.EndMenu() end --- Cayo Perico 1

if ImGui.BeginMenu("Diamond Casino Heist") then

if ImGui.BeginMenu("How to use Skip Heist !!") then
ImGui.BulletText("--------------------------------------------------------------")
ImGui.BulletText("              Read carefully please ")
ImGui.BulletText("--------------------------------------------------------------")
ImGui.BulletText("            SetThe first thing to do  ")
ImGui.BulletText("                 is pay for the 2.5k ")
ImGui.BulletText("           Then step away from the screen  ")
ImGui.BulletText("                 and start selecting ")
ImGui.BulletText("--------------------------------------------------------------")
ImGui.BulletText("Set the percentage according to the goal")
ImGui.BulletText("Target Heist = Cash = 179%   ")
ImGui.BulletText("Target Heist = Gold = 120%     ")
ImGui.BulletText("--------------------------------------------------------------")
ImGui.BulletText("Target Heist = Artwork = 150%  ")
ImGui.BulletText("Target Heist = Diamonds = 100%  ")
ImGui.BulletText("--------------------------------------------------------------")
ImGui.BulletText("To be safe? Do not repeat the theft more  ")
ImGui.BulletText("than two or three times every 24 hours!  ")
ImGui.BulletText("--------------------------------------------------------------")
ImGui.EndMenu() end

if ImGui.BeginMenu("Skip Diamond Casino") then
  
ImGui.BulletText( "Choose The Target By Number")
ImGui.BulletText("--------------------------------------------------------------")

if ImGui.Button("1 - Cash ") then script.run_in_fiber(function(script)
    stats.set_int(MPX .. "H3OPT_TARGET", 0)  
end)end
 
if ImGui.Button("2 - Gold ") then script.run_in_fiber(function(script)
  stats.set_int(MPX .. "H3OPT_TARGET", 1)  
end)end

if ImGui.Button("3 - Artwork ") then script.run_in_fiber(function(script)
  stats.set_int(MPX .. "H3OPT_TARGET", 2)  
end)end

if ImGui.Button("4 - Diamonds ") then script.run_in_fiber(function(script)
  stats.set_int(MPX .. "H3OPT_TARGET", 3)  
end)end
ImGui.BulletText("--------------------------------------------------------------")
ImGui.BulletText( "Set Level Heist ")
ImGui.BulletText("--------------------------------------------------------------")

if ImGui.Button("1 - Norma ") then script.run_in_fiber(function(script)
  stats.set_int(MPX .. "H3_LAST_APPROACH", 2)  
end)end

if ImGui.Button("2 - Hard ") then script.run_in_fiber(function(script)
  stats.set_int(MPX .. "H3_HARD_APPROACH", 3)  
end)end

ImGui.BulletText("--------------------------------------------------------------")
ImGui.BulletText( "Set Easy Approach ")
ImGui.BulletText("--------------------------------------------------------------")

if ImGui.Button("1 - The Silent and Sneaky") then script.run_in_fiber(function(script)
  stats.set_int(MPX .. "H3_LAST_APPROACH", 1)  
end)end

if ImGui.Button("2 - The Big Con") then script.run_in_fiber(function(script)
  stats.set_int(MPX .. "H3_HARD_APPROACH", 2)  
end)end

if ImGui.Button("3 - The Aggressive") then script.run_in_fiber(function(script)
  stats.set_int(MPX .. "H3OPT_APPROACH", 3)  
end)end

ImGui.BulletText("--------------------------------------------------------------")

if ImGui.Button("completed Setup ( 1 ) ") then script.run_in_fiber(function(script)
  stats.set_int(MPX .. "H3OPT_BITSET1", -1)  
end)end
ImGui.BulletText("--------------------------------------------------------------")
ImGui.BulletText( "Set Hacker Heist  ")
ImGui.BulletText("--------------------------------------------------------------")

if ImGui.Button("1 - Rickie Luckens 3%") then script.run_in_fiber(function(script)
    stats.set_int(MPX .. "H3OPT_CREWHACKER", 1)  
 end)end

 if ImGui.Button("2 - Avi Schwartzman 10% ") then script.run_in_fiber(function(script)
  stats.set_int(MPX .. "H3OPT_CREWHACKER", 2)  
end)end

if ImGui.Button("3 - Paige Harris 9% ") then script.run_in_fiber(function(script)
  stats.set_int(MPX .. "H3OPT_CREWHACKER", 3)  
end)end

if ImGui.Button("4 - Paige Harris 9% ") then script.run_in_fiber(function(script)
  stats.set_int(MPX .. "H3OPT_CREWHACKER", 4)  
end)end


ImGui.BulletText("--------------------------------------------------------------")
ImGui.BulletText( "Set H3OPT_VEHS Heist   ")
ImGui.BulletText("--------------------------------------------------------------")

if ImGui.Button("1 - v1 ") then script.run_in_fiber(function(script)
  stats.set_int(MPX .. "H3OPT_VEHS", 1)  
end)end

if ImGui.Button("2 - v2 ") then script.run_in_fiber(function(script)
stats.set_int(MPX .. "H3OPT_VEHS", 2)  
end)end

if ImGui.Button("3 - v3% ") then script.run_in_fiber(function(script)
  stats.set_int(MPX .. "H3OPT_VEHS", 3)  
 end)end
  
ImGui.BulletText("--------------------------------------------------------------")
ImGui.BulletText( "Set Weapn Heist  ")
ImGui.BulletText("--------------------------------------------------------------")
  
if ImGui.Button("1 - Weap-Karl ") then script.run_in_fiber(function(script)
  stats.set_int(MPX .. "H3OPT_CREWWEAP", 1)  
end)end

if ImGui.Button("2 - Gus ") then script.run_in_fiber(function(script)
  stats.set_int(MPX .. "H3OPT_CREWWEAP", 2)  
end)end

if ImGui.Button("3 - Char ") then script.run_in_fiber(function(script)
  stats.set_int(MPX .. "H3OPT_CREWWEAP", 3)  
end)end

if ImGui.Button("4 - Ches") then script.run_in_fiber(function(script)
  stats.set_int(MPX .. "H3OPT_CREWWEAP", 4)  
end)end

if ImGui.Button("5 - Pat") then script.run_in_fiber(function(script)
  stats.set_int(MPX .. "H3OPT_CREWWEAP", 5)  
end)end

ImGui.BulletText("--------------------------------------------------------------")

if ImGui.Button("completed Setup ( 2 ) ") then script.run_in_fiber(function(script)
stats.set_int(MPX .. "H3OPT_DISRUPTSHIP", 3)
stats.set_int(MPX .. "H3OPT_KEYLEVELS", 2)
stats.set_int(MPX .. "H3OPT_CREWWEAP", 1)
stats.set_int(MPX .. "H3OPT_CREWDRIVER", 1)
stats.set_int(MPX .. "H3OPT_VEHS", 3)
stats.set_int(MPX .. "H3OPT_WEAPS", 0)
stats.set_int(MPX .. "H3OPT_BITSET0", -129)
end)end

ImGui.EndMenu() end 

if ImGui.BeginMenu("Cuts $ Diamond Casino") then

  Obj_Heist_Diamond_Cut1, HC = ImGui.DragInt("Player 1", Obj_Heist_Diamond_Cut1, 1, 5, 179) if HC then globals.set_int(Money_Heist_Diamond_Cut1, Obj_Heist_Diamond_Cut1) end 
  Obj_Heist_Diamond_Cut2, HC = ImGui.DragInt("Player 2", Obj_Heist_Diamond_Cut2, 1, 5, 179) if HC then globals.set_int(Money_Heist_Diamond_Cut2, Obj_Heist_Diamond_Cut2) end 
  Obj_Heist_Diamond_Cut3, HC = ImGui.DragInt("Player 3", Obj_Heist_Diamond_Cut3, 1, 5, 179) if HC then globals.set_int(Money_Heist_Diamond_Cut3, Obj_Heist_Cayo_Cut3) end 
  Obj_Heist_Diamond_Cut4, HC = ImGui.DragInt("Player 4", Obj_Heist_Diamond_Cut4, 1, 5, 179) if HC then globals.set_int(Money_Heist_Diamond_Cut4, Obj_Heist_Diamond_Cut4) end 

ImGui.EndMenu() end 

ImGui.EndMenu() end 


if ImGui.BeginMenu("Doomsday Heist") then

if ImGui.BeginMenu(" Skip Heist Doomsday") then

if ImGui.Button("The Data Breaches ACT I") then script.run_in_fiber(function(script)
stats.set_int(MPX .. "GANGOPS_FLOW_MISSION_PROG", 503)
stats.set_int(MPX .. "GANGOPS_HEIST_STATUS", -229383)
stats.set_int(MPX .. "GANGOPS_FLOW_NotifyS", 1557)
end)end

if ImGui.Button("The Data Breaches ACT II") then script.run_in_fiber(function(script)
stats.set_int(MPX .. "GANGOPS_FLOW_MISSION_PROG", 240)
stats.set_int(MPX .. "GANGOPS_HEIST_STATUS", -229378)
stats.set_int(MPX .. "GANGOPS_FLOW_NotifyS", 1557)
end)end
 
if ImGui.Button("The Data Breaches ACT III") then script.run_in_fiber(function(script)
stats.set_int(MPX .. "GANGOPS_FLOW_MISSION_PROG", 16368)
stats.set_int(MPX .. "GANGOPS_HEIST_STATUS", -229380)
stats.set_int(MPX .. "GANGOPS_FLOW_NotifyS", 1557)
end)end
ImGui.EndMenu() end 

if ImGui.BeginMenu("Cuts $ Doomsday") then

Obj_Heist_Doomsday_Cut1, HC = ImGui.DragInt("Player 1", Obj_Heist_Doomsday_Cut1, 1, 15, 313) if HC then globals.set_int(Money_Heist_Doomsday_Cut1, Obj_Heist_Doomsday_Cut1) end 
Obj_Heist_Doomsday_Cut1, HC = ImGui.DragInt("Player 2", Obj_Heist_Doomsday_Cut1, 1, 15, 313) if HC then globals.set_int(Money_Heist_Doomsday_Cut2, Obj_Heist_Doomsday_Cut1) end 
Obj_Heist_Doomsday_Cut3, HC = ImGui.DragInt("Player 3", Obj_Heist_Doomsday_Cut3, 1, 15, 313) if HC then globals.set_int(Money_Heist_Doomsday_Cut3, Obj_Heist_Doomsday_Cut3) end 
Obj_Heist_Doomsday_Cut4, HC = ImGui.DragInt("Player 4", Obj_Heist_Doomsday_Cut4, 1, 15, 313) if HC then globals.set_int(Money_Heist_Doomsday_Cut4, Obj_Heist_Doomsday_Cut4) end 


ImGui.EndMenu() end 

if ImGui.Button("Skip All Missions") then script.run_in_fiber(function(script)
  stats.set_int(MPX .. "GANGOPS_FM_MISSION_PROG", -1)  
end)end

ImGui.EndMenu() end 

if ImGui.BeginMenu("Apartmen Heisty") then


if ImGui.Button("Skip All Missions") then script.run_in_fiber(function(script)
stats.set_int(MPX .. " HEIST_PLANNING_STAGE", -1)
end)end
 
ImGui.EndMenu() end 
ImGui.EndMenu() end 


if ImGui.BeginMenu("Contracts & Missions") then
  if ImGui.BeginMenu("Salvage Yard") then
  
  ImGui.BulletText("--------------------------------------------------------------")
  ImGui.BulletText("                       Salvage Yard  ")
  ImGui.BulletText("--------------------------------------------------------------")
  ImGui.BulletText("          How to use !!")
  ImGui.BulletText("    You must choose any Mission ")  
  ImGui.BulletText(" from the computer, then press Skip  ") 
  ImGui.BulletText("--------------------------------------------------------------")        
  if ImGui.Button("Skip Preps") then script.run_in_fiber(function(script) stats.set_int(MPX .. "SALV23_FM_PROG",-1)end)end

  ImGui.EndMenu()end

  if ImGui.BeginMenu("Agency Contract") then
  ImGui.BulletText("          How to use !!")
  ImGui.BulletText("To skip tasks, just click once")  
  ImGui.BulletText("Skip every 24 hours")  
  
  if ImGui.Button("Set Up Dre Finale Mission") then script.run_in_fiber(function(script)
    stats.set_int(MPX .. "FIXER_STORY_BS", 4092)
    stats.set_int(MPX .. "FIXER_STORY_STRAND", -1)
  end)end
  
  ImGui.BulletText("You have to confirm ")  
  ImGui.BulletText("the money before completing the Missions")
  Obj_Agency1, N1 = ImGui.DragInt("Set Money Missions", Obj_Agency1, 10000, 0, 2000000) if N1 then globals.set_int(262145 +Money_gency1, Obj_Agency1) end 
  
  ImGui.EndMenu()end
  
  if ImGui.BeginMenu("Los Santos Tuners") then
    ImGui.BulletText("          How to use !!")
    ImGui.BulletText("To skip tasks, just click once")  
    ImGui.BulletText("And you should be out Auto Shop!  ")  
  
  ImGui.BulletText("--------------------------------------------------------------")
  if ImGui.Button("Set The Union Depository ") then script.run_in_fiber(function(script) 
    stats.set_int(MPX .. "TUNER_GEN_BS", 12543)
    stats.set_int(MPX .. "TUNER_GEN_BS", 4351)
    stats.set_int(MPX .. "TUNER_CURRENT", 0)  end)end
  Obj_SantosT1, N1 = ImGui.DragInt("Set Money Missions 1", Obj_SantosT1, 10000, 0, 1000000) if N1 then globals.set_int(262145 + 31323 , 0) end 
  ImGui.BulletText("--------------------------------------------------------------")
  if ImGui.Button("Set The Superdollar Deal") then script.run_in_fiber(function(script)     
    stats.set_int(MPX .. "TUNER_GEN_BS", 12543)
    stats.set_int(MPX .. "TUNER_GEN_BS", 4351)
    stats.set_int(MPX .. "TUNER_CURRENT", 1)  end)end

  Obj_SantosT2, N1 = ImGui.DragInt("Set Money Missions 2", Obj_SantosT2, 10000, 0, 1000000) if N1 then globals.set_int(262145 + 31323 , 1) end 
  ImGui.BulletText("--------------------------------------------------------------")
  if ImGui.Button("Set he Bank Contract") then script.run_in_fiber(function(script)     
    stats.set_int(MPX .. "TUNER_GEN_BS", 12543)
    stats.set_int(MPX .. "TUNER_GEN_BS", 4351)
    stats.set_int(MPX .. "TUNER_CURRENT", 2)  end)end

  Obj_SantosT3, N1 = ImGui.DragInt("Set Money Missions 3", Obj_SantosT3, 10000, 0, 1000000) if N1 then globals.set_int(262145 + 31323 , 2) end 
  ImGui.BulletText("--------------------------------------------------------------")
  if ImGui.Button("Set The ECU Job ") then script.run_in_fiber(function(script)     
    stats.set_int(MPX .. "TUNER_GEN_BS", 12543)
    stats.set_int(MPX .. "TUNER_GEN_BS", 4351)
    stats.set_int(MPX .. "TUNER_CURRENT", 3)  end)end

  Obj_SantosT4, N1 = ImGui.DragInt("Set Money Missions 4", Obj_SantosT4, 10000, 0, 1000000) if N1 then globals.set_int(262145 + 31323 , 3) end 
  ImGui.BulletText("--------------------------------------------------------------")
  if ImGui.Button("Set The Prison Contract") then script.run_in_fiber(function(script)     
    stats.set_int(MPX .. "TUNER_GEN_BS", 12543)
    stats.set_int(MPX .. "TUNER_GEN_BS", 4351)
    stats.set_int(MPX .. "TUNER_CURRENT", 4)  end)end

  Obj_SantosT5, N1 = ImGui.DragInt("Set Money Missions 5", Obj_SantosT5, 10000, 0, 1000000) if N1 then globals.set_int(262145 + 31323 , 4) end 
  ImGui.BulletText("--------------------------------------------------------------")
  if ImGui.Button("Set The Agency Deal") then script.run_in_fiber(function(script)     
    stats.set_int(MPX .. "TUNER_GEN_BS", 12543)
    stats.set_int(MPX .. "TUNER_GEN_BS", 4351)
    stats.set_int(MPX .. "TUNER_CURRENT", 5)  end)end

  Obj_SantosT6, N1 = ImGui.DragInt("Set Money Missions 6", Obj_SantosT6, 10000, 0, 1000000) if N1 then globals.set_int(262145 + 31323 , 5) end 
  ImGui.BulletText("--------------------------------------------------------------")
  if ImGui.Button("Set The Lost Contract") then script.run_in_fiber(function(script)     
    stats.set_int(MPX .. "TUNER_GEN_BS", 12543)
    stats.set_int(MPX .. "TUNER_GEN_BS", 4351)
    stats.set_int(MPX .. "TUNER_CURRENT", 6)  end)end
  Obj_SantosT7, N1 = ImGui.DragInt("Set Money Missions 7", Obj_SantosT7, 10000, 0, 1000000) if N1 then globals.set_int(262145 + 31323 , 6) end 
  ImGui.BulletText("--------------------------------------------------------------")
  if ImGui.Button("Set The Data Contract") then script.run_in_fiber(function(script)     
    stats.set_int(MPX .. "TUNER_GEN_BS", 12543)
    stats.set_int(MPX .. "TUNER_GEN_BS", 4351)
    stats.set_int(MPX .. "TUNER_CURRENT", 7)  end)end
  Obj_SantosT8, N1 = ImGui.DragInt("Set Money Missions 8", Obj_SantosT8, 10000, 0, 1000000) if N1 then globals.set_int(262145 + 31323 , 7) end 
  ImGui.BulletText("--------------------------------------------------------------")
  
  if ImGui.Button("Reset The Preps") then script.run_in_fiber(function(script) stats.set_int(MPX .. "TUNER_GEN_BS", 30338) end)end
  if ImGui.Button("Reset The Contracts") then script.run_in_fiber(function(script) stats.set_int(MPX .. "TUNER_GEN_BS", 8371) stats.set_int(MPX .. "TUNER_CURRENT", -1) end)end
  if ImGui.Button("Reset Total Gains And Completed Contracts") then script.run_in_fiber(function(script) stats.set_int(MPX .. "TUNER_COUNT", 0) stats.set_int(MPX .. "TUNER_EARNINGS", 0) end)end 


  ImGui.EndMenu()end
  
  -------------------------------------------------------------------------------
  if ImGui.BeginMenu("Drug Wars") then
  ImGui.BulletText("--------------------------------------------------------------")
  ImGui.BulletText("                   Los Santos Drug Wars  ")
  ImGui.BulletText("--------------------------------------------------------------")
  if ImGui.Button("Set Welcome to Troupe") then script.run_in_fiber(function(script) stats.set_int(MPX .. "XM22_CURRENT", 0)end)end
  if ImGui.Button("Set Designated Driver") then script.run_in_fiber(function(script) stats.set_int(MPX .. "XM22_CURRENT", 1)end)end
  if ImGui.Button("Set Fatal Incursion") then script.run_in_fiber(function(script) stats.set_int(MPX .. "XM22_CURRENT", 2) end)end
  if ImGui.Button("Set Uncontrolled Substance") then script.run_in_fiber(function(script) stats.set_int(MPX .. "XM22_CURRENT", 3) end)end
  if ImGui.Button("Set Make War Not Love") then script.run_in_fiber(function(script) stats.set_int(MPX .. "XM22_CURRENT", 4) end)end  
  if ImGui.Button("Set Off The Rails") then script.run_in_fiber(function(script) stats.set_int(MPX .. "XM22_CURRENT", 5) end)end
      
  ImGui.BulletText("--------------------------------------------------------------")
  ImGui.BulletText("                  Los Santos Last Dose  ")
  ImGui.BulletText("--------------------------------------------------------------")
  
  if ImGui.Button("Set This is an lntervention") then script.run_in_fiber(function(script) stats.set_int(MPX .. "XM22_CURRENT", 6) end)end
  if ImGui.Button("Set Unusual Suspects") then script.run_in_fiber(function(script) stats.set_int(MPX .. "XM22_CURRENT", 7) end)end 
  if ImGui.Button("Set Friedmind") then script.run_in_fiber(function(script) stats.set_int(MPX .. "XM22_CURRENT", 8) end)end
  if ImGui.Button("Set Checking ln") then script.run_in_fiber(function(script) stats.set_int(MPX .. "XM22_CURRENT", 9) end)end 
  if ImGui.Button("Set BDKD") then script.run_in_fiber(function(script) stats.set_int(MPX .. "XM22_CURRENT", 10) end)end
  ImGui.EndMenu() 
  end  
  -------------------------------------------------------------------------------
  if ImGui.BeginMenu("ULP Missions") then
  ImGui.BulletText("--------------------------------------------------------------")
  ImGui.BulletText("                          ULP Mission  ")
  ImGui.BulletText("--------------------------------------------------------------")
  if ImGui.Button("Set Intelligence") then script.run_in_fiber(function(script) stats.set_int(MPX .. "ULP_MISSION_CURRENT", 0) stats.set_int(MPX .. "LP_MISSION_PROGRESS", 127) end)end
  if ImGui.Button("Set Counterintelligence") then script.run_in_fiber(function(script) stats.set_int(MPX .. "ULP_MISSION_CURRENT", 1) stats.set_int(MPX .. "LP_MISSION_PROGRESS", 127) end)end
  if ImGui.Button("Set Extraction") then script.run_in_fiber(function(script) stats.set_int(MPX .. "ULP_MISSION_CURRENT", 2) stats.set_int(MPX .. "LP_MISSION_PROGRESS", 127) end)end
  if ImGui.Button("Set Asset Seizure") then script.run_in_fiber(function(script) stats.set_int(MPX .. "ULP_MISSION_CURRENT", 3) stats.set_int(MPX .. "LP_MISSION_PROGRESS", 127) end)end
  if ImGui.Button("Set Operation Paper Trail") then script.run_in_fiber(function(script) stats.set_int(MPX .. "ULP_MISSION_CURRENT", 4) stats.set_int(MPX .. "LP_MISSION_PROGRESS", 127) end)end
  if ImGui.Button("Set Cleanup") then script.run_in_fiber(function(script) stats.set_int(MPX .. "ULP_MISSION_CURRENT", 5) stats.set_int(MPX .. "LP_MISSION_PROGRESS", 127) end)end
  ImGui.BulletText("--------------------------------------------------------------")
  ImGui.BulletText("                    Skip All ULP Missions  ")
  ImGui.BulletText("--------------------------------------------------------------")
  if ImGui.Button("Skip All ULP Missions") then script.run_in_fiber(function(script) stats.set_int(MPX .. "ULP_MISSION_PROGRESS", 127) stats.set_int(MPX .. "ULP_MISSION_CURRENT", 0) end)end
  ImGui.BulletText("--------------------------------------------------------------")
  ImGui.EndMenu()end
  -------------------------------------------------------------------------------
  if ImGui.BeginMenu("Yatch Missions") then
  ImGui.BulletText("--------------------------------------------------------------")
  ImGui.BulletText("                          Yatch Missions  ")
  ImGui.BulletText("--------------------------------------------------------------")
  if ImGui.Button("Set Salvage ") then script.run_in_fiber(function(script) stats.set_int(MPX .. "YACHT_MISSION_PROG", 0)end)end
  if ImGui.Button("Set Overboard") then script.run_in_fiber(function(script) stats.set_int(MPX .. "YACHT_MISSION_PROG", 1)end)end
  if ImGui.Button("Set All Hands") then script.run_in_fiber(function(script) stats.set_int(MPX .. "YACHT_MISSION_PROG", 2)end)end 
  if ImGui.Button("Set Icebreaker ") then script.run_in_fiber(function(script) stats.set_int(MPX .. "YACHT_MISSION_PROG", 3)end)end
  if ImGui.Button("Set Bon Voyage") then script.run_in_fiber(function(script) stats.set_int(MPX .. "YACHT_MISSION_PROG", 4)end)end
  if ImGui.Button("Set D-Day") then script.run_in_fiber(function(script) stats.set_int(MPX .. "YACHT_MISSION_PROG", 5)end)end
  ImGui.BulletText("--------------------------------------------------------------")
  ImGui.BulletText("                      Skip All Yatch Missions  ")
  ImGui.BulletText("--------------------------------------------------------------")
  if ImGui.Button("Skip ULP Missions") then script.run_in_fiber(function(script)
  stats.set_int(MPX .. "YACHT_MISSION_PROG", 0) 
  stats.set_int(MPX .. "YACHT_MISSION_FLOW", 21845) 
  stats.set_int(MPX .. "CASINO_DECORATION_GIFT_1", -1) 
  end)end
  
  ImGui.BulletText("--------------------------------------------------------------")
  ImGui.EndMenu()end
  

  if ImGui.BeginMenu("Casino Story Missions") then
    ImGui.BulletText("--------------------------------------------------------------")
    ImGui.BulletText("                       Casino Story Missions  ")
    ImGui.BulletText("--------------------------------------------------------------")
    if ImGui.Button("Set Loose Cheng ") then script.run_in_fiber(function(script) 
      stats.set_int(MPX .. "VCM_STORY_PROGRESS", 0) 
      stats.set_int(MPX .. "VCM_FLOW_PROGRESS", 1311695)
    end)end

    if ImGui.Button("Set House Keeping") then script.run_in_fiber(function(script) 
      stats.set_int(MPX .. "VCM_STORY_PROGRESS", 1) 
      stats.set_int(MPX .. "VCM_FLOW_PROGRESS", 1311695)
    end)end
      
    if ImGui.Button("Set Strong Arm Tactics") then script.run_in_fiber(function(script) 
      stats.set_int(MPX .. "VCM_STORY_PROGRESS", 2) 
      stats.set_int(MPX .. "VCM_FLOW_PROGRESS", 1311695)
    end)end

    if ImGui.Button("Set Play to Win ") then script.run_in_fiber(function(script) 
      stats.set_int(MPX .. "VCM_STORY_PROGRESS", 3)
      stats.set_int(MPX .. "VCM_FLOW_PROGRESS", 1311695)
    end)end

    if ImGui.Button("Set Bad Beat") then script.run_in_fiber(function(script) 
      stats.set_int(MPX .. "VCM_STORY_PROGRESS", 4) 
      stats.set_int(MPX .. "VCM_FLOW_PROGRESS", 1311695)
    end)end
    if ImGui.Button("Set Cashing Out") then script.run_in_fiber(function(script) 
      stats.set_int(MPX .. "VCM_STORY_PROGRESS", 5) 
      stats.set_int(MPX .. "VCM_FLOW_PROGRESS", 1311695)
    end)end

    ImGui.BulletText("--------------------------------------------------------------")
    ImGui.EndMenu()end

    if ImGui.BeginMenu("San Andreas Mercenaries") then
      ImGui.BulletText("--------------------------------------------------------------")
      ImGui.BulletText("               San Andreas Mercenaries Missions  ")
      ImGui.BulletText("--------------------------------------------------------------")
      if ImGui.Button("Set Reporting for Duty ") then script.run_in_fiber(function(script) 
        stats.set_int(MPX .. "SUM23_AVOP_PROGRESS", 0) 
        stats.set_int(MPX .. "SUM23_AVOP_CURRENT", 0)
      end)end
  
      if ImGui.Button("Set Falling In") then script.run_in_fiber(function(script) 
        stats.set_int(MPX .. "SUM23_AVOP_PROGRESS", 0) 
        stats.set_int(MPX .. "SUM23_AVOP_CURRENT", 1)
      end)end
        
      if ImGui.Button("Set On Parade") then script.run_in_fiber(function(script) 
        stats.set_int(MPX .. "SUM23_AVOP_PROGRESS", 0) 
        stats.set_int(MPX .. "SUM23_AVOP_CURRENT", 2)
      end)end
  
      if ImGui.Button("Set Breaking Ranks ") then script.run_in_fiber(function(script) 
        stats.set_int(MPX .. "SUM23_AVOP_PROGRESS", 0)
        stats.set_int(MPX .. "SUM23_AVOP_CURRENT", 3)
      end)end
  
      if ImGui.Button("Set Unconventional Warfare") then script.run_in_fiber(function(script) 
        stats.set_int(MPX .. "SUM23_AVOP_PROGRESS", 0) 
        stats.set_int(MPX .. "SUM23_AVOP_CURRENT", 4)
      end)end
      if ImGui.Button("SetShock & Awe") then script.run_in_fiber(function(script) 
        stats.set_int(MPX .. "SUM23_AVOP_PROGRESS", 0) 
        stats.set_int(MPX .. "SUM23_AVOP_CURRENT", 5)
      end)end
  
      ImGui.BulletText("--------------------------------------------------------------")
      ImGui.EndMenu()end

      if ImGui.BeginMenu("The Cluckin' Bell Farm Raid") then
        ImGui.BulletText("--------------------------------------------------------------")
        ImGui.BulletText("        The Cluckin' Bell Farm Raid Missions  ")
        ImGui.BulletText("--------------------------------------------------------------")
        if ImGui.Button("Set Slush Fund ") then script.run_in_fiber(function(script) 
          stats.set_int(MPX .. "SALV23_INST_PROG", 1) 
          stats.set_int(MPX .. "SALV23_CFR_COOLDOWN", -1)
        end)end
    
        if ImGui.Button("Set Breaking and Entering") then script.run_in_fiber(function(script) 
          stats.set_int(MPX .. "SALV23_INST_PROG", 2) 
          stats.set_int(MPX .. "SALV23_CFR_COOLDOWN", -1)
        end)end
          
        if ImGui.Button("Set Concealed Weapons") then script.run_in_fiber(function(script) 
          stats.set_int(MPX .. "SALV23_INST_PROG", 3) 
          stats.set_int(MPX .. "SALV23_CFR_COOLDOWN", -1)
        end)end
    
        if ImGui.Button("Set Hit and Run ") then script.run_in_fiber(function(script) 
          stats.set_int(MPX .. "SALV23_INST_PROG", 4)
          stats.set_int(MPX .. "SALV23_CFR_COOLDOWN", -1)
        end)end
    
        if ImGui.Button("Set Disorganized Crime") then script.run_in_fiber(function(script) 
          stats.set_int(MPX .. "SALV23_INST_PROG", 5) 
          stats.set_int(MPX .. "SALV23_CFR_COOLDOWN", -1)
        end)end
        if ImGui.Button("Set Scene of The Crime") then script.run_in_fiber(function(script) 
          stats.set_int(MPX .. "SALV23_INST_PROG", 6) 
          stats.set_int(MPX .. "SALV23_CFR_COOLDOWN",-1)
        end)end
    
        ImGui.BulletText("--------------------------------------------------------------")
        ImGui.EndMenu()end



  if ImGui.BeginMenu("Lamar Missions ") then
    ImGui.BulletText("--------------------------------------------------------------")
    ImGui.BulletText("                          Lamar Missions   ")
    ImGui.BulletText("--------------------------------------------------------------")
    ImGui.BulletText("You must change the server after selecting!!")
    ImGui.BulletText("--------------------------------------------------------------")
  if ImGui.Button("Set Community Outreach ") then script.run_in_fiber(function(script) stats.set_int(MPX .. "LOW_FLOW_CURRENT_PROG",0)end)end
  if ImGui.Button("Set Slow and Lowd") then script.run_in_fiber(function(script) stats.set_int(MPX .. "LOW_FLOW_CURRENT_PROG",1)end)end
  if ImGui.Button("Set It's a G Thing") then script.run_in_fiber(function(script) stats.set_int(MPX .. "LOW_FLOW_CURRENT_PROG",2)end)end
  if ImGui.Button("Set Funeral Party ") then script.run_in_fiber(function(script) stats.set_int(MPX .. "LOW_FLOW_CURRENT_PROG",3)end)end
  if ImGui.Button("Set Lowrider Envy") then script.run_in_fiber(function(script) stats.set_int(MPX .. "LOW_FLOW_CURRENT_PROG",4)end)end
  if ImGui.Button("Set Point and Shoot") then script.run_in_fiber(function(script) stats.set_int(MPX .. "LOW_FLOW_CURRENT_PROG",5)end)end
  if ImGui.Button("Set Desperate Times Call ") then script.run_in_fiber(function(script) stats.set_int(MPX .. "LOW_FLOW_CURRENT_PROG",4) end)end
  if ImGui.Button("Set Peace Offerings") then script.run_in_fiber(function(script) stats.set_int(MPX .. "LOW_FLOW_CURRENT_PROG",5)end)end
  
  ImGui.BulletText("--------------------------------------------------------------")
  ImGui.BulletText("                      Skip All Lamar Missions   ")
  ImGui.BulletText("--------------------------------------------------------------")
  if ImGui.Button("Skip Lamar Missions ") then script.run_in_fiber(function(script)
      stats.set_bool(MPX .. "LOW_FLOW_CS_DRV_SEEN", true) 
      stats.set_bool(MPX .. "LOW_FLOW_CS_TRA_SEEN", true) 
      stats.set_bool(MPX .. "LOW_FLOW_CS_FUN_SEEN", true) 
      stats.set_bool(MPX .. "LOW_FLOW_CS_PHO_SEEN", true) 
      stats.set_bool(MPX .. "LOW_FLOW_CS_FIN_SEEN", true) 
      stats.set_bool(MPX .. "LOW_BEN_INTRO_CS_SEEN", true) 
      stats.set_int(MPX .. "LOWRIDER_FLOW_COMPLETE", 4) 
      stats.set_int(MPX .. "LOW_FLOW_CURRENT_PROG", 9) 
      stats.set_int(MPX .. "LOW_FLOW_CURRENT_CALL", 9) 
      stats.set_int(MPX .. "LOW_FLOW_CS_HELPTEXT", 66)
  end)end
  
  ImGui.BulletText("--------------------------------------------------------------")
  
  ImGui.EndMenu()end
  ImGui.EndMenu()end
  
  if ImGui.BeginMenu("Allow Gender Change") then
  ImGui.BulletText("          How to use !!")
  ImGui.BulletText("( 1 ) The CEO and the club must be logged out")
  ImGui.BulletText("( 2 ) Click on (Open Gender Change)")
  ImGui.BulletText("( 3 ) Click on (Interaction Menu > Appearance > Change Appearance $100000)")
  ImGui.BulletText("( 4 ) After entering the place to modify your character, you will see (Sex) Male - Female")
  ImGui.BulletText("** Choose a character (girl or man) as you want **")
  ImGui.BulletText("                          ** Everything will be transferred without loss **")       
  ImGui.BulletText("    ** Use at your own risk **")
  if ImGui.Button("Open Gender Change") then script.run_in_fiber(function(script) stats.set_int(MPX .."ALLOW_GENDER_CHANGE", 52) end)end
  ImGui.EndMenu()end 
  
  if ImGui.BeginMenu("Delete Report") then
     ImGui.BulletText("          How to use !!")
     ImGui.BulletText("Sometimes it doesn't work")
  
  if ImGui.Button("Delete Report ( Players )") then script.run_in_fiber(function(script)
      stats.set_int("MPPLY_REPORT_STRENGTH", 0)
      stats.set_int("MPPLY_COMMEND_STRENGTH", 0)
      stats.set_int("MPPLY_GRIEFING", 0)
      stats.set_int("MPPLY_VC_ANNOYINGME", 0)
      stats.set_int("MPPLY_VC_HATE", 0)
      stats.set_int("MPPLY_TC_ANNOYINGME", 0)
      stats.set_int("MPPLY_TC_HATE", 0)
      stats.set_int("MPPLY_OFFENSIVE_LANGUAGE", 0)
      stats.set_int("MPPLY_OFFENSIVE_TAGPLATE", 0)
      stats.set_int("MPPLY_OFFENSIVE_UGC", 0)
      stats.set_int("MPPLY_BAD_CREW_NAME", 0)
      stats.set_int("MPPLY_BAD_CREW_MOTTO", 0)
      stats.set_int("MPPLY_BAD_CREW_STATUS", 0)
      stats.set_int("MPPLY_BAD_CREW_EMBLEM", 0)
      stats.set_int("MPPLY_EXPLOITS", 0)
      stats.set_int("MPPLY_BECAME_BADSPORT_NUM", 0)
      stats.set_int("MPPLY_DESTROYED_PVEHICLES", 0)
      stats.set_int("MPPLY_BADSPORT_MESSAGE", 0)
      stats.set_int("MPPLY_GAME_EXPLOITS", 0)
      stats.set_int("MPPLY_PLAYER_MENTAL_STATE", 0)
      stats.set_int("MPPLY_PLAYERMADE_TITLE", 0)
      stats.set_int("MPPLY_PLAYERMADE_DESC", 0)
      stats.set_int("MPPLY_ISPUNISHED", 0)
      stats.set_int("MPPLY_WAS_I_BAD_SPORT", 0)
      stats.set_int("MPPLY_WAS_I_CHEATER", 0)
      stats.set_int("MPPLY_CHAR_IS_BADSPORT", 0)
      stats.set_int("MPPLY_OVERALL_BADSPORT", 0)
      stats.set_int("MPPLY_OVERALL_CHEAT", 0)
      stats.set_int("MPPLY_HELPFUL", 0)
      stats.set_int("MPPLY_FRIENDLY", 0)
      stats.set_int("MPPLY_CHEAT_BITSET", 0)
      stats.set_int("MPPLY_CHEAT_ISPUNISHED", 0)
    end)end
  
  ImGui.EndMenu()end
  
  if ImGui.BeginMenu("Remove Cooldown") then 
  
  if ImGui.Button("Remove Cooldown Orbital Cannon")  then script.run_in_fiber(function(script)
    stats.set_int(MPX .. "ORBITAL_CANNON_COOLDOWN", 0) 
    stats.set_int(MPX .. "ORBITAL_CANNON_COOLDOWN", 1)
  end)end
  if ImGui.Button("Removed Cooldown Missions Dax")  then script.run_in_fiber(function(script)
    stats.set_int(MPX .. "_XM22JUGGALOWORKCDTIMER", -1) 
  end)end
  if ImGui.Button("Remove VIP/MC Cool Down")  then script.run_in_fiber(function(script)
    stats.set_int('MPPLY_VIPGAMEPLAYDISABLEDTIMER', 0)
    stats.set_int('MPPLY_VIPGAMEPLAYDISABLEDTIMER', 1)
  end)end
  
  if ImGui.Button("Remove Cooldown Buy Chips")  then script.run_in_fiber(function(script)
    stats.set_int("MPPLY_CASINO_CHIPS_PUR_GD", 0)
    stats.set_int("MPPLY_CASINO_CHIPS_PURTIM", 0)
  end)end
  
  ImGui.EndMenu()end
  ImGui.EndMenu()end
  -----------------------------------------------------------------------------------------------------------------------------
  if ImGui.BeginMenu("Recovery") then 
  
  if ImGui.BeginMenu("Speciaal Cargo ( Options )") then 
  RecoverysG = 15732
  ImGui.BulletText(" $$  Every 24 hours 4 million!  $$ ")
      
  if ImGui.Button(" Set Cargo +100k") then script.run_in_fiber(function(script)
  KingS = 100000
  globals.set_int(262145+RecoverysG, KingS//1)globals.set_int(262145+RecoverysG+1, KingS//2)globals.set_int(262145+RecoverysG+2, KingS//3)globals.set_int(262145+RecoverysG+3, KingS//5)globals.set_int(262145+RecoverysG+4, KingS//7)globals.set_int(262145+RecoverysG+5, KingS//9) globals.set_int(262145+RecoverysG+6, KingS//14)globals.set_int(262145+RecoverysG+7, KingS//19)globals.set_int(262145+RecoverysG+8, KingS//24)globals.set_int(262145+RecoverysG+9, KingS//29)globals.set_int(262145+RecoverysG+10, KingS//34)globals.set_int(262145+RecoverysG+11, KingS//39)globals.set_int(262145+RecoverysG+12, KingS//44)globals.set_int(262145+RecoverysG+13, KingS//49)globals.set_int(262145+RecoverysG+14, KingS//59)globals.set_int(262145+RecoverysG+15, KingS//69)globals.set_int(262145+RecoverysG+16, KingS//79)globals.set_int(262145+RecoverysG+17, KingS//89)globals.set_int(262145+RecoverysG+18, KingS//99)globals.set_int(262145+RecoverysG+19, KingS//110)globals.set_int(262145+RecoverysG+20, KingS//111)
  end)end
          
  if ImGui.Button(" Set Cargo +250k") then script.run_in_fiber(function(script)
  KingS = 250000
  globals.set_int(262145+RecoverysG, KingS//1)globals.set_int(262145+RecoverysG+1, KingS//2)globals.set_int(262145+RecoverysG+2, KingS//3)globals.set_int(262145+RecoverysG+3, KingS//5)globals.set_int(262145+RecoverysG+4, KingS//7)globals.set_int(262145+RecoverysG+5, KingS//9) globals.set_int(262145+RecoverysG+6, KingS//14)globals.set_int(262145+RecoverysG+7, KingS//19)globals.set_int(262145+RecoverysG+8, KingS//24)globals.set_int(262145+RecoverysG+9, KingS//29)globals.set_int(262145+RecoverysG+10, KingS//34)globals.set_int(262145+RecoverysG+11, KingS//39)globals.set_int(262145+RecoverysG+12, KingS//44)globals.set_int(262145+RecoverysG+13, KingS//49)globals.set_int(262145+RecoverysG+14, KingS//59)globals.set_int(262145+RecoverysG+15, KingS//69)globals.set_int(262145+RecoverysG+16, KingS//79)globals.set_int(262145+RecoverysG+17, KingS//89)globals.set_int(262145+RecoverysG+18, KingS//99)globals.set_int(262145+RecoverysG+19, KingS//110)globals.set_int(262145+RecoverysG+20, KingS//111)
  end)end
          
  if ImGui.Button(" Set Cargo +500k") then script.run_in_fiber(function(script)
  KingS = 500000
   globals.set_int(262145+RecoverysG, KingS//1)globals.set_int(262145+RecoverysG+1, KingS//2)globals.set_int(262145+RecoverysG+2, KingS//3)globals.set_int(262145+RecoverysG+3, KingS//5)globals.set_int(262145+RecoverysG+4, KingS//7)globals.set_int(262145+RecoverysG+5, KingS//9) globals.set_int(262145+RecoverysG+6, KingS//14)globals.set_int(262145+RecoverysG+7, KingS//19)globals.set_int(262145+RecoverysG+8, KingS//24)globals.set_int(262145+RecoverysG+9, KingS//29)globals.set_int(262145+RecoverysG+10, KingS//34)globals.set_int(262145+RecoverysG+11, KingS//39)globals.set_int(262145+RecoverysG+12, KingS//44)globals.set_int(262145+RecoverysG+13, KingS//49)globals.set_int(262145+RecoverysG+14, KingS//59)globals.set_int(262145+RecoverysG+15, KingS//69)globals.set_int(262145+RecoverysG+16, KingS//79)globals.set_int(262145+RecoverysG+17, KingS//89)globals.set_int(262145+RecoverysG+18, KingS//99)globals.set_int(262145+RecoverysG+19, KingS//110)globals.set_int(262145+RecoverysG+20, KingS//111)
  end)end
          
  if ImGui.Button(" Set Cargo +750k") then script.run_in_fiber(function(script)
  KingS = 750000
  globals.set_int(262145+RecoverysG, KingS//1)globals.set_int(262145+RecoverysG+1, KingS//2)globals.set_int(262145+RecoverysG+2, KingS//3)globals.set_int(262145+RecoverysG+3, KingS//5)globals.set_int(262145+RecoverysG+4, KingS//7)globals.set_int(262145+RecoverysG+5, KingS//9) globals.set_int(262145+RecoverysG+6, KingS//14)globals.set_int(262145+RecoverysG+7, KingS//19)globals.set_int(262145+RecoverysG+8, KingS//24)globals.set_int(262145+RecoverysG+9, KingS//29)globals.set_int(262145+RecoverysG+10, KingS//34)globals.set_int(262145+RecoverysG+11, KingS//39)globals.set_int(262145+RecoverysG+12, KingS//44)globals.set_int(262145+RecoverysG+13, KingS//49)globals.set_int(262145+RecoverysG+14, KingS//59)globals.set_int(262145+RecoverysG+15, KingS//69)globals.set_int(262145+RecoverysG+16, KingS//79)globals.set_int(262145+RecoverysG+17, KingS//89)globals.set_int(262145+RecoverysG+18, KingS//99)globals.set_int(262145+RecoverysG+19, KingS//110)globals.set_int(262145+RecoverysG+20, KingS//111)
  end)end
          
  if ImGui.Button(" Set Cargo +1M") then script.run_in_fiber(function(script)
  KingS = 1000000
  globals.set_int(262145+RecoverysG, KingS//1)globals.set_int(262145+RecoverysG+1, KingS//2)globals.set_int(262145+RecoverysG+2, KingS//3)globals.set_int(262145+RecoverysG+3, KingS//5)globals.set_int(262145+RecoverysG+4, KingS//7)globals.set_int(262145+RecoverysG+5, KingS//9) globals.set_int(262145+RecoverysG+6, KingS//14)globals.set_int(262145+RecoverysG+7, KingS//19)globals.set_int(262145+RecoverysG+8, KingS//24)globals.set_int(262145+RecoverysG+9, KingS//29)globals.set_int(262145+RecoverysG+10, KingS//34)globals.set_int(262145+RecoverysG+11, KingS//39)globals.set_int(262145+RecoverysG+12, KingS//44)globals.set_int(262145+RecoverysG+13, KingS//49)globals.set_int(262145+RecoverysG+14, KingS//59)globals.set_int(262145+RecoverysG+15, KingS//69)globals.set_int(262145+RecoverysG+16, KingS//79)globals.set_int(262145+RecoverysG+17, KingS//89)globals.set_int(262145+RecoverysG+18, KingS//99)globals.set_int(262145+RecoverysG+19, KingS//110)globals.set_int(262145+RecoverysG+20, KingS//111)
  end)end
          
  if ImGui.Button(" Set Cargo +2M") then script.run_in_fiber(function(script)
  KingS = 2000000
  globals.set_int(262145+RecoverysG, KingS//1)globals.set_int(262145+RecoverysG+1, KingS//2)globals.set_int(262145+RecoverysG+2, KingS//3)globals.set_int(262145+RecoverysG+3, KingS//5)globals.set_int(262145+RecoverysG+4, KingS//7)globals.set_int(262145+RecoverysG+5, KingS//9) globals.set_int(262145+RecoverysG+6, KingS//14)globals.set_int(262145+RecoverysG+7, KingS//19)globals.set_int(262145+RecoverysG+8, KingS//24)globals.set_int(262145+RecoverysG+9, KingS//29)globals.set_int(262145+RecoverysG+10, KingS//34)globals.set_int(262145+RecoverysG+11, KingS//39)globals.set_int(262145+RecoverysG+12, KingS//44)globals.set_int(262145+RecoverysG+13, KingS//49)globals.set_int(262145+RecoverysG+14, KingS//59)globals.set_int(262145+RecoverysG+15, KingS//69)globals.set_int(262145+RecoverysG+16, KingS//79)globals.set_int(262145+RecoverysG+17, KingS//89)globals.set_int(262145+RecoverysG+18, KingS//99)globals.set_int(262145+RecoverysG+19, KingS//110)globals.set_int(262145+RecoverysG+20, KingS//111)
  end)end
          
  if ImGui.Button(" Set Cargo +3M") then script.run_in_fiber(function(script)
  KingS = 3000000
  globals.set_int(262145+RecoverysG, KingS//1)globals.set_int(262145+RecoverysG+1, KingS//2)globals.set_int(262145+RecoverysG+2, KingS//3)globals.set_int(262145+RecoverysG+3, KingS//5)globals.set_int(262145+RecoverysG+4, KingS//7)globals.set_int(262145+RecoverysG+5, KingS//9) globals.set_int(262145+RecoverysG+6, KingS//14)globals.set_int(262145+RecoverysG+7, KingS//19)globals.set_int(262145+RecoverysG+8, KingS//24)globals.set_int(262145+RecoverysG+9, KingS//29)globals.set_int(262145+RecoverysG+10, KingS//34)globals.set_int(262145+RecoverysG+11, KingS//39)globals.set_int(262145+RecoverysG+12, KingS//44)globals.set_int(262145+RecoverysG+13, KingS//49)globals.set_int(262145+RecoverysG+14, KingS//59)globals.set_int(262145+RecoverysG+15, KingS//69)globals.set_int(262145+RecoverysG+16, KingS//79)globals.set_int(262145+RecoverysG+17, KingS//89)globals.set_int(262145+RecoverysG+18, KingS//99)globals.set_int(262145+RecoverysG+19, KingS//110)globals.set_int(262145+RecoverysG+20, KingS//111)
  end)end
          
  if ImGui.Button(" Set Cargo +4M") then script.run_in_fiber(function(script)
  KingS = 4000000
  globals.set_int(262145+RecoverysG, KingS//1)globals.set_int(262145+RecoverysG+1, KingS//2)globals.set_int(262145+RecoverysG+2, KingS//3)globals.set_int(262145+RecoverysG+3, KingS//5)globals.set_int(262145+RecoverysG+4, KingS//7)globals.set_int(262145+RecoverysG+5, KingS//9) globals.set_int(262145+RecoverysG+6, KingS//14)globals.set_int(262145+RecoverysG+7, KingS//19)globals.set_int(262145+RecoverysG+8, KingS//24)globals.set_int(262145+RecoverysG+9, KingS//29)globals.set_int(262145+RecoverysG+10, KingS//34)globals.set_int(262145+RecoverysG+11, KingS//39)globals.set_int(262145+RecoverysG+12, KingS//44)globals.set_int(262145+RecoverysG+13, KingS//49)globals.set_int(262145+RecoverysG+14, KingS//59)globals.set_int(262145+RecoverysG+15, KingS//69)globals.set_int(262145+RecoverysG+16, KingS//79)globals.set_int(262145+RecoverysG+17, KingS//89)globals.set_int(262145+RecoverysG+18, KingS//99)globals.set_int(262145+RecoverysG+19, KingS//110)globals.set_int(262145+RecoverysG+20, KingS//111)
  end)end
          
  if ImGui.Button(" Set Cargo +5M") then script.run_in_fiber(function(script)
  KingS = 5000000
  globals.set_int(262145+RecoverysG, KingS//1)globals.set_int(262145+RecoverysG+1, KingS//2)globals.set_int(262145+RecoverysG+2, KingS//3)globals.set_int(262145+RecoverysG+3, KingS//5)globals.set_int(262145+RecoverysG+4, KingS//7)globals.set_int(262145+RecoverysG+5, KingS//9) globals.set_int(262145+RecoverysG+6, KingS//14)globals.set_int(262145+RecoverysG+7, KingS//19)globals.set_int(262145+RecoverysG+8, KingS//24)globals.set_int(262145+RecoverysG+9, KingS//29)globals.set_int(262145+RecoverysG+10, KingS//34)globals.set_int(262145+RecoverysG+11, KingS//39)globals.set_int(262145+RecoverysG+12, KingS//44)globals.set_int(262145+RecoverysG+13, KingS//49)globals.set_int(262145+RecoverysG+14, KingS//59)globals.set_int(262145+RecoverysG+15, KingS//69)globals.set_int(262145+RecoverysG+16, KingS//79)globals.set_int(262145+RecoverysG+17, KingS//89)globals.set_int(262145+RecoverysG+18, KingS//99)globals.set_int(262145+RecoverysG+19, KingS//110)globals.set_int(262145+RecoverysG+20, KingS//111)
  end)end
          
  if ImGui.Button(" Set Cargo +6M") then script.run_in_fiber(function(script)
  KingS = 6000000
  globals.set_int(262145+RecoverysG, KingS//1)globals.set_int(262145+RecoverysG+1, KingS//2)globals.set_int(262145+RecoverysG+2, KingS//3)globals.set_int(262145+RecoverysG+3, KingS//5)globals.set_int(262145+RecoverysG+4, KingS//7)globals.set_int(262145+RecoverysG+5, KingS//9) globals.set_int(262145+RecoverysG+6, KingS//14)globals.set_int(262145+RecoverysG+7, KingS//19)globals.set_int(262145+RecoverysG+8, KingS//24)globals.set_int(262145+RecoverysG+9, KingS//29)globals.set_int(262145+RecoverysG+10, KingS//34)globals.set_int(262145+RecoverysG+11, KingS//39)globals.set_int(262145+RecoverysG+12, KingS//44)globals.set_int(262145+RecoverysG+13, KingS//49)globals.set_int(262145+RecoverysG+14, KingS//59)globals.set_int(262145+RecoverysG+15, KingS//69)globals.set_int(262145+RecoverysG+16, KingS//79)globals.set_int(262145+RecoverysG+17, KingS//89)globals.set_int(262145+RecoverysG+18, KingS//99)globals.set_int(262145+RecoverysG+19, KingS//110)globals.set_int(262145+RecoverysG+20, KingS//111)
  end)end
  
  ImGui.BulletText("--------------------------------------------------------------")
  
  if ImGui.Button("Insta Finish Sell Mission") then script.run_in_fiber(function(script)
        if SCRIPT.GET_NUMBER_OF_THREADS_RUNNING_THE_SCRIPT_WITH_THIS_HASH(joaat("gb_contraband_sell")) ~= 0 then
            locals.set_int("gb_contraband_sell", 545 + 1, 99999)
        end
    end)
  end
  if ImGui.Button("Insta Finish Buy Mission") then script.run_in_fiber(function(script)
    if SCRIPT.GET_NUMBER_OF_THREADS_RUNNING_THE_SCRIPT_WITH_THIS_HASH(joaat("gb_contraband_buy")) ~= 0 then
        locals.set_int("gb_contraband_buy", 603 + 192, 4)
    end
end)
end

  ImGui.BulletText("--------------------------------------------------------------")

  if ImGui.Button("Remove Buy Cooldown") then script.run_in_fiber(function(script) globals.set_int(262145+15499,0) end) end  
  if ImGui.Button("Remove Sell Cooldown") then script.run_in_fiber(function(script) globals.set_int(262145+15500, 0) end) end  

  ------------------------------------------------------------------------------------------------------------------------------------------------  
   ImGui.EndMenu() end
  if ImGui.BeginMenu("Nightclub Cargo ( Options )") then
  
  if ImGui.Button("Max Nightclub Popularity") then script.run_in_fiber(function(script)
  stats.set_int(MPX .. "CLUB_POPULARITY", 1000)
  end)end
      
  if ImGui.BeginMenu("Nightclub Loop Money") then
  
  ImGui.BulletText("                                    How to use !!")
  ImGui.BulletText(" You must be in front of the money vault in NightClub, then press (On)")
  ImGui.BulletText("  I do not advise you to reach more than 2 million every 24 hours!")
  ImGui.BulletText("                            Used at your own risk!!")
        
  Checkbox, Toggled = ImGui.Checkbox("On / Off", checkbox)
  script.register_looped("nightclubloop", function(script)
  script:yield()
  if Checkbox then
   log.info("Starting")
  STATS.STAT_SET_INT(joaat(King_1), 1000, true)
  STATS.STAT_SET_INT(joaat(King_2), -1, true)
   log.info("Finished")
  script:sleep(2500)
            end
          end)
  
  ImGui.EndMenu() end      
  if ImGui.BeginMenu("Set Money Nightclub Cargo") then 
          
  ImGui.BulletText(" $$  Every 24 hours 3 million!  $$ ") 
  Obj_Nightclcub_1, N1 = ImGui.DragInt("Sporting Goods", Obj_Nightclcub_1, 10000, 0, 3000000) if N1 then globals.set_int(262145 + Money_Nightclcub_1, Obj_Nightclcub_1) end
  Obj_Nightclcub_2, N2 = ImGui.DragInt("South American Imports", Obj_Nightclcub_2, 10000, 0, 3000000) if N2 then globals.set_int(262145 + Money_Nightclcub_2, Obj_Nightclcub_2) end
  Obj_Nightclcub_3, N3 = ImGui.DragInt("Pharmaceutical Research", Obj_Nightclcub_3, 10000, 0, 3000000) if N3 then globals.set_int(262145 + Money_Nightclcub_3, Obj_Nightclcub_3) end
  Obj_Nightclcub_4, N4 = ImGui.DragInt("Organic Produce", Obj_Nightclcub_4, 10000, 0, 3000000) if N4 then globals.set_int(262145 + Money_Nightclcub_4, Obj_Nightclcub_4) end
  Obj_Nightclcub_5, N5 = ImGui.DragInt("Printing & Copying", Obj_Nightclcub_5, 10000, 0, 3000000) if N5 then globals.set_int(262145 + Money_Nightclcub_5, Obj_Nightclcub_5) end
  Obj_Nightclcub_6, N6 = ImGui.DragInt("Cash Creation", Obj_Nightclcub_6, 10000, 0, 3000000) if N6 then globals.set_int(262145 + Money_Nightclcub_6, Obj_Nightclcub_6) end
  Obj_Nightclcub_7, N7 = ImGui.DragInt("Gargo & Shipments", Obj_Nightclcub_7, 10000, 0, 3000000) if N7 then globals.set_int(262145 + Money_Nightclcub_7, Obj_Nightclcub_7) end
  ImGui.EndMenu() end

  -----------------------------------------------------------------------------------------------------------------------------------------------
  ImGui.EndMenu() end   
  if ImGui.BeginMenu("Hanger Cargo ( Options )") then
  ImGui.BulletText(" $$  Every 24 hours 3 million!  $$ ")    
  Obj_Hanger_1, N1 = ImGui.DragInt("Animal Material", Obj_Hanger_1, 10000, 0, 3000000) if N1 then globals.set_int(262145 +Money_Hanger_1, Obj_Hanger_1) end
  Obj_Hanger_2, N2 = ImGui.DragInt("Art n Antiques", Obj_Hanger_2, 10000, 0, 3000000) if N2 then globals.set_int(262145 +Money_Hanger_2, Obj_Hanger_2) end
  Obj_Hanger_3, N3 = ImGui.DragInt("Chemicals", Obj_Hanger_3, 10000, 0, 3000000) if N3 then globals.set_int(262145 +Money_Hanger_3, Obj_Hanger_3) end
  Obj_Hanger_4, N3 = ImGui.DragInt("Counterfeit", Obj_Hanger_4, 10000, 0, 3000000)  if N3 then globals.set_int(262145 +Money_Hanger_4, Obj_Hanger_4) end
  Obj_Hanger_5, N3 = ImGui.DragInt("Jewelry", Obj_Hanger_5, 10000, 0, 3000000) if N3 then globals.set_int(262145 +Money_Hanger_5, Obj_Hanger_5) end
  Obj_Hanger_6, N3 = ImGui.DragInt("Medical Sup", Obj_Hanger_6, 10000, 0, 3000000) if N3 then globals.set_int(262145 +Money_Hanger_6, Obj_Hanger_6) end
  Obj_Hanger_7, N3 = ImGui.DragInt("Narcotics", Obj_Hanger_7, 10000, 0, 3000000) if N3 then globals.set_int(262145 +Money_Hanger_7, Obj_Hanger_7) end
  Obj_Hanger_8, N3 = ImGui.DragInt("Tabacco", Obj_Hanger_8, 10000, 0, 3000000) if N3 then globals.set_int(262145 +Money_Hanger_8, Obj_Hanger_8) end


  ImGui.BulletText("--------------------------------------------------------------")
  if ImGui.Button("Insta Finish Sell ( Hanger Cargo )") then
    script.run_in_fiber(function(script)
        if SCRIPT.GET_NUMBER_OF_THREADS_RUNNING_THE_SCRIPT_WITH_THIS_HASH(joaat("gb_gunrunning")) ~= 0 then
            locals.set_int("gb_gunrunning", HF01 + 774, 0)
        end
    end)
  end

  ------------------------------------------------------------------------------------------------------------------------------------------------
  ImGui.EndMenu() end
      
  if ImGui.BeginMenu("Acid Lab ( Options )") then   
  ImGui.BulletText(" $$  Every 24 hours 2 million!  $$ ") 
  if ImGui.Button("Acid Lab / Resupply ") then script.run_in_fiber(function(script) globals.set_int(1663174 + 7,1) end) end 
  if ImGui.Button("Acid Lab Equipment Upgrade ") then script.run_in_fiber(function(script) stats.set_int(MPX .. "AWD_CALLME",10) end)end   
  ImGui.BulletText("--------------------------------------------------------------")
  ImGui.BulletText(" $$  Increase selling price$$ ") 
  ImGui.BulletText("--------------------------------------------------------------")
  Obj_Acid_1, N1 = ImGui.DragInt("Product", Obj_Acid_1, 500, 0, 20000) if N1 then globals.set_int(262145 +Money_Acid_1, Obj_Acid_1) end     
  ImGui.BulletText("--------------------------------------------------------------")
  ImGui.BulletText(" $$  Insta Finish Sell $$ ") 
  ImGui.BulletText("--------------------------------------------------------------")
  if ImGui.Button("Insta Finish Sell Acid Lab Business", 200, 0) then
    script.run_in_fiber(function(script)
       if SCRIPT.GET_NUMBER_OF_THREADS_RUNNING_THE_SCRIPT_WITH_THIS_HASH(joaat("fm_content_acid_lab_sell")) ~= 0 then
       locals.set_int("fm_content_acid_lab_sell", 5483 + 1358 + 2, 9)
       locals.set_int("fm_content_acid_lab_sell", 5483 + 1358 + 3, 10)
       locals.set_int("fm_content_acid_lab_sell", 5483 + 1293, 2)
       end
    end)
 end

  ------------------------------------------------------------------------------------------------------------------------------------------------
  ImGui.EndMenu() end
  if ImGui.BeginMenu("Vehicle Cargo ") then           
  ImGui.BulletText(" $$  Every 1 hour 300 thousand!  $$ ") 
  Obj_Vehicle_Cargo_1, N1 = ImGui.DragInt("Sell Vehicle ( Privat )", Obj_Vehicle_Cargo_1, 500, 0, 300000) if N1 then globals.set_int(262145 +Money_Vehicle_Cargo_1, Obj_Vehicle_Cargo_1) end     
  Obj_Vehicle_Cargo_2, N1 = ImGui.DragInt("Sell Vehicle ( Showroom )", Obj_Vehicle_Cargo_2, 500, 0, 300000) if N1 then globals.set_int(262145 +Money_Vehicle_Cargo_2, Obj_Vehicle_Cargo_2) end   
  Obj_Vehicle_Cargo_3, N1 = ImGui.DragInt("Sell Vehicle ( Specialist)", Obj_Vehicle_Cargo_3, 500, 0, 300000) if N1 then globals.set_int(262145 +Money_Vehicle_Cargo_3, Obj_Vehicle_Cargo_3) end   

  ------------------------------------------------------------------------------------------------------------------------------------------------
      ImGui.EndMenu() end
      if ImGui.BeginMenu("Vehicle Auto Shop ") then
  ImGui.BulletText(" $$  Infinity 100 thousand!  $$ ") 
  Obj_Vehicle_Auto_1, N1 = ImGui.DragInt("Low Tier Delivery", Obj_Vehicle_Auto_1, 500, 0, 120000) if N1 then globals.set_int(262145 +Money_Vehicle_Auto_1, Obj_Vehicle_Auto_1) end     
  Obj_Vehicle_Auto_2, N1 = ImGui.DragInt("Mid Tier Delivery", Obj_Vehicle_Auto_2, 500, 0, 120000) if N1 then globals.set_int(262145 +Money_Vehicle_Auto_2, Obj_Vehicle_Auto_2) end   
  Obj_Vehicle_Auto_3, N1 = ImGui.DragInt("High Tier Delivery", Obj_Vehicle_Auto_3, 500, 0, 120000) if N1 then globals.set_int(262145 +Money_Vehicle_Auto_3, Obj_Vehicle_Auto_3) end   

  ------------------------------------------------------------------------------------------------------------------------------------------------
      ImGui.EndMenu() end
      if ImGui.BeginMenu("MC Club ( Options )") then    
      if ImGui.Button("MC / Resupply Cash") then script.run_in_fiber(function(script) globals.set_int(1663174 + 1,1) end) end  
      if ImGui.Button("MC / Resupply Coke") then script.run_in_fiber(function(script) globals.set_int(1663174 + 2,1) end) end  
      if ImGui.Button("MC / Resupply Weed") then script.run_in_fiber(function(script) globals.set_int(1663174 + 3,1) end) end  
      if ImGui.Button("MC / Resupply Meth") then script.run_in_fiber(function(script) globals.set_int(1663174 + 4,1) end) end  
      if ImGui.Button("MC / Resupply Documents") then script.run_in_fiber(function(script) globals.set_int(1663174 + 5,1) end) end  
      ImGui.BulletText("--------------------------------------------------------------")
   
    if ImGui.Button("Insta Finish Sell Mission ( MC )") then script.run_in_fiber(function(script)
            if SCRIPT.GET_NUMBER_OF_THREADS_RUNNING_THE_SCRIPT_WITH_THIS_HASH(joaat("gb_biker_contraband_sell")) ~= 0 then
                locals.set_int("gb_biker_contraband_sell", 704 + 122, 17)
            end
        end)
      end
  
  ImGui.EndMenu()
  end
  ------------------------------------------------------------------------------------------------------------------------------------------------
  
  if ImGui.BeginMenu("Bunker ( Options )") then  
  if ImGui.Button("Bunker / Resupply ") then script.run_in_fiber(function(script) globals.set_int(1662874 + 6,1) end) end  
  
  ImGui.BulletText("--------------------------------------------------------------")
  if ImGui.Button("Insta Finish Sell Mission ( Bunker )") then
    script.run_in_fiber(function(script)
        if SCRIPT.GET_NUMBER_OF_THREADS_RUNNING_THE_SCRIPT_WITH_THIS_HASH(joaat("gb_gunrunning")) ~= 0 then
            locals.set_int("gb_gunrunning", BF01 + 774, 0)
        end
    end)
  end
  
  ImGui.EndMenu()
  end
  ------------------------------------------------------------------------------------------------------------------------------------------------
  if ImGui.BeginMenu("Money Loop !!Risk!! ") then

  ImGui.BulletText(" It doesn't work with the new update !") 
 ImGui.BulletText(" It will be updated soon!") 
  -- if ImGui.Button("Get 1 Mmillion") then script.run_in_fiber(function(script)
  --         globals.set_int(4537212+ 1, 2147483646)
   --        globals.set_int(4537212+ 7, 2147483647)
   --        globals.set_int(4537212+ 6, 0)
    --       globals.set_int(4537212+ 5, 0)
    --       globals.set_int(4537212+ 3, 0x615762F1)
    --       globals.set_int(4537212+ 2, 1000000)
    --       globals.set_int(4537212,2)
  -- end)end
   --if ImGui.Button("Get 15 Mmillion!!!") then script.run_in_fiber(function(script)
   --        globals.set_int(4537212+ 1, 2147483646)
     --      globals.set_int(4537212+ 7, 2147483647)
    ----        globals.set_int(4537212+ 6, 0)
    --       globals.set_int(4537212+ 5, 0)
     --      globals.set_int(4537212+ 3, 0x176D9D54)
      --     globals.set_int(4537212+ 2, 15000000)
     --      globals.set_int(4537212,2)
    --   end)end

  if ImGui.Button("Get 500K Orbital Refund ") then script.run_in_fiber(function(script) globals.set_int(1962237 ,1)end)end
--  if ImGui.Button("Get 5K Chips (Casino)") then script.run_in_fiber(function(script) globals.set_int(1963515,1)end)end

  ImGui.EndMenu() end
  ------------------------------------------------------------------------------------------------------------------------------------------------
  if ImGui.BeginMenu("Set Skills ") then
  if ImGui.Button("Stamina ") then script.run_in_fiber(function(script) stats.set_int(MPX .. "SCRIPT_INCREASE_STAM",100)end)end
  if ImGui.Button("Strength ") then script.run_in_fiber(function(script) stats.set_int(MPX .. "SCRIPT_INCREASE_STRN",100)end)end 
  if ImGui.Button("Shooting ") then script.run_in_fiber(function(script) stats.set_int(MPX .. "SCRIPT_INCREASE_SHO",100)end)end
  if ImGui.Button("Stealth ") then script.run_in_fiber(function(script) stats.set_int(MPX .. "SCRIPT_INCREASE_STL",100)end)end
  if ImGui.Button("Flying ") then script.run_in_fiber(function(script) stats.set_int(MPX .. "SCRIPT_INCREASE_FLY",100)end)end
  if ImGui.Button("Driving ") then script.run_in_fiber(function(script) stats.set_int(MPX .. "SCRIPT_INCREASE_DRIV",100)end)end
  if ImGui.Button("Lung Capaciy") then script.run_in_fiber(function(script) stats.set_int(MPX .. "SCRIPT_INCREASE_LUNG",100)end)end
------------------------------------------------------------------------------------------------------------------------------------------------
ImGui.EndMenu()end

if ImGui.BeginMenu("Set Level Rank ") then
  ImGui.BulletText("               How to use !!")
  ImGui.BulletText("It is not recommended to exceed 1000")
  ImGui.BulletText("After selecting Level, change the server")
  ImGui.BulletText("        ** Use at your own risk **")
  if ImGui.Button("Set 25 Rank") then script.run_in_fiber(function(script) stats.set_int(MPX .. "CHAR_SET_RP_GIFT_ADMIN", 127100 )end)end
  if ImGui.Button("Set 75 Rank") then script.run_in_fiber(function(script) stats.set_int(MPX .. "CHAR_SET_RP_GIFT_ADMIN", 938700 )end)end
  if ImGui.Button("Set 120 Rank") then script.run_in_fiber(function(script) stats.set_int(MPX .. "CHAR_SET_RP_GIFT_ADMIN", 2165850 )end)end
  if ImGui.Button("Set 150 Rank") then script.run_in_fiber(function(script) stats.set_int(MPX .. "CHAR_SET_RP_GIFT_ADMIN", 3075600 )end)end
  if ImGui.Button("Set 200 Rank") then script.run_in_fiber(function(script) stats.set_int(MPX .. "CHAR_SET_RP_GIFT_ADMIN", 4691850 )end)end
  if ImGui.Button("Set 250 Rank") then script.run_in_fiber(function(script) stats.set_int(MPX .. "CHAR_SET_RP_GIFT_ADMIN", 6433100 )end)end
  if ImGui.Button("Set 300 Rank") then script.run_in_fiber(function(script) stats.set_int(MPX .. "CHAR_SET_RP_GIFT_ADMIN", 8299350 )end)end
  if ImGui.Button("Set 350 Rank") then script.run_in_fiber(function(script) stats.set_int(MPX .. "CHAR_SET_RP_GIFT_ADMIN", 10290600 )end)end
  if ImGui.Button("Set 400 Rank") then script.run_in_fiber(function(script) stats.set_int(MPX .. "CHAR_SET_RP_GIFT_ADMIN", 12406850 )end)end
  if ImGui.Button("Set 450 Rank") then script.run_in_fiber(function(script) stats.set_int(MPX .. "CHAR_SET_RP_GIFT_ADMIN", 14648100 )end)end
  if ImGui.Button("Set 500 Rank") then script.run_in_fiber(function(script) stats.set_int(MPX .. "CHAR_SET_RP_GIFT_ADMIN", 17014350 )end)end
  if ImGui.Button("Set 550 Rank") then script.run_in_fiber(function(script) stats.set_int(MPX .. "CHAR_SET_RP_GIFT_ADMIN", 19505600 )end)end
  if ImGui.Button("Set 600 Rank") then script.run_in_fiber(function(script) stats.set_int(MPX .. "CHAR_SET_RP_GIFT_ADMIN", 22121850 )end)end
  if ImGui.Button("Set 650 Rank") then script.run_in_fiber(function(script) stats.set_int(MPX .. "CHAR_SET_RP_GIFT_ADMIN", 24863100 )end)end
  if ImGui.Button("Set 700 Rank") then script.run_in_fiber(function(script) stats.set_int(MPX .. "CHAR_SET_RP_GIFT_ADMIN", 27729350 )end)end
  if ImGui.Button("Set 750 Rank") then script.run_in_fiber(function(script) stats.set_int(MPX .. "CHAR_SET_RP_GIFT_ADMIN", 30720600 )end)end
  if ImGui.Button("Set 800 Rank") then script.run_in_fiber(function(script) stats.set_int(MPX .. "CHAR_SET_RP_GIFT_ADMIN", 33836850 )end)end
  if ImGui.Button("Set 850 Rank") then script.run_in_fiber(function(script) stats.set_int(MPX .. "CHAR_SET_RP_GIFT_ADMIN", 37078100 )end)end
  if ImGui.Button("Set 900 Rank") then script.run_in_fiber(function(script) stats.set_int(MPX .. "CHAR_SET_RP_GIFT_ADMIN", 40444350 )end)end
  if ImGui.Button("Set 950 Rank") then script.run_in_fiber(function(script) stats.set_int(MPX .. "CHAR_SET_RP_GIFT_ADMIN", 43935600 )end)end
  if ImGui.Button("Set 1000 Rank") then script.run_in_fiber(function(script) stats.set_int(MPX .. "CHAR_SET_RP_GIFT_ADMIN", 47551850 )end)end
  if ImGui.Button("Set 1050 Rank") then script.run_in_fiber(function(script) stats.set_int(MPX .. "CHAR_SET_RP_GIFT_ADMIN", 51293100 )end)end
  if ImGui.Button("Set 1100 Rank") then script.run_in_fiber(function(script) stats.set_int(MPX .. "CHAR_SET_RP_GIFT_ADMIN", 55159350 )end)end
  if ImGui.Button("Set 1150 Rank") then script.run_in_fiber(function(script) stats.set_int(MPX .. "CHAR_SET_RP_GIFT_ADMIN", 59150600 )end)end
  if ImGui.Button("Set 1200 Rank") then script.run_in_fiber(function(script) stats.set_int(MPX .. "CHAR_SET_RP_GIFT_ADMIN", 63266850 )end)end
  if ImGui.Button("Set 1500 Rank") then script.run_in_fiber(function(script) stats.set_int(MPX .. "CHAR_SET_RP_GIFT_ADMIN", 90589350 )end)end
  if ImGui.Button("Set 2000 Rank") then script.run_in_fiber(function(script) stats.set_int(MPX .. "CHAR_SET_RP_GIFT_ADMIN", 146126850 )end)end
  if ImGui.Button("Set 2500 Rank") then script.run_in_fiber(function(script) stats.set_int(MPX .. "CHAR_SET_RP_GIFT_ADMIN", 214164350 )end)end
  if ImGui.Button("Set 3000 Rank") then script.run_in_fiber(function(script) stats.set_int(MPX .. "CHAR_SET_RP_GIFT_ADMIN", 294701850 )end)end
  if ImGui.Button("Set 3500 Rank") then script.run_in_fiber(function(script) stats.set_int(MPX .. "CHAR_SET_RP_GIFT_ADMIN", 387739350 )end)end
  if ImGui.Button("Set 4000 Rank") then script.run_in_fiber(function(script) stats.set_int(MPX .. "CHAR_SET_RP_GIFT_ADMIN", 493276850 )end)end
  if ImGui.Button("Set 4500 Rank") then script.run_in_fiber(function(script) stats.set_int(MPX .. "CHAR_SET_RP_GIFT_ADMIN", 611314350 )end)end
  if ImGui.Button("Set 5000 Rank") then script.run_in_fiber(function(script) stats.set_int(MPX .. "CHAR_SET_RP_GIFT_ADMIN", 741851850 )end)end
  if ImGui.Button("Set 5500 Rank") then script.run_in_fiber(function(script) stats.set_int(MPX .. "CHAR_SET_RP_GIFT_ADMIN", 884889350 )end)end
  if ImGui.Button("Set 6000 Rank") then script.run_in_fiber(function(script) stats.set_int(MPX .. "CHAR_SET_RP_GIFT_ADMIN", 1040426850 )end)end
  if ImGui.Button("Set 6500 Rank") then script.run_in_fiber(function(script) stats.set_int(MPX .. "CHAR_SET_RP_GIFT_ADMIN", 1208464350 )end)end
  if ImGui.Button("Set 7000 Rank") then script.run_in_fiber(function(script) stats.set_int(MPX .. "CHAR_SET_RP_GIFT_ADMIN", 1389001850 )end)end
  if ImGui.Button("Set 7500 Rank") then script.run_in_fiber(function(script) stats.set_int(MPX .. "CHAR_SET_RP_GIFT_ADMIN", 1582039350 )end)end
  if ImGui.Button("Set 8000 Rank") then script.run_in_fiber(function(script) stats.set_int(MPX .. "CHAR_SET_RP_GIFT_ADMIN", 1787576850 )end)end 
----------------------------------------------------------------------------------------------------------------------------------------------------
ImGui.EndMenu() end  
if ImGui.BeginMenu("Set Level LS Tuners ") then
  if ImGui.Button("Set Level 25") then script.run_in_fiber(function(script) stats.set_int(MPX .. "CAR_CLUB_REP", 3665)end)end
  if ImGui.Button("Set Level 50") then script.run_in_fiber(function(script) stats.set_int(MPX .. "CAR_CLUB_REP", 10540)end)end
  if ImGui.Button("Set Level 100") then script.run_in_fiber(function(script) stats.set_int(MPX .. "CAR_CLUB_REP", 33665)end)end
  if ImGui.Button("Set Level 150") then script.run_in_fiber(function(script) stats.set_int(MPX .. "CAR_CLUB_REP", 69290)end)end
  if ImGui.Button("Set Level 200") then script.run_in_fiber(function(script) stats.set_int(MPX .. "CAR_CLUB_REP", 119630)end)end
  if ImGui.Button("Set Level 250") then script.run_in_fiber(function(script) stats.set_int(MPX .. "CAR_CLUB_REP", 172430)end)end
  if ImGui.Button("Set Level 300") then script.run_in_fiber(function(script) stats.set_int(MPX .. "CAR_CLUB_REP", 227430)end)end
  if ImGui.Button("Set Level 350") then script.run_in_fiber(function(script) stats.set_int(MPX .. "CAR_CLUB_REP", 282430)end)end
  if ImGui.Button("Set Level 400") then script.run_in_fiber(function(script) stats.set_int(MPX .. "CAR_CLUB_REP", 337430)end)end
  if ImGui.Button("Set Level 450") then script.run_in_fiber(function(script) stats.set_int(MPX .. "CAR_CLUB_REP", 392430)end)end
  if ImGui.Button("Set Level 500") then script.run_in_fiber(function(script) stats.set_int(MPX .. "CAR_CLUB_REP", 447430)end)end
  if ImGui.Button("Set Level 550") then script.run_in_fiber(function(script) stats.set_int(MPX .. "CAR_CLUB_REP", 502430)end)end
  if ImGui.Button("Set Level 600") then script.run_in_fiber(function(script) stats.set_int(MPX .. "CAR_CLUB_REP", 557430)end)end
  if ImGui.Button("Set Level 650") then script.run_in_fiber(function(script) stats.set_int(MPX .. "CAR_CLUB_REP", 612430)end)end
  if ImGui.Button("Set Level 700") then script.run_in_fiber(function(script) stats.set_int(MPX .. "CAR_CLUB_REP", 667430)end)end
  if ImGui.Button("Set Level 750") then script.run_in_fiber(function(script) stats.set_int(MPX .. "CAR_CLUB_REP", 722430)end)end
  if ImGui.Button("Set Level 800") then script.run_in_fiber(function(script) stats.set_int(MPX .. "CAR_CLUB_REP", 832430)end)end
  if ImGui.Button("Set Level 900") then script.run_in_fiber(function(script) stats.set_int(MPX .. "CAR_CLUB_REP", 887430)end)end
  if ImGui.Button("Set Level 950") then script.run_in_fiber(function(script) stats.set_int(MPX .. "CAR_CLUB_REP", 942430)end)end
  if ImGui.Button("Set Level 1000") then script.run_in_fiber(function(script) stats.set_int(MPX .. "CAR_CLUB_REP", 997430)end)end
ImGui.EndMenu() end
------------------------------------------------------------------------------------------------------------------------------------------------  

if ImGui.BeginMenu("Unlocks ( Options )") then
  if ImGui.BeginMenu("Achievements") then
            if ImGui.Button("Solid Gold, Baby!") then script.run_in_fiber(function(script) globals.set_int(U_Achievements+ 1 , 12) end)end
            if ImGui.Button(" Welcome to Los Santos") then script.run_in_fiber(function(script) globals.set_int(U_Achievements+ 1 , 1) end) end
            if ImGui.Button(" A Friendship Resurrected") then script.run_in_fiber(function(script) globals.set_int(U_Achievements+ 1 , 2) end) end
            if ImGui.Button(" A Fair Day's Pay") then script.run_in_fiber(function(script) globals.set_int(U_Achievements+ 1 , 3) end) end
            if ImGui.Button(" The Moment of Truth") then script.run_in_fiber(function(script) globals.set_int(U_Achievements+ 1 , 4) end) end
            if ImGui.Button(" To Live or Die in Los Santos") then script.run_in_fiber(function(script) globals.set_int(U_Achievements+ 1 , 5) end) end
            if ImGui.Button(" Diamond Hard") then script.run_in_fiber(function(script) globals.set_int(U_Achievements+ 1 , 6) end) end
            if ImGui.Button(" Subversive") then script.run_in_fiber(function(script) globals.set_int(U_Achievements+ 1 , 7) end) end
            if ImGui.Button(" Blitzed") then script.run_in_fiber(function(script) globals.set_int(U_Achievements+ 1 , 8) end) end
            if ImGui.Button(" Small Town, Big Job") then script.run_in_fiber(function(script) globals.set_int(U_Achievements+ 1 , 9) end) end
            if ImGui.Button(" The Government Gimps") then script.run_in_fiber(function(script) globals.set_int(U_Achievements+ 1 , 10) end) end
            if ImGui.Button(" The Big One!") then script.run_in_fiber(function(script) globals.set_int(U_Achievements+ 1 , 11) end) end
            if ImGui.Button(" Career Criminal") then script.run_in_fiber(function(script) globals.set_int(U_Achievements+ 1 , 13) end) end
            if ImGui.Button(" San Andreas Sightseer") then script.run_in_fiber(function(script) globals.set_int(U_Achievements+ 1 , 14) end) end
            if ImGui.Button(" All's Fare in Love and War") then script.run_in_fiber(function(script) globals.set_int(U_Achievements+ 1 , 15) end) end
            if ImGui.Button(" TP Industries Arms Race") then script.run_in_fiber(function(script) globals.set_int(U_Achievements+ 1 , 16) end) end
            if ImGui.Button(" Multi-Disciplined") then script.run_in_fiber(function(script) globals.set_int(U_Achievements+ 1 , 17) end) end
            if ImGui.Button(" From Beyond the Stars") then script.run_in_fiber(function(script) globals.set_int(U_Achievements+ 1 , 18) end) end
            if ImGui.Button(" A Mystery, Solved") then script.run_in_fiber(function(script) globals.set_int(U_Achievements+ 1 , 19) end) end
            if ImGui.Button(" Waste Management") then script.run_in_fiber(function(script) globals.set_int(U_Achievements+ 1 , 20) end) end
            if ImGui.Button(" Red Mist") then script.run_in_fiber(function(script) globals.set_int(U_Achievements+ 1 , 21) end) end
            if ImGui.Button(" Show Off") then script.run_in_fiber(function(script) globals.set_int(U_Achievements+ 1 , 22) end) end
            if ImGui.Button(" Kifflom!") then script.run_in_fiber(function(script) globals.set_int(U_Achievements+ 1 , 23) end) end
            if ImGui.Button(" Three Man Army") then script.run_in_fiber(function(script) globals.set_int(U_Achievements+ 1 , 24) end) end
            if ImGui.Button(" Out of Your Depth") then script.run_in_fiber(function(script) globals.set_int(U_Achievements+ 1 , 25) end) end
            if ImGui.Button(" Altruist Acolyte") then script.run_in_fiber(function(script) globals.set_int(U_Achievements+ 1 , 26) end) end
            if ImGui.Button(" A Lot of Cheddar") then script.run_in_fiber(function(script) globals.set_int(U_Achievements+ 1 , 27) end) end
            if ImGui.Button(" Trading Pure Alpha") then script.run_in_fiber(function(script) globals.set_int(U_Achievements+ 1 , 28) end) end
            if ImGui.Button(" Pimp My Sidearm") then script.run_in_fiber(function(script) globals.set_int(U_Achievements+ 1 , 29) end) end
            if ImGui.Button(" Wanted: Alive Or Alive") then script.run_in_fiber(function(script) globals.set_int(U_Achievements+ 1 , 30) end) end
            if ImGui.Button(" Los Santos Customs") then script.run_in_fiber(function(script) globals.set_int(U_Achievements+ 1 , 31) end) end
            if ImGui.Button(" Close Shave") then script.run_in_fiber(function(script) globals.set_int(U_Achievements+ 1 , 32) end) end
            if ImGui.Button(" Off the Plane") then script.run_in_fiber(function(script) globals.set_int(U_Achievements+ 1 , 33) end) end
            if ImGui.Button(" Three-Bit Gangster") then script.run_in_fiber(function(script) globals.set_int(U_Achievements+ 1 , 34) end) end
            if ImGui.Button(" Making Moves") then script.run_in_fiber(function(script) globals.set_int(U_Achievements+ 1 , 35) end) end
            if ImGui.Button(" Above the Law") then script.run_in_fiber(function(script) globals.set_int(U_Achievements+ 1 , 36) end) end
            if ImGui.Button(" Numero Uno") then script.run_in_fiber(function(script) globals.set_int(U_Achievements+ 1 , 37) end) end
            if ImGui.Button(" The Midnight Club") then script.run_in_fiber(function(script) globals.set_int(U_Achievements+ 1 , 38) end) end
            if ImGui.Button(" Unnatural Selection") then script.run_in_fiber(function(script) globals.set_int(U_Achievements+ 1 , 39) end) end
            if ImGui.Button(" Backseat Driver") then script.run_in_fiber(function(script) globals.set_int(U_Achievements+ 1 , 40) end) end
            if ImGui.Button(" Run Like The Wind") then script.run_in_fiber(function(script) globals.set_int(U_Achievements+ 1 , 41) end) end
            if ImGui.Button(" Clean Sweep") then script.run_in_fiber(function(script) globals.set_int(U_Achievements+ 1 , 42) end) end
            if ImGui.Button(" Decorated") then script.run_in_fiber(function(script) globals.set_int(U_Achievements+ 1 , 43) end) end
            if ImGui.Button(" Stick Up Kid") then script.run_in_fiber(function(script) globals.set_int(U_Achievements+ 1 , 44) end) end
            if ImGui.Button(" Enjoy Your Stay") then script.run_in_fiber(function(script) globals.set_int(U_Achievements+ 1 , 45) end) end
            if ImGui.Button(" Crew Cut") then script.run_in_fiber(function(script) globals.set_int(U_Achievements+ 1 , 46) end) end
            if ImGui.Button(" Full Refund") then script.run_in_fiber(function(script) globals.set_int(U_Achievements+ 1 , 47) end) end
            if ImGui.Button(" Dialling Digits") then script.run_in_fiber(function(script) globals.set_int(U_Achievements+ 1 , 48) end) end
            if ImGui.Button(" American Dream") then script.run_in_fiber(function(script) globals.set_int(U_Achievements+ 1 , 49) end) end
            if ImGui.Button(" A New Perspective") then script.run_in_fiber(function(script) globals.set_int(U_Achievements+ 1 , 50) end) end
            if ImGui.Button(" Be Prepared") then script.run_in_fiber(function(script) globals.set_int(U_Achievements+ 1 , 51) end) end
            if ImGui.Button(" In the Name of Science") then script.run_in_fiber(function(script) globals.set_int(U_Achievements+ 1 , 52) end) end
            if ImGui.Button(" Dead Presidents") then script.run_in_fiber(function(script) globals.set_int(U_Achievements+ 1 , 53) end) end
            if ImGui.Button(" Parole Day") then script.run_in_fiber(function(script) globals.set_int(U_Achievements+ 1 , 54) end) end
            if ImGui.Button(" Shot Caller") then script.run_in_fiber(function(script) globals.set_int(U_Achievements+ 1 , 55) end) end
            if ImGui.Button(" Four Way") then script.run_in_fiber(function(script) globals.set_int(U_Achievements+ 1 , 56) end) end
            if ImGui.Button(" Live a Little") then script.run_in_fiber(function(script) globals.set_int(U_Achievements+ 1 , 57) end) end
            if ImGui.Button(" Can't Touch This") then script.run_in_fiber(function(script) globals.set_int(U_Achievements+ 1 , 58) end) end
            if ImGui.Button(" Mastermind") then script.run_in_fiber(function(script) globals.set_int(U_Achievements+ 1 , 59) end) end
            if ImGui.Button(" Vinewood Visionary") then script.run_in_fiber(function(script) globals.set_int(U_Achievements+ 1 , 60) end) end
            if ImGui.Button(" Majestic") then script.run_in_fiber(function(script) globals.set_int(U_Achievements+ 1 , 61) end) end
            if ImGui.Button(" Humans of Los Santos") then script.run_in_fiber(function(script) globals.set_int(U_Achievements+ 1 , 62) end) end
            if ImGui.Button(" First Time Director") then script.run_in_fiber(function(script) globals.set_int(U_Achievements+ 1 , 63) end) end
            if ImGui.Button(" Animal Lover") then script.run_in_fiber(function(script) globals.set_int(U_Achievements+ 1 , 64) end) end
            if ImGui.Button(" Ensemble Piece") then script.run_in_fiber(function(script) globals.set_int(U_Achievements+ 1 , 65) end) end
            if ImGui.Button(" Cult Movie") then script.run_in_fiber(function(script) globals.set_int(U_Achievements+ 1 , 66) end) end
            if ImGui.Button(" Location Scout") then script.run_in_fiber(function(script) globals.set_int(U_Achievements+ 1 , 67) end) end
            if ImGui.Button(" Method Actor") then script.run_in_fiber(function(script) globals.set_int(U_Achievements+ 1 , 68) end) end
            if ImGui.Button(" Cryptozoologist") then script.run_in_fiber(function(script) globals.set_int(U_Achievements+ 1 , 69) end) end
            if ImGui.Button(" Getting Started") then script.run_in_fiber(function(script) globals.set_int(U_Achievements+ 1 , 70) end) end
            if ImGui.Button(" The Data Breaches") then script.run_in_fiber(function(script) globals.set_int(U_Achievements+ 1 , 71) end) end
            if ImGui.Button(" The Bogdan Problem") then script.run_in_fiber(function(script) globals.set_int(U_Achievements+ 1 , 72) end) end
            if ImGui.Button(" The Doomsday Scenario") then script.run_in_fiber(function(script) globals.set_int(U_Achievements+ 1 , 73) end) end
            if ImGui.Button(" A World Worth Saving") then script.run_in_fiber(function(script) globals.set_int(U_Achievements+ 1 , 74) end) end
            if ImGui.Button(" Orbital Obliteration") then script.run_in_fiber(function(script) globals.set_int(U_Achievements+ 1 , 75) end) end
            if ImGui.Button(" Elitist") then script.run_in_fiber(function(script) globals.set_int(U_Achievements+ 1 , 76) end) end
            if ImGui.Button(" Masterminds") then script.run_in_fiber(function(script) globals.set_int(U_Achievements+ 1 , 77) end) end
ImGui.EndMenu() end

if ImGui.BeginMenu("Awards") then 
 if ImGui.Button("Victory") then script.run_in_fiber(function(script) --------------------------------------------- ** Victory ** ----------------------------------------
    stats.set_int(MPX .. "AWD_FM_DM_WINS", 50)
    stats.set_int(MPX .. "AWD_FM_TDM_WINS", 50)
    stats.set_int(MPX .. "AWD_FM_TDM_MVP", 50)
    stats.set_int(MPX .. "AWD_RACES_WON", 50)
    stats.set_int(MPX .. "AWD_FMWINAIRRACE", 25)
    stats.set_int(MPX .. "AWD_FMWINSEARACE", 25)
    stats.set_int(MPX .. "AWD_FM_GTA_RACES_WON", 50)
    stats.set_bool(MPX .. "AWD_FMKILL3ANDWINGTARACE", true)
    stats.set_int(MPX .. "AWD_FMRALLYWONDRIVE", 25)
    stats.set_int(MPX .. "AWD_FMRALLYWONNAV", 25)
    stats.set_bool(MPX .. "AWD_FMWINCUSTOMRACE", true)
    stats.set_int(MPX .. "AWD_FMWINRACETOPOINTS", 25)
    stats.set_bool(MPX .. "CL_RACE_MODDED_CAR", true)
    stats.set_int(MPX .. "AWD_FM_RACE_LAST_FIRST", 25)
    stats.set_bool(MPX .. "AWD_FMRACEWORLDRECHOLDER", true)
    stats.set_int(MPX .. "AWD_FM_RACES_FASTEST_LAP", 50)
    stats.set_bool(MPX .. "AWD_FMWINALLRACEMODES", true)
    stats.set_int(MPX .. "AWD_FMHORDWAVESSURVIVE", 10)
    stats.set_int(MPX .. "NUMBER_SLIPSTREAMS_IN_RACE", 100)
    stats.set_int(MPX .. "NUMBER_TURBO_STARTS_IN_RACE", 50)
    stats.set_int(MPX .. "AWD_NO_ARMWRESTLING_WINS", 25)
    stats.set_int(MPX .. "MOST_ARM_WRESTLING_WINS", 25)
    stats.set_int(MPX .. "AWD_WIN_AT_DARTS", 25)
    stats.set_int(MPX .. "AWD_FM_GOLF_WON", 25)
    stats.set_int(MPX .. "AWD_FM_TENNIS_WON", 25)
    stats.set_bool(MPX .. "AWD_FM_TENNIS_5_SET_WINS", true)
    stats.set_bool(MPX .. "AWD_FM_TENNIS_STASETWIN", true)
    stats.set_int(MPX .. "AWD_FM_SHOOTRANG_CT_WON", 25)
    stats.set_int(MPX .. "AWD_FM_SHOOTRANG_RT_WON", 25)
    stats.set_int(MPX .. "AWD_FM_SHOOTRANG_TG_WON", 25)
    stats.set_bool(MPX .. "AWD_FM_SHOOTRANG_GRAN_WON", true)
    stats.set_bool(MPX .. "AWD_FMWINEVERYGAMEMODE", true)
    stats.set_int(MPX .. "AWD_WIN_CAPTURES", 50)
    stats.set_int(MPX .. "AWD_WIN_CAPTURE_DONT_DYING", 25)
    stats.set_int(MPX .. "AWD_WIN_LAST_TEAM_STANDINGS", 50)
    stats.set_int(MPX .. "AWD_ONLY_PLAYER_ALIVE_LTS", 50)
    stats.set_int(MPX .. "AWD_KILL_TEAM_YOURSELF_LTS", 25)
    stats.set_int(MPX .. "AIR_LAUNCHES_OVER_40M", 25)
    stats.set_int(MPX .. "AWD_CARS_EXPORTED", 50)
    stats.set_int(MPX .. "AWD_LESTERDELIVERVEHICLES", 25)
    stats.set_int(MPX .. "TOTAL_RACES_WON", 500)
    stats.set_int(MPX .. "TOTAL_RACES_LOST", 250)
    stats.set_int(MPX .. "TOTAL_CUSTOM_RACES_WON", 500)
    stats.set_int(MPX .. "TOTAL_DEATHMATCH_LOST", 250)
    stats.set_int(MPX .. "TOTAL_DEATHMATCH_WON", 500)
    stats.set_int(MPX .. "TOTAL_TDEATHMATCH_LOST", 250)
    stats.set_int(MPX .. "TOTAL_TDEATHMATCH_WON", 500)
    stats.set_int(MPX .. "SHOOTINGRANGE_WINS", 500)
    stats.set_int(MPX .. "SHOOTINGRANGE_LOSSES", 250)
    stats.set_int(MPX .. "TENNIS_MATCHES_WON", 500)
    stats.set_int(MPX .. "TENNIS_MATCHES_LOST", 250)
    stats.set_int(MPX .. "GOLF_WINS", 500)
    stats.set_int(MPX .. "GOLF_LOSSES", 250)
    stats.set_int(MPX .. "DARTS_TOTAL_WINS", 500)
    stats.set_int(MPX .. "DARTS_TOTAL_MATCHES", 750)
    stats.set_int(MPX .. "SHOOTINGRANGE_TOTAL_MATCH", 800)
    stats.set_int(MPX .. "BJ_WINS", 500)
    stats.set_int(MPX .. "BJ_LOST", 250)
    stats.set_int(MPX .. "RACE_2_POINT_WINS", 500)
    stats.set_int(MPX .. "RACE_2_POINT_LOST", 250)
    stats.set_int(MPX .. "KILLS_PLAYERS", 3593)
    stats.set_int(MPX .. "DEATHS_PLAYER", 1002)
    stats.set_int(MPX .. "MISSIONS_CREATED", 500)
    stats.set_int(MPX .. "LTS_CREATED", 500)
    stats.set_int(MPX .. "FM_MISSION_LIKES", 1500) end)end
  
  if ImGui.Button("General") then script.run_in_fiber(function(script)--------------------------------------------- ** General ** ----------------------------------------
    stats.set_bool(MPX .. "AWD_FM25DIFFERENTDM", true)
    stats.set_int(MPX .. "CR_DIFFERENT_DM", 25)
    stats.set_bool(MPX .. "AWD_FM25DIFFERENTRACES", true)
    stats.set_int(MPX .. "CR_DIFFERENT_RACES", 25)
    stats.set_int(MPX .. "AWD_PARACHUTE_JUMPS_20M", 25)
    stats.set_int(MPX .. "AWD_PARACHUTE_JUMPS_50M", 25)
    stats.set_int(MPX .. "AWD_FMBASEJMP", 25)
    stats.set_bool(MPX .. "AWD_FMATTGANGHQ", true)
    stats.set_bool(MPX .. "AWD_FM6DARTCHKOUT", true)
    stats.set_int(MPX .. "AWD_FM_GOLF_BIRDIES", 25)
    stats.set_bool(MPX .. "AWD_FM_GOLF_HOLE_IN_1", true)
    stats.set_int(MPX .. "AWD_FM_TENNIS_ACE", 25)
    stats.set_int(MPX .. "AWD_FMBBETWIN", 50000)
    stats.set_int(MPX .. "AWD_LAPDANCES", 25)
    stats.set_int(MPX .. "AWD_FMCRATEDROPS", 25)
    stats.set_bool(MPX .. "AWD_FMPICKUPDLCCRATE1ST", true)
    stats.set_bool(MPX .. "AWD_FM25DIFITEMSCLOTHES", true)
    stats.set_int(MPX .. "AWD_NO_HAIRCUTS", 25)
    stats.set_bool(MPX .. "AWD_BUY_EVERY_GUN", true)
    stats.set_bool(MPX .. "AWD_DRIVELESTERCAR5MINS", true)
    stats.set_bool(MPX .. "AWD_FMTATTOOALLBODYPARTS", true)
    stats.set_int(MPX .. "AWD_DROPOFF_CAP_PACKAGES", 100)
    stats.set_int(MPX .. "AWD_PICKUP_CAP_PACKAGES", 100)
    stats.set_int(MPX .. "AWD_MENTALSTATE_TO_NORMAL", 50)
    stats.set_bool(MPX .. "AWD_STORE_20_CAR_IN_GARAGES", true)
    stats.set_int(MPX .. "AWD_TRADE_IN_YOUR_PROPERTY", 25)
    stats.set_bool(MPX .. "AWD_DAILYOBJWEEKBONUS", true)
    stats.set_bool(MPX .. "AWD_DAILYOBJMONTHBONUS", true)
    stats.set_int(MPX .. "AWD_FM_CR_DM_MADE", 25)
    stats.set_int(MPX .. "AWD_FM_CR_RACES_MADE", 25)
    stats.set_int(MPX .. "AWD_FM_CR_PLAYED_BY_PEEP", 1598)
    stats.set_int(MPX .. "AWD_FM_CR_MISSION_SCORE", 100)
    stats.set_bool(MPX .. "CL_DRIVE_RALLY", true)
    stats.set_bool(MPX .. "CL_PLAY_GTA_RACE", true)
    stats.set_bool(MPX .. "CL_PLAY_BOAT_RACE", true)
    stats.set_bool(MPX .. "CL_PLAY_FOOT_RACE", true)
    stats.set_bool(MPX .. "CL_PLAY_TEAM_DM", true)
    stats.set_bool(MPX .. "CL_PLAY_VEHICLE_DM", true)
    stats.set_bool(MPX .. "CL_PLAY_MISSION_CONTACT", true)
    stats.set_bool(MPX .. "CL_PLAY_A_PLAYLIST", true)
    stats.set_bool(MPX .. "CL_PLAY_POINT_TO_POINT", true)
    stats.set_bool(MPX .. "CL_PLAY_ONE_ON_ONE_DM", true)
    stats.set_bool(MPX .. "CL_PLAY_ONE_ON_ONE_RACE", true)
    stats.set_bool(MPX .. "CL_SURV_A_BOUNTY", true)
    stats.set_bool(MPX .. "CL_SET_WANTED_LVL_ON_PLAY", true)
    stats.set_bool(MPX .. "CL_GANG_BACKUP_GANGS", true)
    stats.set_bool(MPX .. "CL_GANG_BACKUP_LOST", true)
    stats.set_bool(MPX .. "CL_GANG_BACKUP_VAGOS", true)
    stats.set_bool(MPX .. "CL_CALL_MERCENARIES", true)
    stats.set_bool(MPX .. "CL_PHONE_MECH_DROP_CAR", true)
    stats.set_bool(MPX .. "CL_GONE_OFF_RADAR", true)
    stats.set_bool(MPX .. "CL_FILL_TITAN", true)
    stats.set_bool(MPX .. "CL_MOD_CAR_USING_APP", true)
    stats.set_bool(MPX .. "CL_MOD_CAR_USING_APP", true)
    stats.set_bool(MPX .. "CL_BUY_INSURANCE", true)
    stats.set_bool(MPX .. "CL_BUY_GARAGE", true)
    stats.set_bool(MPX .. "CL_ENTER_FRIENDS_HOUSE", true)
    stats.set_bool(MPX .. "CL_CALL_STRIPPER_HOUSE", true)
    stats.set_bool(MPX .. "CL_CALL_FRIEND", true)
    stats.set_bool(MPX .. "CL_SEND_FRIEND_REQUEST", true)
    stats.set_bool(MPX .. "CL_W_WANTED_PLAYER_TV", true)
    stats.set_bool(MPX .. "FM_INTRO_CUT_DONE", true)
    stats.set_bool(MPX .. "FM_INTRO_MISS_DONE", true)
    stats.set_bool(MPX .. "SHOOTINGRANGE_SEEN_TUT", true)
    stats.set_bool(MPX .. "TENNIS_SEEN_TUTORIAL", true)
    stats.set_bool(MPX .. "DARTS_SEEN_TUTORIAL", true)
    stats.set_bool(MPX .. "ARMWRESTLING_SEEN_TUTORIAL", true)
    stats.set_bool(MPX .. "HAS_WATCHED_BENNY_CUTSCE", true)
    stats.set_int(MPX .. "NO_PHOTOS_TAKEN", 100)
    stats.set_int(MPX .. "BOUNTSONU", 200)
    stats.set_int(MPX .. "BOUNTPLACED", 500)
    stats.set_int(MPX .. "BETAMOUNT", 500)
    stats.set_int(MPX .. "CRARMWREST", 500)
    stats.set_int(MPX .. "CRBASEJUMP", 500)
    stats.set_int(MPX .. "CRDARTS", 500)
    stats.set_int(MPX .. "CRDM", 500)
    stats.set_int(MPX .. "CRGANGHIDE", 500)
    stats.set_int(MPX .. "CRGOLF", 500)
    stats.set_int(MPX .. "CRHORDE", 500)
    stats.set_int(MPX .. "CRMISSION", 500)
    stats.set_int(MPX .. "CRSHOOTRNG", 500)
    stats.set_int(MPX .. "CRTENNIS", 500)
    stats.set_int(MPX .. "NO_TIMES_CINEMA", 500)end)end  
                    
  if ImGui.Button("Weapons") then script.run_in_fiber(function(script)--------------------------------------------- ** Weapons ** ----------------------------------------
    stats.set_int(MPX .. "CHAR_WEAP_UNLOCKED", -1)
    stats.set_int(MPX .. "CHAR_WEAP_UNLOCKED2", -1)
    stats.set_int(MPX .. "CHAR_WEAP_UNLOCKED3", -1)
    stats.set_int(MPX .. "CHAR_WEAP_UNLOCKED4", -1)
    stats.set_int(MPX .. "CHAR_WEAP_ADDON_1_UNLCK", -1)
    stats.set_int(MPX .. "CHAR_WEAP_ADDON_2_UNLCK", -1)
    stats.set_int(MPX .. "CHAR_WEAP_ADDON_3_UNLCK", -1)
    stats.set_int(MPX .. "CHAR_WEAP_ADDON_4_UNLCK", -1)
    stats.set_int(MPX .. "CHAR_WEAP_FREE", -1)
    stats.set_int(MPX .. "CHAR_WEAP_FREE2", -1)
    stats.set_int(MPX .. "CHAR_FM_WEAP_FREE", -1)
    stats.set_int(MPX .. "CHAR_FM_WEAP_FREE2", -1)
    stats.set_int(MPX .. "CHAR_FM_WEAP_FREE3", -1)
    stats.set_int(MPX .. "CHAR_FM_WEAP_FREE4", -1)
    stats.set_int(MPX .. "CHAR_WEAP_PURCHASED", -1)
    stats.set_int(MPX .. "CHAR_WEAP_PURCHASED2", -1)
    stats.set_int(MPX .. "WEAPON_PICKUP_BITSET", -1)
    stats.set_int(MPX .. "WEAPON_PICKUP_BITSET2", -1)
    stats.set_int(MPX .. "CHAR_FM_WEAP_UNLOCKED", -1)
    stats.set_int(MPX .. "NO_WEAPONS_UNLOCK", -1)
    stats.set_int(MPX .. "NO_WEAPON_MODS_UNLOCK", -1)
    stats.set_int(MPX .. "NO_WEAPON_CLR_MOD_UNLOCK", -1)
    stats.set_int(MPX .. "CHAR_FM_WEAP_UNLOCKED2", -1)
    stats.set_int(MPX .. "CHAR_FM_WEAP_UNLOCKED3", -1)
    stats.set_int(MPX .. "CHAR_FM_WEAP_UNLOCKED4", -1)
    stats.set_int(MPX .. "CHAR_KIT_1_FM_UNLCK", -1)
    stats.set_int(MPX .. "CHAR_KIT_2_FM_UNLCK", -1)
    stats.set_int(MPX .. "CHAR_KIT_3_FM_UNLCK", -1)
    stats.set_int(MPX .. "CHAR_KIT_4_FM_UNLCK", -1)
    stats.set_int(MPX .. "CHAR_KIT_5_FM_UNLCK", -1)
    stats.set_int(MPX .. "CHAR_KIT_6_FM_UNLCK", -1)
    stats.set_int(MPX .. "CHAR_KIT_7_FM_UNLCK", -1)
    stats.set_int(MPX .. "CHAR_KIT_8_FM_UNLCK", -1)
    stats.set_int(MPX .. "CHAR_KIT_9_FM_UNLCK", -1)
    stats.set_int(MPX .. "CHAR_KIT_10_FM_UNLCK", -1)
    stats.set_int(MPX .. "CHAR_KIT_11_FM_UNLCK", -1)
    stats.set_int(MPX .. "CHAR_KIT_12_FM_UNLCK", -1)
    stats.set_int(MPX .. "CHAR_KIT_FM_PURCHASE", -1)
    stats.set_int(MPX .. "CHAR_WEAP_FM_PURCHASE", -1)
    stats.set_int(MPX .. "CHAR_WEAP_FM_PURCHASE2", -1)
    stats.set_int(MPX .. "CHAR_WEAP_FM_PURCHASE3", -1)
    stats.set_int(MPX .. "CHAR_WEAP_FM_PURCHASE4", -1)
    stats.set_int(MPX .. "FIREWORK_TYPE_1_WHITE", 1000)
    stats.set_int(MPX .. "FIREWORK_TYPE_1_RED", 1000)
    stats.set_int(MPX .. "FIREWORK_TYPE_1_BLUE", 1000)
    stats.set_int(MPX .. "FIREWORK_TYPE_2_WHITE", 1000)
    stats.set_int(MPX .. "FIREWORK_TYPE_2_RED", 1000)
    stats.set_int(MPX .. "FIREWORK_TYPE_2_BLUE", 1000)
    stats.set_int(MPX .. "FIREWORK_TYPE_3_WHITE", 1000)
    stats.set_int(MPX .. "FIREWORK_TYPE_3_RED", 1000)
    stats.set_int(MPX .. "FIREWORK_TYPE_3_BLUE", 1000)
    stats.set_int(MPX .. "FIREWORK_TYPE_4_WHITE", 1000)
    stats.set_int(MPX .. "FIREWORK_TYPE_4_RED", 1000)
    stats.set_int(MPX .. "FIREWORK_TYPE_4_BLUE", 1000)
    stats.set_int(MPX .. "WEAP_FM_ADDON_PURCH", -1)
    end) end
  if ImGui.Button("Crimes") then script.run_in_fiber(function(script)--------------------------------------------- ** Crimes ** -----------------------------------------
      stats.set_int(MPX .. "AWD_FMTIME5STARWANTED", 120)
      stats.set_int(MPX .. "AWD_5STAR_WANTED_AVOIDANCE", 50)
      stats.set_int(MPX .. "AWD_FMSHOOTDOWNCOPHELI", 25)
      stats.set_int(MPX .. "AWD_VEHICLES_JACKEDR", 500)
      stats.set_int(MPX .. "AWD_SECURITY_CARS_ROBBED", 25)
      stats.set_int(MPX .. "AWD_HOLD_UP_SHOPS", 20)
      stats.set_int(MPX .. "AWD_ODISTRACTCOPSNOEATH", 25)
      stats.set_int(MPX .. "AWD_ENEMYDRIVEBYKILLS", 100)
      stats.set_int(MPX .. "CHAR_WANTED_LEVEL_TIME5STAR", 18000000)
      stats.set_int(MPX .. "CARS_COPS_EXPLODED", 300)
      stats.set_int(MPX .. "BIKES_EXPLODED", 100)
      stats.set_int(MPX .. "BOATS_EXPLODED", 168)
      stats.set_int(MPX .. "HELIS_EXPLODED", 98)
      stats.set_int(MPX .. "PLANES_EXPLODED", 138)
      stats.set_int(MPX .. "QUADBIKE_EXPLODED", 50)
      stats.set_int(MPX .. "BICYCLE_EXPLODED", 48)
      stats.set_int(MPX .. "SUBMARINE_EXPLODED", 28)
      stats.set_int(MPX .. "TIRES_POPPED_BY_GUNSHOT", 500)
      stats.set_int(MPX .. "NUMBER_CRASHES_CARS", 300)
      stats.set_int(MPX .. "NUMBER_CRASHES_BIKES", 300)
      stats.set_int(MPX .. "BAILED_FROM_VEHICLE", 300)
      stats.set_int(MPX .. "NUMBER_CRASHES_QUADBIKES", 300)
      stats.set_int(MPX .. "NUMBER_STOLEN_COP_VEHICLE", 300)
      stats.set_int(MPX .. "NUMBER_STOLEN_CARS", 300)
      stats.set_int(MPX .. "NUMBER_STOLEN_BIKES", 300)
      stats.set_int(MPX .. "NUMBER_STOLEN_BOATS", 300)
      stats.set_int(MPX .. "NUMBER_STOLEN_HELIS", 300)
      stats.set_int(MPX .. "NUMBER_STOLEN_PLANES", 300)
      stats.set_int(MPX .. "NUMBER_STOLEN_QUADBIKES", 300)
      stats.set_int(MPX .. "NUMBER_STOLEN_BICYCLES", 300)
      stats.set_int(MPX .. "MC_CONTRIBUTION_POINTS", 1000)
      stats.set_int(MPX .. "MEMBERSMARKEDFORDEATH", 700)
      stats.set_int(MPX .. "MCKILLS", 500)
      stats.set_int(MPX .. "MCDEATHS", 700)
      stats.set_int(MPX .. "RIVALPRESIDENTKILLS", 700)
      stats.set_int(MPX .. "RIVALCEOANDVIPKILLS", 700)
      stats.set_int(MPX .. "CLUBHOUSECONTRACTSCOMPLETE", 700)
      stats.set_int(MPX .. "CLUBHOUSECONTRACTEARNINGS", 32698547)
      stats.set_int(MPX .. "CLUBCHALLENGESCOMPLETED", 700)
      stats.set_int(MPX .. "MEMBERCHALLENGESCOMPLETED", 700)
      stats.set_int(MPX .. "GHKILLS", 500)
      stats.set_int(MPX .. "HORDELVL", 10)
      stats.set_int(MPX .. "HORDKILLS", 500)
      stats.set_int(MPX .. "UNIQUECRATES", 500)
      stats.set_int(MPX .. "BJWINS", 500)
      stats.set_int(MPX .. "HORDEWINS", 500)
      stats.set_int(MPX .. "MCMWINS", 500)
      stats.set_int(MPX .. "GANGHIDWINS", 500)
      stats.set_int(MPX .. "KILLS", 800)
      stats.set_int(MPX .. "HITS_PEDS_VEHICLES", 100)
      stats.set_int(MPX .. "SHOTS", 1000)
      stats.set_int(MPX .. "HEADSHOTS", 100)
      stats.set_int(MPX .. "KILLS_ARMED", 650)
      stats.set_int(MPX .. "SUCCESSFUL_COUNTERS", 100)
      stats.set_int(MPX .. "KILLS_PLAYERS", 3593)
      stats.set_int(MPX .. "DEATHS_PLAYER", 1002)
      stats.set_int(MPX .. "KILLS_STEALTH", 100)
      stats.set_int(MPX .. "KILLS_INNOCENTS", 500)
      stats.set_int(MPX .. "KILLS_ENEMY_GANG_MEMBERS", 500)
      stats.set_int(MPX .. "KILLS_FRIENDLY_GANG_MEMBERS", 500)
      stats.set_int(MPX .. "KILLS_BY_OTHERS", 100)
      stats.set_int(MPX .. "BIGGEST_VICTIM_KILLS", 500)
      stats.set_int(MPX .. "ARCHENEMY_KILLS", 500)
      stats.set_int(MPX .. "KILLS_COP", 4500)
      stats.set_int(MPX .. "KILLS_SWAT", 500)
      stats.set_int(MPX .. "STARS_ATTAINED", 5000)
      stats.set_int(MPX .. "STARS_EVADED", 4000)
      stats.set_int(MPX .. "VEHEXPORTED", 500)
      stats.set_int(MPX .. "TOTAL_NO_SHOPS_HELD_UP", 100)
      stats.set_int(MPX .. "CR_GANGATTACK_CITY", 1000)
      stats.set_int(MPX .. "CR_GANGATTACK_COUNTRY", 1000)
      stats.set_int(MPX .. "CR_GANGATTACK_LOST", 1000)
      stats.set_int(MPX .. "CR_GANGATTACK_VAGOS", 1000)
      stats.set_int(MPX .. "NO_NON_CONTRACT_RACE_WIN", 500)
      stats.set_int(MPX .. "DIED_IN_DROWNING", 833)
      stats.set_int(MPX .. "DIED_IN_DROWNINGINVEHICLE", 833)
      stats.set_int(MPX .. "DIED_IN_EXPLOSION", 833)
      stats.set_int(MPX .. "DIED_IN_FALL", 833)
      stats.set_int(MPX .. "DIED_IN_FIRE", 833)
      stats.set_int(MPX .. "DIED_IN_ROAD", 833)
      stats.set_int(MPX .. "GRENADE_ENEMY_KILLS", 50)
      stats.set_int(MPX .. "MICROSMG_ENEMY_KILLS", 500)
      stats.set_int(MPX .. "SMG_ENEMY_KILLS", 500)
      stats.set_int(MPX .. "ASLTSMG_ENEMY_KILLS", 500)
      stats.set_int(MPX .. "CRBNRIFLE_ENEMY_KILLS", 500)
      stats.set_int(MPX .. "ADVRIFLE_ENEMY_KILLS", 500)
      stats.set_int(MPX .. "MG_ENEMY_KILLS", 500)
      stats.set_int(MPX .. "CMBTMG_ENEMY_KILLS", 500)
      stats.set_int(MPX .. "ASLTMG_ENEMY_KILLS", 500)
      stats.set_int(MPX .. "RPG_ENEMY_KILLS", 500)
      stats.set_int(MPX .. "PISTOL_ENEMY_KILLS", 500)
      stats.set_int(MPX .. "PLAYER_HEADSHOTS", 500)
      stats.set_int(MPX .. "SAWNOFF_ENEMY_KILLS", 500)
      stats.set_int(MPX .. "STKYBMB_ENEMY_KILLS", 50)
      stats.set_int(MPX .. "UNARMED_ENEMY_KILLS", 50)
      stats.set_int(MPX .. "SNIPERRFL_ENEMY_KILLS", 500)
      stats.set_int(MPX .. "HVYSNIPER_ENEMY_KILLS", 500)
      end) end
  
  if ImGui.Button("Arena War") then script.run_in_fiber(function(script)--------------------------------------------- ** Arena War ** -----------------------------------------
        stats.set_int(MPX .. "AWD_50_VEHICLES_BLOWNUP", 500)
        stats.set_int(MPX .. "CARS_EXPLODED", 500)
        stats.set_int(MPX .. "AWD_CAR_EXPORT", 100)
        stats.set_int(MPX .. "AWD_FMDRIVEWITHOUTCRASH", 30)
        stats.set_int(MPX .. "AWD_PASSENGERTIME", 4)
        stats.set_int(MPX .. "AWD_TIME_IN_HELICOPTER", 4)
        stats.set_int(MPX .. "AWD_VEHICLE_JUMP_OVER_40M", 25)
        stats.set_int(MPX .. "MOST_FLIPS_IN_ONE_JUMP", 5)
        stats.set_int(MPX .. "MOST_SPINS_IN_ONE_JUMP", 5)
        stats.set_int(MPX .. "CHAR_FM_VEHICLE_1_UNLCK", -1)
        stats.set_int(MPX .. "CHAR_FM_VEHICLE_2_UNLCK", -1)
        stats.set_int(MPX .. "NO_CARS_REPAIR", 1000)
        stats.set_int(MPX .. "VEHICLES_SPRAYED", 500)
        stats.set_int(MPX .. "NUMBER_NEAR_MISS_NOCRASH", 500)
        stats.set_int(MPX .. "USJS_FOUND", 50)
        stats.set_int(MPX .. "USJS_COMPLETED", 50)
        stats.set_int(MPX .. "USJS_TOTAL_COMPLETED", 50)
        stats.set_int(MPX .. "CRDEADLINE", 5)
        stats.set_int(MPX .. "FAVOUTFITBIKETIMECURRENT", 2069146067)
        stats.set_int(MPX .. "FAVOUTFITBIKETIME1ALLTIME", 2069146067)
        stats.set_int(MPX .. "FAVOUTFITBIKETYPECURRENT", 2069146067)
        stats.set_int(MPX .. "FAVOUTFITBIKETYPEALLTIME", 2069146067)
        stats.set_int(MPX .. "LONGEST_WHEELIE_DIST", 1000)
        stats.set_int(MPX .. "RACES_WON", 50)
        stats.set_int(MPX .. "COUNT_HOTRING_RACE", 20)
        stats.set_bool(MPX .. "AWD_FMFURTHESTWHEELIE", true)
        stats.set_bool(MPX .. "AWD_FMFULLYMODDEDCAR", true) end)end
  
  if ImGui.Button("Combat") then script.run_in_fiber(function(script)--------------------------------------------- ** Combat ** -----------------------------------------
          stats.set_int(MPX .. "AWD_100_HEADSHOTS", 500)
          stats.set_int(MPX .. "AWD_FMOVERALLKILLS", 1000)
          stats.set_int(MPX .. "AWD_FMKILLBOUNTY", 25)
          stats.set_int(MPX .. "AWD_FM_DM_3KILLSAMEGUY", 50)
          stats.set_int(MPX .. "AWD_FM_DM_KILLSTREAK", 100)
          stats.set_int(MPX .. "AWD_FM_DM_STOLENKILL", 50)
          stats.set_int(MPX .. "AWD_FM_DM_TOTALKILLS", 500)
          stats.set_bool(MPX .. "AWD_FMKILLSTREAKSDM", true)
          stats.set_bool(MPX .. "AWD_FMMOSTKILLSGANGHIDE", true)
          stats.set_bool(MPX .. "AWD_FMMOSTKILLSSURVIVE", true)
          stats.set_int(MPX .. "AWD_FMREVENGEKILLSDM", 50)
          stats.set_int(MPX .. "AWD_KILL_CARRIER_CAPTURE", 100)
          stats.set_int(MPX .. "AWD_NIGHTVISION_KILLS", 100)
          stats.set_int(MPX .. "AWD_KILL_PSYCHOPATHS", 100)
          stats.set_int(MPX .. "AWD_TAKEDOWNSMUGPLANE", 50)
          stats.set_int(MPX .. "AWD_100_KILLS_PISTOL", 500)
          stats.set_int(MPX .. "AWD_100_KILLS_SMG", 500)
          stats.set_int(MPX .. "AWD_100_KILLS_SHOTGUN", 500)
          stats.set_int(MPX .. "ASLTRIFLE_ENEMY_KILLS", 500)
          stats.set_int(MPX .. "AWD_100_KILLS_SNIPER", 500)
          stats.set_int(MPX .. "MG_ENEMY_KILLS", 500)
          stats.set_int(MPX .. "AWD_25_KILLS_STICKYBOMBS", 50)
          stats.set_int(MPX .. "AWD_50_KILLS_GRENADES", 50)
          stats.set_int(MPX .. "AWD_50_KILLS_ROCKETLAUNCH", 50)
          stats.set_int(MPX .. "AWD_20_KILLS_MELEE", 50)
          stats.set_int(MPX .. "AWD_CAR_BOMBS_ENEMY_KILLS", 25)
          stats.set_int(MPX .. "MELEEKILLS", 700)
          stats.set_int(MPX .. "HITS", 10000)
          stats.set_int(MPX .. "DEATHS", 499)
          stats.set_int(MPX .. "HIGHEST_SKITTLES", 900)
          stats.set_int(MPX .. "NUMBER_NEAR_MISS", 1000) end) end
  
  if ImGui.Button("Heists") then script.run_in_fiber(function(script)--------------------------------------------- ** Heists ** -----------------------------------------
            stats.set_int(MPX .. "AWD_FINISH_HEISTS", 50)
            stats.set_int(MPX .. "AWD_FINISH_HEIST_SETUP_JOB", 50)
            stats.set_int(MPX .. "AWD_COMPLETE_HEIST_NOT_DIE", -1)
            stats.set_bool(MPX .. "AWD_FINISH_HEIST_NO_DAMAGE", true)
            stats.set_int(MPX .. "AWD_WIN_GOLD_MEDAL_HEISTS", 25)
            stats.set_int(MPX .. "AWD_DO_HEIST_AS_MEMBER", 25)
            stats.set_int(MPX .. "AWD_DO_HEIST_AS_THE_LEADER", 25)
            stats.set_bool(MPX .. "AWD_SPLIT_HEIST_TAKE_EVENLY", true)
            stats.set_bool(MPX .. "AWD_ACTIVATE_2_PERSON_KEY", true)
            stats.set_int(MPX .. "AWD_CONTROL_CROWDS", 25)
            stats.set_bool(MPX .. "AWD_ALL_ROLES_HEIST", true)
            stats.set_int(MPX .. "HEIST_COMPLETION", 25)
            stats.set_int(MPX .. "HEISTS_ORGANISED", -1)
            stats.set_int(MPX .. "HEIST_START", -1)
            stats.set_int(MPX .. "HEIST_END", -1)
            stats.set_int(MPX .. "CUTSCENE_MID_PRISON", -1)
            stats.set_int(MPX .. "CUTSCENE_MID_HUMANE", -1)
            stats.set_int(MPX .. "CUTSCENE_MID_NARC", -1)
            stats.set_int(MPX .. "CUTSCENE_MID_ORNATE", -1)
            stats.set_int(MPX .. "CR_FLEECA_PREP_1", -1)
            stats.set_int(MPX .. "CR_FLEECA_PREP_2", -1)
            stats.set_int(MPX .. "CR_FLEECA_FINALE", -1)
            stats.set_int(MPX .. "CR_PRISON_PLANE", -1)
            stats.set_int(MPX .. "CR_PRISON_BUS", -1)
            stats.set_int(MPX .. "CR_PRISON_STATION", -1)
            stats.set_int(MPX .. "CR_PRISON_UNFINISHED_BIZ", -1)
            stats.set_int(MPX .. "CR_PRISON_FINALE", -1)
            stats.set_int(MPX .. "CR_HUMANE_KEY_CODES", -1)
            stats.set_int(MPX .. "CR_HUMANE_ARMORDILLOS", -1)
            stats.set_int(MPX .. "CR_HUMANE_EMP", -1)
            stats.set_int(MPX .. "CR_HUMANE_VALKYRIE", -1)
            stats.set_int(MPX .. "CR_HUMANE_FINALE", -1)
            stats.set_int(MPX .. "CR_NARC_COKE", -1)
            stats.set_int(MPX .. "CR_NARC_TRASH_TRUCK", -1)
            stats.set_int(MPX .. "CR_NARC_BIKERS", -1)
            stats.set_int(MPX .. "CR_NARC_WEED", -1)
            stats.set_int(MPX .. "CR_NARC_STEAL_METH", -1)
            stats.set_int(MPX .. "CR_NARC_FINALE", -1)
            stats.set_int(MPX .. "CR_PACIFIC_TRUCKS", -1)
            stats.set_int(MPX .. "CR_PACIFIC_WITSEC", -1)
            stats.set_int(MPX .. "CR_PACIFIC_HACK", -1)
            stats.set_int(MPX .. "CR_PACIFIC_BIKES", -1)
            stats.set_int(MPX .. "CR_PACIFIC_CONVOY", -1)
            stats.set_int(MPX .. "CR_PACIFIC_FINALE", -1)
            stats.set_int("MPPLY_HEIST_ACH_TRACKER", -1)
            stats.set_int("MPPLY_WIN_GOLD_MEDAL_HEISTS", 25)
            stats.set_bool("MPPLY_AWD_FLEECA_FIN", true)
            stats.set_bool("MPPLY_AWD_PRISON_FIN", true)
            stats.set_bool("MPPLY_AWD_HUMANE_FIN", true)
            stats.set_bool("MPPLY_AWD_SERIESA_FIN", true)
            stats.set_bool("MPPLY_AWD_PACIFIC_FIN", true)
            stats.set_bool("MPPLY_AWD_HST_ORDER", true)
            stats.set_bool("MPPLY_AWD_COMPLET_HEIST_MEM", true)
            stats.set_bool("MPPLY_AWD_COMPLET_HEIST_1STPER", true)
            stats.set_bool("MPPLY_AWD_HST_SAME_TEAM", true)
            stats.set_bool("MPPLY_AWD_HST_ULT_CHAL", true)
            stats.set_bool(MPX .. "AWD_MATCHING_OUTFIT_HEIST", true)
            stats.set_bool(MPX .. "HEIST_PLANNING_DONE_PRINT", true)
            stats.set_bool(MPX .. "HEIST_PLANNING_DONE_HELP_0", true)
            stats.set_bool(MPX .. "HEIST_PLANNING_DONE_HELP_1", true)
            stats.set_bool(MPX .. "HEIST_PRE_PLAN_DONE_HELP_0", true)
            stats.set_bool(MPX .. "HEIST_CUTS_DONE_FINALE", true)
            stats.set_bool(MPX .. "HEIST_IS_TUTORIAL", true)
            stats.set_bool(MPX .. "HEIST_STRAND_INTRO_DONE", true)
            stats.set_bool(MPX .. "HEIST_CUTS_DONE_ORNATE", true)
            stats.set_bool(MPX .. "HEIST_CUTS_DONE_PRISON", true)
            stats.set_bool(MPX .. "HEIST_CUTS_DONE_BIOLAB", true)
            stats.set_bool(MPX .. "HEIST_CUTS_DONE_NARCOTIC", true)
            stats.set_bool(MPX .. "HEIST_CUTS_DONE_TUTORIAL", true)
            stats.set_bool(MPX .. "HEIST_AWARD_DONE_PREP", true)
            stats.set_bool(MPX .. "HEIST_AWARD_BOUGHT_IN", true)
            stats.set_int(MPX .. "HEIST_PLANNING_STAGE", -1) end) end
  
  if ImGui.Button("Doomsday") then script.run_in_fiber(function(script)--------------------------------------------- ** Doomsday** -----------------------------------------
              stats.set_int(MPX .. "GANGOPS_HEIST_STATUS", -1)
              stats.set_int(MPX .. "GANGOPS_HEIST_STATUS", -229384)
              stats.set_int(MPX .. "GANGOPS_FM_MISSION_PROG", -1)
              stats.set_int(MPX .. "GANGOPS_FLOW_MISSION_PROG", -1)
              stats.set_int("MPPLY_GANGOPS_ALLINORDER", 100)
              stats.set_int("MPPLY_GANGOPS_LOYALTY", 100)
              stats.set_int("MPPLY_GANGOPS_CRIMMASMD", 100)
              stats.set_int("MPPLY_GANGOPS_LOYALTY2", 100)
              stats.set_int("MPPLY_GANGOPS_LOYALTY3", 100)
              stats.set_int("MPPLY_GANGOPS_CRIMMASMD2", 100)
              stats.set_int("MPPLY_GANGOPS_CRIMMASMD3", 100)
              stats.set_int("MPPLY_GANGOPS_SUPPORT", 100)
              stats.set_int(MPX .. "CR_GANGOP_MORGUE", 10)
              stats.set_int(MPX .. "CR_GANGOP_DELUXO", 10)
              stats.set_int(MPX .. "CR_GANGOP_SERVERFARM", 10)
              stats.set_int(MPX .. "CR_GANGOP_IAABASE_FIN", 10)
              stats.set_int(MPX .. "CR_GANGOP_STEALOSPREY", 10)
              stats.set_int(MPX .. "CR_GANGOP_FOUNDRY", 10)
              stats.set_int(MPX .. "CR_GANGOP_RIOTVAN", 10)
              stats.set_int(MPX .. "CR_GANGOP_SUBMARINECAR", 10)
              stats.set_int(MPX .. "CR_GANGOP_SUBMARINE_FIN", 10)
              stats.set_int(MPX .. "CR_GANGOP_PREDATOR", 10)
              stats.set_int(MPX .. "CR_GANGOP_BMLAUNCHER", 10)
              stats.set_int(MPX .. "CR_GANGOP_BCCUSTOM", 10)
              stats.set_int(MPX .. "CR_GANGOP_STEALTHTANKS", 10)
              stats.set_int(MPX .. "CR_GANGOP_SPYPLANE", 10)
              stats.set_int(MPX .. "CR_GANGOP_FINALE", 10)
              stats.set_int(MPX .. "CR_GANGOP_FINALE_P2", 10)
              stats.set_int(MPX .. "CR_GANGOP_FINALE_P3", 10)
              stats.set_bool("MPPLY_AWD_GANGOPS_IAA", true)
              stats.set_bool("MPPLY_AWD_GANGOPS_SUBMARINE", true)
              stats.set_bool("MPPLY_AWD_GANGOPS_MISSILE", true)
              stats.set_bool("MPPLY_AWD_GANGOPS_ALLINORDER", true)
              stats.set_bool("MPPLY_AWD_GANGOPS_LOYALTY", true)
              stats.set_bool("MPPLY_AWD_GANGOPS_LOYALTY2", true)
              stats.set_bool("MPPLY_AWD_GANGOPS_LOYALTY3", true)
              stats.set_bool("MPPLY_AWD_GANGOPS_CRIMMASMD", true)
              stats.set_bool("MPPLY_AWD_GANGOPS_CRIMMASMD2", true)
              stats.set_bool("MPPLY_AWD_GANGOPS_CRIMMASMD3", true)
              stats.set_bool("MPPLY_AWD_GANGOPS_SUPPORT", true)
   end)end 
  
  if ImGui.Button("After Hours") then script.run_in_fiber(function(script)--------------------------------------------- ** After Hours ** -----------------------------------------
  stats.set_int(MPX .. "AWD_DANCE_TO_SOLOMUN", 120)
  stats.set_int(MPX .. "AWD_DANCE_TO_TALEOFUS", 120)
  stats.set_int(MPX .. "AWD_DANCE_TO_DIXON", 120)
  stats.set_int(MPX .. "AWD_DANCE_TO_BLKMAD", 120)
  stats.set_int(MPX .. "AWD_CLUB_DRUNK", 200)
  stats.set_int(MPX .. "NIGHTCLUB_VIP_APPEAR", 700)
  stats.set_int(MPX .. "NIGHTCLUB_JOBS_DONE", 700)
  stats.set_int(MPX .. "NIGHTCLUB_EARNINGS", 5721002)
  stats.set_int(MPX .. "HUB_SALES_COMPLETED", 1001)
  stats.set_int(MPX .. "HUB_EARNINGS", 20721002)
  stats.set_int(MPX .. "DANCE_COMBO_DURATION_MINS", 3600000)
  stats.set_int(MPX .. "NIGHTCLUB_PLAYER_APPEAR", 100)
  stats.set_int(MPX .. "LIFETIME_HUB_GOODS_SOLD", 784672)
  stats.set_int(MPX .. "LIFETIME_HUB_GOODS_MADE", 507822)
  stats.set_int(MPX .. "DANCEPERFECTOWNCLUB", 120)
  stats.set_int(MPX .. "NUMUNIQUEPLYSINCLUB", 120)
  stats.set_int(MPX .. "DANCETODIFFDJS", 4)
  stats.set_int(MPX .. "NIGHTCLUB_HOTSPOT_TIME_MS", 3600000)
  stats.set_int(MPX .. "NIGHTCLUB_CONT_TOTAL", 20)
  stats.set_int(MPX .. "NIGHTCLUB_CONT_MISSION", -1)
  stats.set_int(MPX .. "CLUB_CONTRABAND_MISSION", 1000)
  stats.set_int(MPX .. "HUB_CONTRABAND_MISSION", 1000)
  stats.set_bool(MPX .. "AWD_CLUB_HOTSPOT", true)
  stats.set_bool(MPX .. "AWD_CLUB_CLUBBER", true)
  stats.set_bool(MPX .. "AWD_CLUB_COORD", true)
  end)end
  
  if ImGui.Button("Arena War ") then script.run_in_fiber(function(script)--------------------------------------------- ** Arena War ** -----------------------------------------
    stats.set_int(MPX .. "ARN_BS_TRINKET_TICKERS", -1)
    stats.set_int(MPX .. "ARN_BS_TRINKET_SAVED", -1)
    stats.set_int(MPX .. "AWD_WATCH_YOUR_STEP", 50)
    stats.set_int(MPX .. "AWD_TOWER_OFFENSE", 50)
    stats.set_int(MPX .. "AWD_READY_FOR_WAR", 50)
    stats.set_int(MPX .. "AWD_THROUGH_A_LENS", 50)
    stats.set_int(MPX .. "AWD_SPINNER", 50)
    stats.set_int(MPX .. "AWD_YOUMEANBOOBYTRAPS", 50)
    stats.set_int(MPX .. "AWD_MASTER_BANDITO", 50)
    stats.set_int(MPX .. "AWD_SITTING_DUCK", 50)
    stats.set_int(MPX .. "AWD_CROWDPARTICIPATION", 50)
    stats.set_int(MPX .. "AWD_KILL_OR_BE_KILLED", 50)
    stats.set_int(MPX .. "AWD_MASSIVE_SHUNT", 50)
    stats.set_int(MPX .. "AWD_YOURE_OUTTA_HERE", 200)
    stats.set_int(MPX .. "AWD_WEVE_GOT_ONE", 50)
    stats.set_int(MPX .. "AWD_ARENA_WAGEWORKER", 1000000)
    stats.set_int(MPX .. "AWD_TIME_SERVED", 1000)
    stats.set_int(MPX .. "AWD_TOP_SCORE", 55000)
    stats.set_int(MPX .. "AWD_CAREER_WINNER", 1000)
    stats.set_int(MPX .. "ARENAWARS_SP", 0)
    stats.set_int(MPX .. "ARENAWARS_SKILL_LEVEL", 20)
    stats.set_int(MPX .. "ARENAWARS_SP_LIFETIME", 100)
    stats.set_int(MPX .. "ARENAWARS_AP", 0)
    stats.set_int(MPX .. "ARENAWARS_AP_TIER", 1000)
    stats.set_int(MPX .. "ARENAWARS_AP_LIFETIME", 5055000)
    stats.set_int(MPX .. "ARENAWARS_CARRER_UNLK", -1)
    stats.set_int(MPX .. "ARN_W_THEME_SCIFI", 1000)
    stats.set_int(MPX .. "ARN_W_THEME_APOC", 1000)
    stats.set_int(MPX .. "ARN_W_THEME_CONS", 1000)
    stats.set_int(MPX .. "ARN_W_PASS_THE_BOMB", 1000)
    stats.set_int(MPX .. "ARN_W_DETONATION", 1000)
    stats.set_int(MPX .. "ARN_W_ARCADE_RACE", 1000)
    stats.set_int(MPX .. "ARN_W_CTF", 1000)
    stats.set_int(MPX .. "ARN_W_TAG_TEAM", 1000)
    stats.set_int(MPX .. "ARN_W_DESTR_DERBY", 1000)
    stats.set_int(MPX .. "ARN_W_CARNAGE", 1000)
    stats.set_int(MPX .. "ARN_W_MONSTER_JAM", 1000)
    stats.set_int(MPX .. "ARN_W_GAMES_MASTERS", 1000)
    stats.set_int(MPX .. "ARN_L_PASS_THE_BOMB", 500)
    stats.set_int(MPX .. "ARN_L_DETONATION", 500)
    stats.set_int(MPX .. "ARN_L_ARCADE_RACE", 500)
    stats.set_int(MPX .. "ARN_L_CTF", 500)
    stats.set_int(MPX .. "ARN_L_TAG_TEAM", 500)
    stats.set_int(MPX .. "ARN_L_DESTR_DERBY", 500)
    stats.set_int(MPX .. "ARN_L_CARNAGE", 500)
    stats.set_int(MPX .. "ARN_L_MONSTER_JAM", 500)
    stats.set_int(MPX .. "ARN_L_GAMES_MASTERS", 500)
    stats.set_int(MPX .. "NUMBER_OF_CHAMP_BOUGHT", 1000)
    stats.set_int(MPX .. "ARN_SPECTATOR_KILLS", 1000)
    stats.set_int(MPX .. "ARN_LIFETIME_KILLS", 1000)
    stats.set_int(MPX .. "ARN_LIFETIME_DEATHS", 500)
    stats.set_int(MPX .. "ARENAWARS_CARRER_WINS", 1000)
    stats.set_int(MPX .. "ARENAWARS_CARRER_WINT", 1000)
    stats.set_int(MPX .. "ARENAWARS_MATCHES_PLYD", 1000)
    stats.set_int(MPX .. "ARENAWARS_MATCHES_PLYDT", 1000)
    stats.set_int(MPX .. "ARN_SPEC_BOX_TIME_MS", 86400000)
    stats.set_int(MPX .. "ARN_SPECTATOR_DRONE", 1000)
    stats.set_int(MPX .. "ARN_SPECTATOR_CAMS", 1000)
    stats.set_int(MPX .. "ARN_SMOKE", 1000)
    stats.set_int(MPX .. "ARN_DRINK", 1000)
    stats.set_int(MPX .. "ARN_VEH_MONSTER", 1000)
    stats.set_int(MPX .. "ARN_VEH_MONSTER", 1000)
    stats.set_int(MPX .. "ARN_VEH_MONSTER", 1000)
    stats.set_int(MPX .. "ARN_VEH_CERBERUS", 1000)
    stats.set_int(MPX .. "ARN_VEH_CERBERUS2", 1000)
    stats.set_int(MPX .. "ARN_VEH_CERBERUS3", 1000)
    stats.set_int(MPX .. "ARN_VEH_BRUISER", 1000)
    stats.set_int(MPX .. "ARN_VEH_BRUISER2", 1000)
    stats.set_int(MPX .. "ARN_VEH_BRUISER3", 1000)
    stats.set_int(MPX .. "ARN_VEH_SLAMVAN4", 1000)
    stats.set_int(MPX .. "ARN_VEH_SLAMVAN5", 1000)
    stats.set_int(MPX .. "ARN_VEH_SLAMVAN6", 1000)
    stats.set_int(MPX .. "ARN_VEH_BRUTUS", 1000)
    stats.set_int(MPX .. "ARN_VEH_BRUTUS2", 1000)
    stats.set_int(MPX .. "ARN_VEH_BRUTUS3", 1000)
    stats.set_int(MPX .. "ARN_VEH_SCARAB", 1000)
    stats.set_int(MPX .. "ARN_VEH_SCARAB2", 1000)
    stats.set_int(MPX .. "ARN_VEH_SCARAB3", 1000)
    stats.set_int(MPX .. "ARN_VEH_DOMINATOR4", 1000)
    stats.set_int(MPX .. "ARN_VEH_DOMINATOR5", 1000)
    stats.set_int(MPX .. "ARN_VEH_DOMINATOR6", 1000)
    stats.set_int(MPX .. "ARN_VEH_IMPALER2", 1000)
    stats.set_int(MPX .. "ARN_VEH_IMPALER3", 1000)
    stats.set_int(MPX .. "ARN_VEH_IMPALER4", 1000)
    stats.set_int(MPX .. "ARN_VEH_ISSI4", 1000)
    stats.set_int(MPX .. "ARN_VEH_ISSI5", 1000)
    stats.set_int(MPX .. "ARN_VEH_ISSI", 61000)
    stats.set_int(MPX .. "ARN_VEH_IMPERATOR", 1000)
    stats.set_int(MPX .. "ARN_VEH_IMPERATOR2", 1000)
    stats.set_int(MPX .. "ARN_VEH_IMPERATOR3", 1000)
    stats.set_int(MPX .. "ARN_VEH_ZR380", 1000)
    stats.set_int(MPX .. "ARN_VEH_ZR3802", 1000)
    stats.set_int(MPX .. "ARN_VEH_ZR3803", 1000)
    stats.set_int(MPX .. "ARN_VEH_DEATHBIKE", 1000)
    stats.set_int(MPX .. "ARN_VEH_DEATHBIKE2", 1000)
    stats.set_int(MPX .. "ARN_VEH_DEATHBIKE3", 1000)
    stats.set_bool(MPX .. "AWD_BEGINNER", true)
    stats.set_bool(MPX .. "AWD_FIELD_FILLER", true)
    stats.set_bool(MPX .. "AWD_ARMCHAIR_RACER", true)
    stats.set_bool(MPX .. "AWD_LEARNER", true)
    stats.set_bool(MPX .. "AWD_SUNDAY_DRIVER", true)
    stats.set_bool(MPX .. "AWD_THE_ROOKIE", true)
    stats.set_bool(MPX .. "AWD_BUMP_AND_RUN", true)
    stats.set_bool(MPX .. "AWD_GEAR_HEAD", true)
    stats.set_bool(MPX .. "AWD_DOOR_SLAMMER", true)
    stats.set_bool(MPX .. "AWD_HOT_LAP", true)
    stats.set_bool(MPX .. "AWD_ARENA_AMATEUR", true)
    stats.set_bool(MPX .. "AWD_PAINT_TRADER", true)
    stats.set_bool(MPX .. "AWD_SHUNTER", true)
    stats.set_bool(MPX .. "AWD_JOCK", true)
    stats.set_bool(MPX .. "AWD_WARRIOR", true)
    stats.set_bool(MPX .. "AWD_T_BONE", true)
    stats.set_bool(MPX .. "AWD_MAYHEM", true)
    stats.set_bool(MPX .. "AWD_WRECKER", true)
    stats.set_bool(MPX .. "AWD_CRASH_COURSE", true)
    stats.set_bool(MPX .. "AWD_ARENA_LEGEND", true)
    stats.set_bool(MPX .. "AWD_PEGASUS", true)
    stats.set_bool(MPX .. "AWD_UNSTOPPABLE", true)
    stats.set_bool(MPX .. "AWD_CONTACT_SPORT", true)
    stats.set_masked_int(MPX.."ARENAWARSPSTAT_INT", 1, 35, 8)
    end)end
    
  if ImGui.Button("Diamond Casino Resort") then script.run_in_fiber(function(script)--------------------------------------------- ** Diamond Casino Resort ** -----------------------------------------
    stats.set_int(MPX .. "AWD_ODD_JOBS", 50)
    stats.set_int(MPX .. "VCM_FLOW_PROGRESS", -1)
    stats.set_int(MPX .. "VCM_STORY_PROGRESS", 5)
    stats.set_bool(MPX .. "AWD_FIRST_TIME1", true)
    stats.set_bool(MPX .. "AWD_FIRST_TIME2", true)
    stats.set_bool(MPX .. "AWD_FIRST_TIME3", true)
    stats.set_bool(MPX .. "AWD_FIRST_TIME4", true)
    stats.set_bool(MPX .. "AWD_FIRST_TIME5", true)
    stats.set_bool(MPX .. "AWD_FIRST_TIME6", true)
    stats.set_bool(MPX .. "AWD_ALL_IN_ORDER", true)
    stats.set_bool(MPX .. "AWD_SUPPORTING_ROLE", true)
    stats.set_bool(MPX .. "AWD_LEADER", true)
    stats.set_bool(MPX .. "AWD_SURVIVALIST", true) end)end
  
  if ImGui.Button("Diamond Casino Heist") then script.run_in_fiber(function(script)--------------------------------------------- ** Diamond Casino Heist ** -----------------------------------------
    stats.set_int(MPX .. "CAS_HEIST_NOTS", -1)
    stats.set_int(MPX .. "CAS_HEIST_FLOW", -1)
    stats.set_int(MPX .. "SIGNAL_JAMMERS_COLLECTED", 50)
    stats.set_int(MPX .. "AWD_PREPARATION", 40)
    stats.set_int(MPX .. "AWD_ASLEEPONJOB", 20)
    stats.set_int(MPX .. "AWD_DAICASHCRAB", 100000)
    stats.set_int(MPX .. "AWD_BIGBRO", 40)
    stats.set_int(MPX .. "AWD_SHARPSHOOTER", 40)
    stats.set_int(MPX .. "AWD_RACECHAMP", 40)
    stats.set_int(MPX .. "AWD_BATSWORD", 1000000)
    stats.set_int(MPX .. "AWD_COINPURSE", 950000)
    stats.set_int(MPX .. "AWD_ASTROCHIMP", 3000000)
    stats.set_int(MPX .. "AWD_MASTERFUL", 40000)
    stats.set_int(MPX .. "H3_BOARD_DIALOGU262145 +E0", -1)
    stats.set_int(MPX .. "H3_BOARD_DIALOGUE1", -1)
    stats.set_int(MPX .. "H3_BOARD_DIALOGUE2", -1)
    stats.set_int(MPX .. "H3_VEHICLESUSED", -1)
    stats.set_int(MPX .. "H3_CR_STEALTH_1A", 100)
    stats.set_int(MPX .. "H3_CR_STEALTH_2B_RAPP", 100)
    stats.set_int(MPX .. "H3_CR_STEALTH_2C_SIDE", 100)
    stats.set_int(MPX .. "H3_CR_STEALTH_3A", 100)
    stats.set_int(MPX .. "H3_CR_STEALTH_4A", 100)
    stats.set_int(MPX .. "H3_CR_STEALTH_5A", 100)
    stats.set_int(MPX .. "H3_CR_SUBTERFUGE_1A", 100)
    stats.set_int(MPX .. "H3_CR_SUBTERFUGE_2A", 100)
    stats.set_int(MPX .. "H3_CR_SUBTERFUGE_2B", 100)
    stats.set_int(MPX .. "H3_CR_SUBTERFUGE_3A", 100)
    stats.set_int(MPX .. "H3_CR_SUBTERFUGE_3B", 100)
    stats.set_int(MPX .. "H3_CR_SUBTERFUGE_4A", 100)
    stats.set_int(MPX .. "H3_CR_SUBTERFUGE_5A", 100)
    stats.set_int(MPX .. "H3_CR_DIRECT_1A", 100)
    stats.set_int(MPX .. "H3_CR_DIRECT_2A1", 100)
    stats.set_int(MPX .. "H3_CR_DIRECT_2A2", 100)
    stats.set_int(MPX .. "H3_CR_DIRECT_2BP", 100)
    stats.set_int(MPX .. "H3_CR_DIRECT_2C", 100)
    stats.set_int(MPX .. "H3_CR_DIRECT_3A", 100)
    stats.set_int(MPX .. "H3_CR_DIRECT_4A", 100)
    stats.set_int(MPX .. "H3_CR_DIRECT_5A", 100)
    stats.set_int(MPX .. "CR_ORDER", 100)
    stats.set_bool(MPX .. "AWD_SCOPEOUT", true)
    stats.set_bool(MPX .. "AWD_CREWEDUP", true)
    stats.set_bool(MPX .. "AWD_MOVINGON", true)
    stats.set_bool(MPX .. "AWD_PROMOCAMP", true)
    stats.set_bool(MPX .. "AWD_GUNMAN", true)
    stats.set_bool(MPX .. "AWD_SMASHNGRAB", true)
    stats.set_bool(MPX .. "AWD_INPLAINSI", true)
    stats.set_bool(MPX .. "AWD_UNDETECTED", true)
    stats.set_bool(MPX .. "AWD_ALLROUND", true)
    stats.set_bool(MPX .. "AWD_ELITETHEIF", true)
    stats.set_bool(MPX .. "AWD_PRO", true)
    stats.set_bool(MPX .. "AWD_SUPPORTACT", true)
    stats.set_bool(MPX .. "AWD_SHAFTED", true)
    stats.set_bool(MPX .. "AWD_COLLECTOR", true)
    stats.set_bool(MPX .. "AWD_DEADEYE", true)
    stats.set_bool(MPX .. "AWD_PISTOLSATDAWN", true)
    stats.set_bool(MPX .. "AWD_TRAFFICAVOI", true)
    stats.set_bool(MPX .. "AWD_CANTCATCHBRA", true)
    stats.set_bool(MPX .. "AWD_WIZHARD", true)
    stats.set_bool(MPX .. "AWD_APEESCAPE", true)
    stats.set_bool(MPX .. "AWD_MONKEYKIND", true)
    stats.set_bool(MPX .. "AWD_AQUAAPE", true)
    stats.set_bool(MPX .. "AWD_KEEPFAITH", true)
    stats.set_bool(MPX .. "AWD_TRUELOVE", true)
    stats.set_bool(MPX .. "AWD_NEMESIS", true)
    stats.set_bool(MPX .. "AWD_FRIENDZONED", true)
    stats.set_bool(MPX .. "VCM_FLOW_CS_RSC_SEEN", true)
    stats.set_bool(MPX .. "VCM_FLOW_CS_BWL_SEEN", true)
    stats.set_bool(MPX .. "VCM_FLOW_CS_MTG_SEEN", true)
    stats.set_bool(MPX .. "VCM_FLOW_CS_OIL_SEEN", true)
    stats.set_bool(MPX .. "VCM_FLOW_CS_DEF_SEEN", true)
    stats.set_bool(MPX .. "VCM_FLOW_CS_FIN_SEEN", true)
    stats.set_bool(MPX .. "HELP_FURIA", true)
    stats.set_bool(MPX .. "HELP_MINITAN", true)
    stats.set_bool(MPX .. "HELP_YOSEMITE2", true)
    stats.set_bool(MPX .. "HELP_ZHABA", true)
    stats.set_bool(MPX .. "HELP_IMORGEN", true)
    stats.set_bool(MPX .. "HELP_SULTAN2", true)
    stats.set_bool(MPX .. "HELP_VAGRANT", true)
    stats.set_bool(MPX .. "HELP_VSTR", true)
    stats.set_bool(MPX .. "HELP_STRYDER", true)
    stats.set_bool(MPX .. "HELP_SUGOI", true)
    stats.set_bool(MPX .. "HELP_KANJO", true)
    stats.set_bool(MPX .. "HELP_FORMULA", true)
    stats.set_bool(MPX .. "HELP_FORMULA2", true)
    stats.set_bool(MPX .. "HELP_JB7002", true) end) end
  
  if ImGui.Button("Arcade") then script.run_in_fiber(function(script)--------------------------------------------- ** Arcade ** -----------------------------------------
  stats.set_int(MPX .. "AWD_PREPARATION", 50)
  stats.set_int(MPX .. "AWD_ASLEEPONJOB", 20)
  stats.set_int(MPX .. "AWD_DAICASHCRAB", 100000)
  stats.set_int(MPX .. "AWD_BIGBRO", 40)
  stats.set_int(MPX .. "AWD_SHARPSHOOTER", 40)
  stats.set_int(MPX .. "AWD_RACECHAMP", 40)
  stats.set_int(MPX .. "AWD_BATSWORD", 1000000)
  stats.set_int(MPX .. "AWD_COINPURSE", 950000)
  stats.set_int(MPX .. "AWD_ASTROCHIMP", 3000000)
  stats.set_int(MPX .. "AWD_MASTERFUL", 40000)
  stats.set_int(MPX .. "SCGW_NUM_WINS_GANG_0", 50)
  stats.set_int(MPX .. "SCGW_NUM_WINS_GANG_1", 50)
  stats.set_int(MPX .. "SCGW_NUM_WINS_GANG_2", 50)
  stats.set_int(MPX .. "SCGW_NUM_WINS_GANG_3", 50)
  stats.set_int(MPX .. "CH_ARC_CAB_CLAW_TROPHY", -1)
  stats.set_int(MPX .. "CH_ARC_CAB_LOVE_TROPHY", -1)
  stats.set_int(MPX .. "IAP_MAX_MOON_DIST", 2147483647)
  stats.set_int(MPX .. "SCGW_INITIALS_0", 69644)
  stats.set_int(MPX .. "SCGW_INITIALS_1", 50333)
  stats.set_int(MPX .. "SCGW_INITIALS_2", 63512)
  stats.set_int(MPX .. "SCGW_INITIALS_3", 46136)
  stats.set_int(MPX .. "SCGW_INITIALS_4", 21638)
  stats.set_int(MPX .. "SCGW_INITIALS_5", 2133)
  stats.set_int(MPX .. "SCGW_INITIALS_6", 1215)
  stats.set_int(MPX .. "SCGW_INITIALS_7", 2444)
  stats.set_int(MPX .. "SCGW_INITIALS_8", 38023)
  stats.set_int(MPX .. "SCGW_INITIALS_9", 2233)
  stats.set_int(MPX .. "FOOTAGE_INITIALS_0",0)
  stats.set_int(MPX .. "FOOTAGE_INITIALS_1", 64)
  stats.set_int(MPX .. "FOOTAGE_INITIALS_2", 8457)
  stats.set_int(MPX .. "FOOTAGE_INITIALS_3", 91275)
  stats.set_int(MPX .. "FOOTAGE_INITIALS_4", 53260)
  stats.set_int(MPX .. "FOOTAGE_INITIALS_5", 78663)
  stats.set_int(MPX .. "FOOTAGE_INITIALS_6", 25103)
  stats.set_int(MPX .. "FOOTAGE_INITIALS_7", 102401)
  stats.set_int(MPX .. "FOOTAGE_INITIALS_8", 12672)
  stats.set_int(MPX .. "FOOTAGE_INITIALS_9", 74380)
  stats.set_int(MPX .. "FOOTAGE_SCORE_0", 284544)
  stats.set_int(MPX .. "FOOTAGE_SCORE_1", 275758)
  stats.set_int(MPX .. "FOOTAGE_SCORE_2", 100000)
  stats.set_int(MPX .. "FOOTAGE_SCORE_3", 90000)
  stats.set_int(MPX .. "FOOTAGE_SCORE_4", 80000)
  stats.set_int(MPX .. "FOOTAGE_SCORE_5", 70000)
  stats.set_int(MPX .. "FOOTAGE_SCORE_6", 60000)
  stats.set_int(MPX .. "FOOTAGE_SCORE_7", 50000)
  stats.set_int(MPX .. "FOOTAGE_SCORE_8", 40000)
  stats.set_int(MPX .. "FOOTAGE_SCORE_9", 30000)
  stats.set_int(MPX .. "IAP_INITIALS_" .. i, 50)
  stats.set_int(MPX .. "IAP_SCORE_" .. i, 50)
  stats.set_int(MPX .. "IAP_SCORE_" .. i, 50)
  stats.set_int(MPX .. "SCGW_SCORE_" .. i, 50)
  stats.set_int(MPX .. "DG_DEFENDER_INITIALS_" .. i, 69644)
  stats.set_int(MPX .. "DG_DEFENDER_SCORE_" .. i, 50)
  stats.set_int(MPX .. "DG_MONKEY_INITIALS_" .. i, 69644)
  stats.set_int(MPX .. "DG_MONKEY_SCORE_" .. i, 50)
  stats.set_int(MPX .. "DG_PENETRATOR_INITIALS_" .. i, 69644)
  stats.set_int(MPX .. "DG_PENETRATOR_SCORE_" .. i, 50)
  stats.set_int(MPX .. "GGSM_INITIALS_" .. i, 69644)
  stats.set_int(MPX .. "GGSM_SCORE_" .. i, 50)
  stats.set_int(MPX .. "TWR_INITIALS_" .. i, 69644)
  stats.set_int(MPX .. "TWR_SCORE_" .. i, 50)
  stats.set_bool(MPX .. "AWD_SCOPEOUT", true)
  stats.set_bool(MPX .. "AWD_CREWEDUP", true)
  stats.set_bool(MPX .. "AWD_MOVINGON", true)
  stats.set_bool(MPX .. "AWD_PROMOCAMP", true)
  stats.set_bool(MPX .. "AWD_GUNMAN", true)
  stats.set_bool(MPX .. "AWD_SMASHNGRAB", true)
  stats.set_bool(MPX .. "AWD_INPLAINSI", true)
  stats.set_bool(MPX .. "AWD_UNDETECTED", true)
  stats.set_bool(MPX .. "AWD_ALLROUND", true)
  stats.set_bool(MPX .. "AWD_ELITETHEIF", true)
  stats.set_bool(MPX .. "AWD_PRO", true)
  stats.set_bool(MPX .. "AWD_SUPPORTACT", true)
  stats.set_bool(MPX .. "AWD_SHAFTED", true)
  stats.set_bool(MPX .. "AWD_COLLECTOR", true)
  stats.set_bool(MPX .. "AWD_DEADEYE", true)
  stats.set_bool(MPX .. "AWD_PISTOLSATDAWN", true)
  stats.set_bool(MPX .. "AWD_TRAFFICAVOI", true)
  stats.set_bool(MPX .. "AWD_CANTCATCHBRA", true)
  stats.set_bool(MPX .. "AWD_WIZHARD", true)
  stats.set_bool(MPX .. "AWD_APEESCAP", true)
  stats.set_bool(MPX .. "AWD_MONKEYKIND", true)
  stats.set_bool(MPX .. "AWD_AQUAAPE", true)
  stats.set_bool(MPX .. "AWD_KEEPFAITH", true)
  stats.set_bool(MPX .. "AWD_TRUELOVE", true)
  stats.set_bool(MPX .. "AWD_NEMESIS", true)
  stats.set_bool(MPX .. "AWD_FRIENDZONED", true)
  stats.set_bool(MPX .. "IAP_CHALLENGE_0", true)
  stats.set_bool(MPX .. "IAP_CHALLENGE_1", true)
  stats.set_bool(MPX .. "IAP_CHALLENGE_3", true)
  stats.set_bool(MPX .. "IAP_CHALLENGE_4", true)
  stats.set_bool(MPX .. "IAP_GOLD_TANK", true)
  stats.set_bool(MPX .. "SCGW_WON_NO_DEATHS", true) end)end
  
  if ImGui.Button("LS Summer Special") then script.run_in_fiber(function(script)--------------------------------------------- ** LS Summer Special ** ----------------------------------------- 
  stats.set_bool(MPX .. "AWD_KINGOFQUB3D", true)
  stats.set_bool(MPX .. "AWD_QUBISM", true)
  stats.set_bool(MPX .. "AWD_QUIBITS", true)
  stats.set_bool(MPX .. "AWD_GODOFQUB3D", true)
  stats.set_bool(MPX .. "AWD_ELEVENELEVEN", true)
  stats.set_bool(MPX .. "AWD_GOFOR11TH", true)
  stats.set_masked_int(MPX.."SU20PSTAT_INT", 1, 35, 8) end)end
  
  if ImGui.Button("Cayo Perico") then script.run_in_fiber(function(script)--------------------------------------------- ** Cayo Perico ** ----------------------------------------- 
  stats.set_bool(MPX .. "AWD_INTELGATHER", true)
  stats.set_bool(MPX .. "AWD_COMPOUNDINFILT", true)
  stats.set_bool(MPX .. "AWD_LOOT_FINDER", true)
  stats.set_bool(MPX .. "AWD_MAX_DISRUPT", true)
  stats.set_bool(MPX .. "AWD_THE_ISLAND_HEIST", true)
  stats.set_bool(MPX .. "AWD_GOING_ALONE", true)
  stats.set_bool(MPX .. "AWD_TEAM_WORK", true)
  stats.set_bool(MPX .. "AWD_MIXING_UP", true)
  stats.set_bool(MPX .. "AWD_TEAM_WORK", true)
  stats.set_bool(MPX .. "AWD_MIXING_UP", true)
  stats.set_bool(MPX .. "AWD_PRO_THIEF", true)
  stats.set_bool(MPX .. "AWD_CAT_BURGLAR", true)
  stats.set_bool(MPX .. "AWD_ONE_OF_THEM", true)
  stats.set_bool(MPX .. "AWD_GOLDEN_GUN", true)
  stats.set_bool(MPX .. "AWD_ELITE_THIEF", true)
  stats.set_bool(MPX .. "AWD_PROFESSIONAL", true)
  stats.set_bool(MPX .. "AWD_HELPING_OUT", true)
  stats.set_bool(MPX .. "AWD_COURIER", true)
  stats.set_bool(MPX .. "AWD_PARTY_VIBES", true)
  stats.set_bool(MPX .. "AWD_HELPING_HAND", true)
  stats.set_bool(MPX .. "AWD_ELEVENELEVEN", true)
  stats.set_bool(MPX .. "COMPLETE_H4_F_USING_VETIR", true)
  stats.set_bool(MPX .. "COMPLETE_H4_F_USING_LONGFIN", true)
  stats.set_bool(MPX .. "COMPLETE_H4_F_USING_ANNIH", true)
  stats.set_bool(MPX .. "COMPLETE_H4_F_USING_ALKONOS", true)
  stats.set_bool(MPX .. "COMPLETE_H4_F_USING_PATROLB", true)
  stats.set_int(MPX .. "AWD_LOSTANDFOUND", 500000)
  stats.set_int(MPX .. "AWD_SUNSET", 1800000)
  stats.set_int(MPX .. "AWD_TREASURE_HUNTER", 1000000)
  stats.set_int(MPX .. "AWD_WRECK_DIVING", 1000000)
  stats.set_int(MPX .. "AWD_KEINEMUSIK", 1800000)
  stats.set_int(MPX .. "AWD_PALMS_TRAX", 1800000)
  stats.set_int(MPX .. "AWD_MOODYMANN", 1800000)
  stats.set_int(MPX .. "AWD_FILL_YOUR_BAGS", 1000000000)
  stats.set_int(MPX .. "AWD_WELL_PREPARED", 80)
  stats.set_int(MPX .. "H4_H4_DJ_MISSIONS", -1)
  stats.set_int(MPX .. "H4CNF_APPROACH", -1)
  stats.set_int(MPX .. "H4_MISSIONS", -1)
  stats.set_int(MPX .. "H4_PLAYTHROUGH_STATUS", 100)end)end
  
  if ImGui.Button("LS Tuners") then script.run_in_fiber(function(script)--------------------------------------------- ** LS Tuners ** ----------------------------------------- 
  stats.set_int(MPX .. "AWD_CAR_CLUB_MEM", 100)
  stats.set_int(MPX .. "AWD_SPRINTRACER", 50)
  stats.set_int(MPX .. "AWD_STREETRACER", 50)
  stats.set_int(MPX .. "AWD_PURSUITRACER", 50)
  stats.set_int(MPX .. "AWD_TEST_CAR", 240)
  stats.set_int(MPX .. "AWD_AUTO_SHOP", 50)
  stats.set_int(MPX .. "AWD_GROUNDWORK", 40)
  stats.set_int(MPX .. "AWD_CAR_EXPORT", 100)
  stats.set_int(MPX .. "AWD_ROBBERY_CONTRACT", 100)
  stats.set_int(MPX .. "AWD_FACES_OF_DEATH", 100)
  stats.set_bool(MPX .. "AWD_CAR_CLUB", true)
  stats.set_bool(MPX .. "AWD_PRO_CAR_EXPORT", true)
  stats.set_bool(MPX .. "AWD_UNION_DEPOSITORY", true)
  stats.set_bool(MPX .. "AWD_MILITARY_CONVOY", true)
  stats.set_bool(MPX .. "AWD_FLEECA_BANK", true)
  stats.set_bool(MPX .. "AWD_FREIGHT_TRAIN", true)
  stats.set_bool(MPX .. "AWD_BOLINGBROKE_ASS", true)
  stats.set_bool(MPX .. "AWD_IAA_RAID", true)
  stats.set_bool(MPX .. "AWD_METH_JOB", true)
  stats.set_bool(MPX .. "AWD_BUNKER_RAID", true)
  stats.set_bool(MPX .. "AWD_STRAIGHT_TO_VIDEO", true)
  stats.set_bool(MPX .. "AWD_MONKEY_C_MONKEY_DO", true)
  stats.set_bool(MPX .. "AWD_TRAINED_TO_KILL", true)
  stats.set_bool(MPX .. "AWD_DIRECTOR", true) 
  end)end
  
  if ImGui.Button("Contract") then script.run_in_fiber(function(script)--------------------------------------------- ** Contract ** ----------------------------------------- 
    stats.set_int(MPX .. "AWD_CONTRACTOR", 50)
    stats.set_int(MPX .. "AWD_COLD_CALLER", 50)
    stats.set_int(MPX .. "AWD_PRODUCER", 60)
    stats.set_int(MPX .. "FIXERTELEPHONEHITSCOMPL", 10)
    stats.set_int(MPX .. "PAYPHONE_BONUS_KILL_METHOD", 10)
    stats.set_int(MPX .. "PAYPHONE_BONUS_KILL_METHOD", -1)
    stats.set_int(MPX .. "FIXER_GENERAL_BS", -1)
    stats.set_int(MPX .. "FIXER_COMPLETED_BS", -1)
    stats.set_int(MPX .. "FIXER_STORY_BS", -1)
    stats.set_int(MPX .. "FIXER_STORY_STRAND", -1)
    stats.set_int(MPX .. "FIXER_STORY_COOLDOWN", -1)
    stats.set_int(MPX .. "FIXER_COUNT", 510)
    stats.set_int(MPX .. "FIXER_SC_VEH_RECOVERED", 85)
    stats.set_int(MPX .. "FIXER_SC_VAL_RECOVERED", 85)
    stats.set_int(MPX .. "FIXER_SC_GANG_TERMINATED", 85)
    stats.set_int(MPX .. "FIXER_SC_VIP_RESCUED", 85)
    stats.set_int(MPX .. "FIXER_SC_ASSETS_PROTECTED", 85)
    stats.set_int(MPX .. "FIXER_SC_EQ_DESTROYED", 85)
    stats.set_int(MPX .. "FIXER_EARNINGS", 19734860)
    stats.set_bool(MPX .. "AWD_TEEING_OFF", true)
    stats.set_bool(MPX .. "AWD_PARTY_NIGHT", true)
    stats.set_bool(MPX .. "AWD_BILLIONAIRE_GAMES", true)
    stats.set_bool(MPX .. "AWD_HOOD_PASS", true)
    stats.set_bool(MPX .. "AWD_STUDIO_TOUR", true)
    stats.set_bool(MPX .. "AWD_DONT_MESS_DRE", true)
    stats.set_bool(MPX .. "AWD_BACKUP", true)
    stats.set_bool(MPX .. "AWD_SHORTFRANK_1", true)
    stats.set_bool(MPX .. "AWD_SHORTFRANK_2", true)
    stats.set_bool(MPX .. "AWD_SHORTFRANK_3", true)
    stats.set_bool(MPX .. "AWD_CONTR_KILLER", true)
    stats.set_bool(MPX .. "AWD_DOGS_BEST_FRIEND", true)
    stats.set_bool(MPX .. "AWD_MUSIC_STUDIO", true)
    stats.set_bool(MPX .. "AWD_SHORTLAMAR_1", true)
    stats.set_bool(MPX .. "AWD_SHORTLAMAR_2", true)
    stats.set_bool(MPX .. "AWD_SHORTLAMAR_3", true)
    stats.set_bool(MPX .. "BS_FRANKLIN_DIALOGUE_0", true)
    stats.set_bool(MPX .. "BS_FRANKLIN_DIALOGUE_1", true)
    stats.set_bool(MPX .. "BS_FRANKLIN_DIALOGUE_2", true)
    stats.set_bool(MPX .. "BS_IMANI_D_APP_SETUP", true)
    stats.set_bool(MPX .. "BS_IMANI_D_APP_STRAND", true)
    stats.set_bool(MPX .. "BS_IMANI_D_APP_PARTY", true)
    stats.set_bool(MPX .. "BS_IMANI_D_APP_PARTY_2", true)
    stats.set_bool(MPX .. "BS_IMANI_D_APP_PARTY_F", true)
    stats.set_bool(MPX .. "BS_IMANI_D_APP_BILL", true)
    stats.set_bool(MPX .. "BS_IMANI_D_APP_BILL_2", true)
    stats.set_bool(MPX .. "BS_IMANI_D_APP_BILL_F", true)
    stats.set_bool(MPX .. "BS_IMANI_D_APP_HOOD", true)
    stats.set_bool(MPX .. "BS_IMANI_D_APP_HOOD_2", true)
    stats.set_bool(MPX .. "BS_IMANI_D_APP_HOOD_F", true)
  
  
   end)end
  
  if ImGui.Button("Drug Wars") then script.run_in_fiber(function(script) --------------------------------------------- ** Drug Warse ** ----------------------------------------- 
    stats.set_bool(MPX .. "AWD_ACELIQUOR", true)
    stats.set_bool(MPX .. "AWD_TRUCKAMBUSH", true)
    stats.set_bool(MPX .. "AWD_LOSTCAMPREV", true)
    stats.set_bool(MPX .. "AWD_ACIDTRIP", true)
    stats.set_bool(MPX .. "AWD_HIPPYRIVALS", true)
    stats.set_bool(MPX .. "AWD_TRAINCRASH", true)
    stats.set_bool(MPX .. "AWD_BACKUPB", true)
    stats.set_bool(MPX .. "AWD_GETSTARTED", true)
    stats.set_bool(MPX .. "AWD_CHEMREACTION", true)
    stats.set_bool(MPX .. "AAWD_WAREHODEFEND", true)
    stats.set_bool(MPX .. "AWD_ATTACKINVEST", true)
    stats.set_bool(MPX .. "AWD_RESCUECOOK", true)
    stats.set_bool(MPX .. "AWD_DRUGTRIPREHAB", true)
    stats.set_bool(MPX .. "AWD_CARGOPLANE", true)
    stats.set_bool(MPX .. "AWD_BACKUPB2", true)
    stats.set_bool(MPX .. "AWD_TAXISTAR", true)
    stats.set_int(MPX .. "AWD_RUNRABBITRUN", 5)
    stats.set_int(MPX .. "AWD_CALLME", 50)
  stats.set_int(MPX .. "AWD_CHEMCOMPOUNDS", 50) end)end
  ImGui.EndMenu()end 
             

  if ImGui.Button("Unlock LSCar Meet Prize") then script.run_in_fiber(function(script) --------------------------------------------- ** LUnlock LSCar Meet Prize ** ----------------------------------------- 
  stats.set_bool(MPX .. "CARMEET_PV_CHLLGE_CMPLT", true)end)end
            
  if ImGui.Button("LSC Things Unlock ") then script.run_in_fiber(function(script) --------------------------------------------- ** LSC Things Unlock ** ----------------------------------------- 
    stats.set_int(MPX .. "CHAR_FM_CARMOD_1_UNLCK", -1)
       stats.set_int(MPX .. "CHAR_FM_CARMOD_2_UNLCK",-1)
       stats.set_int(MPX .. "CHAR_FM_CARMOD_3_UNLCK", -1)
       stats.set_int(MPX .. "CHAR_FM_CARMOD_4_UNLCK", -1)
       stats.set_int(MPX .. "CHAR_FM_CARMOD_5_UNLCK", -1)
       stats.set_int(MPX .. "CHAR_FM_CARMOD_6_UNLCK", -1)
       stats.set_int(MPX .. "CHAR_FM_CARMOD_7_UNLCK", -1)
       stats.set_int(MPX .. "AWD_WIN_CAPTURES", 50)
       stats.set_int(MPX .. "AWD_DROPOFF_CAP_PACKAGES", 100)
       stats.set_int(MPX .. "AWD_KILL_CARRIER_CAPTURE", 100)
       stats.set_int(MPX .. "AWD_FINISH_HEISTS", 50)
       stats.set_int(MPX .. "AWD_FINISH_HEIST_SETUP_JOB", 50)
       stats.set_int(MPX .. "AWD_NIGHTVISION_KILLS", 100)
       stats.set_int(MPX .. "AWD_WIN_LAST_TEAM_STANDINGS", 50)
       stats.set_int(MPX .. "AWD_ONLY_PLAYER_ALIVE_LTS", 50)
       stats.set_int(MPX .. "AWD_FMRALLYWONDRIVE", 25)
       stats.set_int(MPX .. "AWD_FMRALLYWONNAV", 25)
       stats.set_int(MPX .. "AWD_FMWINSEARACE", 25)
       stats.set_int(MPX .. "AWD_RACES_WON", 50)
       stats.set_int(MPX .. "MOST_FLIPS_IN_ONE_JUMP", 5)
       stats.set_int(MPX .. "MOST_SPINS_IN_ONE_JUMP", 5)
       stats.set_int(MPX .. "NUMBER_SLIPSTREAMS_IN_RACE", 100)
       stats.set_int(MPX .. "NUMBER_TURBO_STARTS_IN_RACE", 50)
       stats.set_int(MPX .. "RACES_WON", 50)
       stats.set_int(MPX .. "USJS_COMPLETED", 50)
       stats.set_int(MPX .. "AWD_FM_GTA_RACES_WON", 50)
       stats.set_int(MPX .. "AWD_FM_RACE_LAST_FIRST", 25)
       stats.set_int(MPX .. "AWD_FM_RACES_FASTEST_LAP", 50)
       stats.set_int(MPX .. "AWD_FMBASEJMP", 25)
       stats.set_int(MPX .. "AWD_FMWINAIRRACE", 25)
       stats.set_int("MPPLY_TOTAL_RACES_WON", 50) end)end
  
  if ImGui.Button("Unlock Hidden Librarie") then script.run_in_fiber(function(script) --------------------------------------------- ** Unlock Hidden Librarie ** ----------------------------------------- 
        stats.set_int("MPPLY_XMASLIVERIES", -1) 
        stats.set_int("MPPLY_XMASLIVERIES", -1) end)end
         
  if ImGui.Button("Vanilla Unicorn") then script.run_in_fiber(function(script)  --------------------------------------------- ** Vanilla Unicorn ** ----------------------------------------- 
        stats.set_int(MPX .. "LAP_DANCED_BOUGHT", 0) 
        stats.set_int(MPX .. "LAP_DANCED_BOUGHT", 5) 
        stats.set_int(MPX .. "LAP_DANCED_BOUGHT", 10) 
        stats.set_int(MPX .. "LAP_DANCED_BOUGHT", 15) 
        stats.set_int(MPX .. "LAP_DANCED_BOUGHT", 25) 
        stats.set_int(MPX .. "PROSTITUTES_FREQUENTED", 1000) end)end
        
  if ImGui.Button("Unlock tatoos") then script.run_in_fiber(function(script)  ---------------------------------------------- ** Unlock tatoos ** ----------------------------------------- 
        stats.set_int(MPX .. "TATTOO_FM_CURRENT_32", -1) 
        stats.set_int(MPX .. "TATTOO_FM_UNLOCKS_", -1) end)end
  
  if ImGui.Button("Unlock Weapons") then script.run_in_fiber(function(script) ---------------------------------------------- ** Unlock Weapons ** -----------------------------------------  
    stats.set_int(MPX .. "MOLOTOV_ENEMY_KILLS", 600)
    stats.set_int(MPX .. "CMBTPISTOL_ENEMY_KILLS", 600)
    stats.set_int(MPX .. "PISTOL50_ENEMY_KILLS", 600)
    stats.set_int(MPX .. "APPISTOL_ENEMY_KILLS", 600)
    stats.set_int(MPX .. "MICROSMG_ENEMY_KILLS", 600)
    stats.set_int(MPX .. "SMG_ENEMY_KILLS", 600)
    stats.set_int(MPX .. "ASLTSMG_ENEMY_KILLS", 600)
    stats.set_int(MPX .. "ASLTRIFLE_ENEMY_KILLS", 600)
    stats.set_int(MPX .. "CRBNRIFLE_ENEMY_KILLS", 600)
    stats.set_int(MPX .. "ADVRIFLE_ENEMY_KILLS", 600)
    stats.set_int(MPX .. "MG_ENEMY_KILLS", 600)
    stats.set_int(MPX .. "CMBTMG_ENEMY_KILLS", 600)
    stats.set_int(MPX .. "ASLTMG_ENEMY_KILLS", 600)
    stats.set_int(MPX .. "PUMP_ENEMY_KILLS", 600)
    stats.set_int(MPX .. "SAWNOFF_ENEMY_KILLS", 600)
    stats.set_int(MPX .. "BULLPUP_ENEMY_KILLS", 600)
    stats.set_int(MPX .. "ASLTSHTGN_ENEMY_KILLS", 600)
    stats.set_int(MPX .. "SNIPERRFL_ENEMY_KILLS", 600)
    stats.set_int(MPX .. "HVYSNIPER_ENEMY_KILLS", 600)
    stats.set_int(MPX .. "GRNLAUNCH_ENEMY_KILLS", 600)
    stats.set_int(MPX .. "RPG_ENEMY_KILLS", 600)
    stats.set_int(MPX .. "MINIGUNS_ENEMY_KILLS", 600)
    stats.set_int(MPX .. "GRENADE_ENEMY_KILLS", 600)
    stats.set_int(MPX .. "SMKGRENADE_ENEMY_KILLS", 600)
    stats.set_int(MPX .. "STKYBMB_ENEMY_KILLS", 600)end)end 
  
  if ImGui.Button("Unlock Vehicles") then script.run_in_fiber(function(script) ---------------------------------------------- ** Unlock Vehicles ** ----------------------------------------- 
  
    stats.set_int(MPX .. "CHAR_FM_CARMOD_1_UNLCK", -1)
    stats.set_int(MPX .. "CHAR_FM_CARMOD_2_UNLCK", -1)
    stats.set_int(MPX .. "CHAR_FM_CARMOD_3_UNLCK", -1)
    stats.set_int(MPX .. "CHAR_FM_CARMOD_4_UNLCK", -1)
    stats.set_int(MPX .. "CHAR_FM_CARMOD_5_UNLCK", -1)
    stats.set_int(MPX .. "CHAR_FM_CARMOD_6_UNLCK", -1)
    stats.set_int(MPX .. "CHAR_FM_CARMOD_7_UNLCK", -1)
    stats.set_int(MPX .. "NUMBER_TURBO_STARTS_IN_RACE", 50)
    stats.set_int(MPX .. "USJS_COMPLETED", 25)
    stats.set_int(MPX .. "AWD_FM_RACES_FASTEST_LAP", 50)
    stats.set_int(MPX .. "NUMBER_SLIPSTREAMS_IN_RACE", 100)
    stats.set_int(MPX .. "AWD_WIN_CAPTURES", 50)
    stats.set_int(MPX .. "AWD_DROPOFF_CAP_PACKAGES", 100)
    stats.set_int(MPX .. "AWD_KILL_CARRIER_CAPTURE", 100)
    stats.set_int(MPX .. "AWD_FINISH_HEISTS", 50)------
    stats.set_int(MPX .. "AWD_FINISH_HEIST_SETUP_JOB", 50)
    stats.set_int(MPX .. "AWD_NIGHTVISION_KILLS", 100)
    stats.set_int(MPX .. "AWD_WIN_LAST_TEAM_STANDINGS", 50)
    stats.set_int(MPX .. "AWD_ONLY_PLAYER_ALIVE_LTS", 50)
    stats.set_int(MPX .. "AWD_FMRALLYWONDRIVE", 1)
    stats.set_int(MPX .. "AWD_FMRALLYWONNAV", 1)
    stats.set_int(MPX .. "AWD_FMWINAIRRACE", 1)
    stats.set_int(MPX .. "AWD_FMWINSEARACE", 1)
    stats.set_int(MPX .. "RACES_WON", 50)
    stats.set_int(MPX .. "MPPLY_TOTAL_RACES_WON", 50) end)end 
    
  if ImGui.Button("Unlock Phone Contacts") then script.run_in_fiber(function(script) ---------------------------------------------- ** Unlock Phone Contacts** ----------------------------------------- 
        stats.set_int(MPX .. "FM_ACT_PHN", -1)
        stats.set_int(MPX .. "FM_ACT_PH2", -1)
        stats.set_int(MPX .. "FM_ACT_PH3", -1)
        stats.set_int(MPX .. "FM_ACT_PH4", -1)
        stats.set_int(MPX .. "FM_ACT_PH5", -1)
        stats.set_int(MPX .. "FM_VEH_TX1", -1)
        stats.set_int(MPX .. "FM_ACT_PH6", -1)
        stats.set_int(MPX .. "FM_ACT_PH7", -1)
        stats.set_int(MPX .. "FM_ACT_PH8", -1)
        stats.set_int(MPX .. "FM_ACT_PH9", -1)
        stats.set_int(MPX .. "FM_ACT_PH10", -1)
        stats.set_int(MPX .. "FM_CUT_DONE", -1)
        stats.set_int(MPX .. "FM_CUT_DONE_2", -1) end)end
  
  if ImGui.Button("Unlock Trade Prices") then script.run_in_fiber(function(script) ---------------------------------------------- ** Unlock Trade Prices ** -----------------------------------------
          stats.set_int(MPX .. "GANGOPS_FLOW_BITSET_MISS0", -1)
          stats.set_int(MPX .. "LFETIME_HANGAR_BUY_UNDETAK", 42)
          stats.set_int(MPX .. "LFETIME_HANGAR_BUY_COMPLET", 42)
          stats.set_int(MPX .. "AT_FLOW_IMPEXP_NUM", 32)
          stats.set_int(MPX .. "AT_FLOW_VEHICLE_BS", -1)
          stats.set_int(MPX .. "WVM_FLOW_VEHICLE_BS", -1)
          stats.set_int(MPX .. "H3_BOARD_DIALOGU262145 +E0", -1)
          stats.set_int(MPX .. "H3_BOARD_DIALOGUE1", -1)
          stats.set_int(MPX .. "H3_BOARD_DIALOGUE2", -1)
          stats.set_int(MPX .. "H3_VEHICLESUSED", -1)
          stats.set_int(MPX .. "WAM_FLOW_VEHICLE_BS", -1)
          stats.set_bool(MPX .. "HELP_VEHUNHEISTISL", true)
          stats.set_bool(MPX .. "HELP_VEHICLESUNLOCK", true)
          stats.set_bool(MPX .. "HELP_VETO", true)
          stats.set_bool(MPX .. "HELP_VETO2", true)
          stats.set_bool(MPX .. "HELP_ITALIRSX", true)
          stats.set_bool(MPX .. "HELP_BRIOSO2", true)
          stats.set_bool(MPX .. "HELP_MANCHEZ2", true)
          stats.set_bool(MPX .. "HELP_SLAMTRUCK", true)
          stats.set_bool(MPX .. "HELP_VETIR", true)
          stats.set_bool(MPX .. "HELP_SQUADDIE", true)
          stats.set_bool(MPX .. "HELP_DINGY5", true)
          stats.set_bool(MPX .. "HELP_VERUS", true)
          stats.set_bool(MPX .. "HELP_WEEVIL", true)
          stats.set_bool(MPX .. "HELP_VEHUNTUNER", true)
          stats.set_bool(MPX .. "FIXER_VEH_HELP", true)
          stats.set_bool(MPX .. "HELP_DOMINATOR7", true)
          stats.set_bool(MPX .. "HELP_JESTER4", true)
          stats.set_bool(MPX .. "HELP_FUTO2", true)
          stats.set_bool(MPX .. "HELP_DOMINATOR8", true)
          stats.set_bool(MPX .. "HELP_PREVION", true)
          stats.set_bool(MPX .. "HELP_GROWLER", true)
          stats.set_bool(MPX .. "HELP_COMET6", true)
          stats.set_bool(MPX .. "HELP_VECTRE", true)
          stats.set_bool(MPX .. "HELP_SULTAN3", true)
          stats.set_bool(MPX .. "HELP_CYPHER", true)
          stats.set_bool(MPX .. "HELP_VEHUNFIXER", true)
          stats.set_bool(MPX .. "COMPLETE_H4_F_USING_VETIR", true)
          stats.set_bool(MPX .. "COMPLETE_H4_F_USING_LONGFIN", true)
          stats.set_bool(MPX .. "COMPLETE_H4_F_USING_ANNIH", true)
          stats.set_bool(MPX .. "COMPLETE_H4_F_USING_ALKONOS", true)
          stats.set_bool(MPX .. "COMPLETE_H4_F_USING_PATROLB", true) end)end
  ImGui.EndMenu()end 


------------------------------------------------------------------------------------------------------------------------------------------------  
ImGui.EndMenu() end 
if ImGui.BeginMenu("World") then 
  ImGui.BulletText("Coming Soon..")

------------------------------------------------------------------------------------------------------------------------------------------------
ImGui.EndMenu() end 

if ImGui.BeginMenu("Credits Script") then 
ImGui.BulletText("Developer : Offline Mods & Relayzr")
ImGui.BulletText("Source code : Recovery Script")
ImGui.BulletText("New and exclusive additions coming soon")
  
ImGui.BulletText("Recovery King X For FREE %100")

end end)

------------------------------------------------------------------------------------------------------------------------------------------------
--
--                                                               [ Encryption code ]        
--
------------------------------------------------------------------------------------------------------------------------------------------------

Money_Nightclcub_1 = 23963 Obj_Nightclcub_1 = 5000     
Money_Nightclcub_2 = 23964 Obj_Nightclcub_2 = 27000   
Money_Nightclcub_3 = 23965 Obj_Nightclcub_3 = 11475   
Money_Nightclcub_4 = 23966 Obj_Nightclcub_4 = 2025    
Money_Nightclcub_5 = 23967 Obj_Nightclcub_5 = 1350  
Money_Nightclcub_6 = 23968 Obj_Nightclcub_6 = 4725     
Money_Nightclcub_7 = 23969 Obj_Nightclcub_7 = 10000    

Obj_Hanger_1 = 30000  Money_Hanger_1 = 22493
Obj_Hanger_2 = 30000  Money_Hanger_2 = 22494
Obj_Hanger_3 = 30000  Money_Hanger_3 = 22495
Obj_Hanger_4 = 30000  Money_Hanger_4 = 22496
Obj_Hanger_5 = 30000  Money_Hanger_5 = 22497
Obj_Hanger_6 = 30000  Money_Hanger_6 = 22498
Obj_Hanger_7 = 30000  Money_Hanger_7 = 22499
Obj_Hanger_8 = 30000  Money_Hanger_8 = 22500

Obj_Acid_1 = 5000 Money_Acid_1 = 17324

Obj_Vehicle_Cargo_1 = 50 Money_Vehicle_Cargo_1 = 19170
Obj_Vehicle_Cargo_2 = 50 Money_Vehicle_Cargo_2 = 19171
Obj_Vehicle_Cargo_3 = 50 Money_Vehicle_Cargo_3 = 19172

Obj_Vehicle_Auto_1 = 5000 Money_Vehicle_Auto_1 = 30431
Obj_Vehicle_Auto_2 = 5000 Money_Vehicle_Auto_2 = 30432
Obj_Vehicle_Auto_3 = 5000 Money_Vehicle_Auto_3 = 30433

U_Achievements = 4543384

Obj_Heist_Doomsday_Cut1 = 25 Money_Heist_Doomsday_Cut1 = 1960755 + 812 + 50 + 1 
Obj_Heist_Doomsday_Cut2 = 25 Money_Heist_Doomsday_Cut2 = 1960755 + 812 + 50 + 2 
Obj_Heist_Doomsday_Cut3 = 25 Money_Heist_Doomsday_Cut3 = 1960755 + 812 + 50 + 3 
Obj_Heist_Doomsday_Cut4 = 25 Money_Heist_Doomsday_Cut4 = 1960755 + 812 + 50 + 4 

Obj_Heist_Diamond_Cut1 = 25 Money_Heist_Diamond_Cut1 = 1964849 + 1497 + 736 + 92 + 1 
Obj_Heist_Diamond_Cut2 = 25 Money_Heist_Diamond_Cut2 = 1964849 + 1497 + 736 + 92 + 2 
Obj_Heist_Diamond_Cut3 = 25 Money_Heist_Diamond_Cut3 = 1964849 + 1497 + 736 + 92 + 3 
Obj_Heist_Diamond_Cut4 = 25 Money_Heist_Diamond_Cut4 = 1964849 + 1497 + 736 + 92 + 4 

Obj_Heist_Cayo_Cut1 = 25 Money_Heist_Cayo_Cut1 = 1971648 + 831 + 56 + 1
Obj_Heist_Cayo_Cut2 = 25 Money_Heist_Cayo_Cut2 = 1971648 + 831 + 56 + 2 
Obj_Heist_Cayo_Cut3 = 25 Money_Heist_Cayo_Cut3 = 1971648 + 831 + 56 + 3
Obj_Heist_Cayo_Cut4 = 25 Money_Heist_Cayo_Cut4 = 1971648 + 831 + 56 + 4

  Obj_Agency1 = 1000000  Money_gency1 = 31084

  Obj_SantosT1 = 100000
  Obj_SantosT2 = 100000
  Obj_SantosT3 = 100000
  Obj_SantosT4 = 100000
  Obj_SantosT5 = 100000
  Obj_SantosT6 = 100000
  Obj_SantosT7 = 100000
  Obj_SantosT8 = 100000

---- -- --- -- -- -- -- -- - - -- - -- -- - -- -- - -- -- --  -- -- -- " End " -- -- -- -- -- -- -- -- - -- -- -- -- -- - -- -- - -- -- -- -- --

